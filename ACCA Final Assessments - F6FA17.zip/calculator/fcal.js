var gCalcOut = ""; //this variable to be accessed from other windows

var cMemory = new Array(12);
for(i=0;i<cMemory.length;i++){cMemory[i] = 0};
var decimalOn = false;
var newOperation = true;
var lastVal = 0;
var thisVal=0;
var lastOperand=0;
var thisOperation = "";
var tvm = "";
var thisDisp = "";
var addToMemOn = false;
var memRecall = false;
var spadWin="";
var helpWin="";
var refreshDisp=false;
var equalActive=false;
var roundOff = 4;
var roundOffActive=true;
var memOperationActive = false;
var tvmN = 0;
var tvmI = 0;
var tvmPV = 0;
var tvmPMT = 0;
var tvmFV = 0;
var tvmDate1 = null;
var tvmDate2 = null;
var tvmDays = 0;
var newFigure = false;
var calculate=false;
var addingDigits=false;
var calculated=false;
var dateActive = false;

function AddDigit(which){
	if(equalActive && !addToMemOn && !memRecall){ClearDisp(); equalActive=false;};
	if(which=="cdecimal"&&decimalOn)return;
	if(addToMemOn){AddToMemory(which);return;};
	if(memRecall){RecallMemory(which);return;};
	if(thisDisp.length>=22){return;};
	if(!newFigure)(thisDisp="");
	if(which=="cdecimal"){
		if(thisDisp==""||thisDisp=="0"||refreshDisp){
			thisDisp = "0.";
			refreshDisp=false;
		}else{
			thisDisp = thisDisp + ".";
		}
		decimalOn=true;
	}else{
		if(refreshDisp){
			thisDisp = which;
			refreshDisp=false;
			decimalOn=false
		}else{
			if(thisDisp=="0"){
				thisDisp = which;
			}else{
				thisDisp = thisDisp + which;
			}
		}
	}

	thisVal = Number(thisDisp);
	addingDigits=true;
	DisplayFigure();
	newFigure=true;
	calculated=false;
}

function DisplayFigure(){
	if(thisDisp.toString()=="Infinity"){
		document.forms["calc"].cdisp.value=thisDisp;
		thisDisp="0";
		thisVal=0;
		return;
	}
	if(addingDigits){
		if(thisDisp.toString()=="0"){
			document.forms["calc"].cdisp.value="0"
		}else{
			document.forms["calc"].cdisp.value=FormatDisp(thisDisp.toString());
		}
	}else{
		if(RoundOff(thisDisp).toString()=="0"){
			document.forms["calc"].cdisp.value="0"
		}else{
			if(dateActive){
				dateActive = false;
				document.forms["calc"].cdisp.value=FormatDisp(thisDisp.toString());
			}else{
				document.forms["calc"].cdisp.value=FormatDisp(RoundOff(thisDisp).toString());
			}
		}
	}
	addingDigits=false;
	//----for removing day chars from dates before assigning to variable----//
	var validChars = "0123456789";
	var str = document.forms["calc"].cdisp.value;
	for(i=str.length-1;i>=0;i--){
		if(validChars.indexOf(str.substr(str.length-1,1))==-1){
			str=str.substr(0,str.length-1);
		}else{
			break;
		}
	}
	gCalcOut = str;
	
	SetLCD1();
}

function FormatDisp(disp){
	if(disp=="Infinity")return disp;
	var str2 = "";
	var str1 = "";
	if(disp.indexOf(".")==-1){
		str1 = disp;
	}else{
		str2 = disp.substr(disp.indexOf("."),disp.length);
		str1 = disp.substr(0,disp.indexOf("."));
	}
	var j=0;
	var strOut = "";
	for(i=str1.length;i>0;i--){
		if(j<3){
			strOut = str1.substring(i,i-1) + strOut;
			j++
		}else{
			if(str1.substring(i,i-1)=="-"){
				strOut = str1.substring(i,i-1) + strOut;
			}else{
				strOut = str1.substring(i,i-1) + "," + strOut;
			}
			j=1;
		}
	}
	strOut = strOut + str2;
	return strOut;
}

function BackSpace(){
	var tmpstr = "-.0123456789";
	var tmpDisp1 = document.forms["calc"].cdisp.value.toString();
	var tmpDisp = thisDisp.toString();
	if(tmpDisp1.length>1&&(tmpstr.indexOf(tmpDisp1.substr(0,1))!=-1)&&tmpstr.indexOf(tmpDisp1.substr(tmpDisp1.length-1,1))!=-1){
		if(calculated==true && thisDisp != RoundOff(thisDisp))tmpDisp = RoundOff(thisDisp).toString();
		
		if(tmpDisp.substr(tmpDisp.length-1,1)==".")decimalOn=false;
		thisDisp = tmpDisp.substr(0,tmpDisp.length-1);
		thisVal = Number(thisDisp);
		addingDigits=true;
		DisplayFigure();
		newFigure=true;
		calculated=false;

	}else{
		if(tmpstr.indexOf((document.forms["calc"].cdisp.value).substr(0,1))==-1){
			thisDisp = "0";
		}else if(tmpstr.indexOf(tmpDisp.substr(tmpDisp.length-1,1))==-1){
			var fexit = false;
			while(!fexit){
				if(tmpstr.indexOf(tmpDisp.substr(tmpDisp.length-1,1))==-1){
					tmpDisp = tmpDisp.substr(0,tmpDisp.length-1);
				}else{
					fexit=true;
				}
			}
			thisDisp = tmpDisp;
		}else{
			thisDisp = "0";
		}
		thisVal = Number(thisDisp);
		addingDigits=true;
		DisplayFigure();
		newFigure=true;
		calculated=false;
	}
}

function AddToMemory(which){
	var mLoc = which;
	if(isNaN(Number(mLoc))||Number(mLoc)>12||mLoc==null||mLoc==""){return};
	var tmpVal = thisVal;
	thisDisp = thisVal.toString();
	if(memOperationActive){
		if(thisOperation=="cadd"){
			tmpVal=eval(cMemory[Number(mLoc)-1] + tmpVal);
		}else if(thisOperation=="csubtract"){
			tmpVal=eval(cMemory[Number(mLoc)-1] - tmpVal);
		}else if(thisOperation=="cmultiply"){
			tmpVal=eval(cMemory[Number(mLoc)-1] * tmpVal);
		}else if(thisOperation=="cdivide"){
			tmpVal=eval(cMemory[Number(mLoc)-1] / tmpVal);
		}
	}
	cMemory[Number(mLoc)-1] = tmpVal;
	DisplayFigure();
	addToMemOn = false;
	memOperationActive = false;
	decimalOn=false;
	newFigure=false;
}

function RecallMemory(which){
	var mLoc = which;
	if(isNaN(Number(mLoc))||Number(mLoc)>12||mLoc==null||mLoc==""){return};
	thisVal = cMemory[Number(mLoc)-1];
	if(thisVal==null)return;
	thisDisp = thisVal.toString();
	DisplayFigure();
	memRecall=false;
	decimalOn=false;
	newFigure=true;
}

function AddOperation(which){
	switch(which){
	case "ctvm": ToggleTVM();break;
	case "cspad": ShowSPad();break;
	case "cclear": ClearAll();break;
	case "cplusminus":
			thisVal = -1 * thisVal
			thisDisp = thisVal.toString();
			newFigure=true;
			DisplayFigure();
			break;
	case "cback": BackSpace();break;
	case "cstore": if(!addToMemOn){
				addToMemOn=true;document.forms["calc"].cdisp.value="STO_";
				SetLCD1();
			}else{
				addToMemOn=false;document.forms["calc"].cdisp.value=thisDisp
				DisplayFigure();
			}
			break;
	case "crecall": if(!memRecall){
				memRecall=true;document.forms["calc"].cdisp.value="RCL_";
				SetLCD1();
			}else{
				memRecall=false;document.forms["calc"].cdisp.value=thisDisp
				DisplayFigure();
			}
			break;
	case "creciprocal":
			if(thisVal!=0){
				thisVal = eval(1 / thisVal);
				thisDisp = thisVal.toString();
				DisplayFigure();
				decimalOn=false;
				newFigure=false;
				break;
			}
			break;
	case "ctvm1":
			if(tvm == "tvm"){
				if(memRecall){
					ClearDisp();
					memRecall = false;
				}
				GetN();
				break;
			}else if(tvm == "tim"){
				if(memRecall){
					ClearDisp();
					memRecall = false;
				}
				SetDate1();
				break;
			}else{
				break;
			}
	case "ctvm2":
			if(tvm == "tvm"){
				if(memRecall){
					ClearDisp();
					memRecall = false;
				}
				GetI();
				break;
			}else if(tvm == "tim"){
				if(memRecall){
					ClearDisp();
					memRecall = false;
				}
				SetDate2();
				break;
			}else{
				break;
			}
	case "ctvm3":
			if(tvm == "tvm"){
				if(memRecall){
					ClearDisp();
					memRecall = false;
				}
				GetPV();
				break;
			}else if(tvm == "tim"){
				if(memRecall){
					ClearDisp();
					memRecall = false;
				}
				GetDays();
				break;
			}else{
				break;
			}
	case "ctvm4":
			if(tvm == "tvm"){
				if(memRecall){
					ClearDisp();
					memRecall = false;
				}
				GetPMT();
				break;
			}else{
				break;
			}
	case "ctvm5":
			if(tvm == "tvm"){
				if(memRecall){
					ClearDisp();
					memRecall = false;
				}
				GetFV();
				break;
			}else{
				break;
			}
	case "ctvm6":
			break;
	default:
		if(addToMemOn){
			if(which=="cadd"||which=="csubtract"||which=="cmultiply"||which=="cdivide"){
				memOperationActive = true;
				thisOperation = which;
				break;
			}
		}

		if(which=="cequal"){
			if(addToMemOn){
				AddToMemory(document.forms["calc"].cdisp.value);
				break;
			}
			if(memRecall){
				RecallMemory(document.forms["calc"].cdisp.value);
				break;
			}
			if(!equalActive){
				lastOperand = thisVal;
			}
			DoCalculate();
			equalActive=true;
		}else{
			decimalOn=false;
			if(newOperation||equalActive||!newFigure){
				lastVal = thisVal;
				thisOperation = which;
				newOperation = false;
				newFigure=false;
				equalActive=false;
			}else{
				lastOperand = thisVal;
				DoCalculate();
				lastVal = thisVal;
				thisOperation = which;
				equalActive=false;
				newFigure=false;
			}
		}
		refreshDisp=true;
	}
}

function GetN(){
	if(tvmI==0||tvmPV==0){
		if(newFigure){
			tvmN=thisVal;
			calculate=true;
		}
	}else{
		if(newFigure){
			tvmN=thisVal;
			calculate=true;
		}else{
			if(calculate){
				if(tvmPMT>0 && tvmFV>0){
					if(tvmPMT == tvmI*tvmFV){
						document.forms["calc"].cdisp.value = "N=Undefined";
						SetLCD1();
						return;
					}else{
						tvmN=(Math.log(tvmPMT-(tvmI*tvmFV))-Math.log(tvmPMT+(tvmI*tvmPV)))/Math.log(1+i);
					}
				}else if(tvmFV>0 && tvmPMT==0){
					tvmN=(Math.log(tvmFV)-Math.log(-tvmPV))/Math.log(1+tvmI);
				}else if(tvmFV==0 && tvmPMT>0){
					tvmN=(Math.log(tvmPMT)-Math.log(tvmPMT+(tvmI*tvmPV)))/Math.log(1+tvmI);
				}else{
					if(tvmFV<0&&tvmPMT<0){
						document.forms["calc"].cdisp.value = "Invalid value in FV, PMT";
						SetLCD1();
						decimalOn=false;
						newFigure=false;
						return;
					}else if(tvmFV<0){
						document.forms["calc"].cdisp.value = "Invalid value in FV";
						SetLCD1();
						decimalOn=false;
						newFigure=false;
						return;
					}else if(tvmPMT<0){
						document.forms["calc"].cdisp.value = "Invalid value in PMT";
						SetLCD1();
						decimalOn=false;
						newFigure=false;
						return;
					}
				}
				calculate=false;
			}
		}
	}
	gCalcOut = FormatDisp(RoundOff(tvmN).toString());
	//thisVal = RoundOff(tvmN);
	thisVal = tvmN;
	thisDisp = RoundOff(tvmN).toString();
	document.forms["calc"].cdisp.value = "N= " + gCalcOut;
	decimalOn=false;
	newFigure=false;
	SetLCD1();
}

function GetI(){
	if(tvmPV==0||tvmN==0){
		if(newFigure){
			if(thisVal<-100 || thisVal==0 || thisVal>100){
				document.forms["calc"].cdisp.value = "Invalid value";
				SetLCD1();
				decimalOn=false;
				newFigure=false;
				return;
			}
			tvmI=thisVal/100;
			calculate=true;
		}
	}else{
		if(newFigure){
			if(thisVal<-100 || thisVal==0 || thisVal>100){
				document.forms["calc"].cdisp.value = "Invalid value";
				SetLCD1();
				decimalOn=false;
				newFigure=false;
				return;
			}
			tvmI=thisVal/100;
			calculate=true;
		}else{
			if(tvmN<=0){
				document.forms["calc"].cdisp.value = "Invalid value in N";
				SetLCD1();
				decimalOn=false;
				newFigure=false;
				return;
			}
			if(calculate){
				document.forms["calc"].cdisp.value = "Calculating I&#37;YR...";
				SetLCD1();
				var i=0;
				var tempPV=0;
				var dPVNew=0;
				var dPVOld=0;
				var j=0;
				var found=false;
				var nextDecimal=false;
				setI=true;
				if(Math.abs(tvmFV) > Math.abs(tvmPV)){
					var k = 1;
				}else{
					var k = -1;
				}
				do{
					i=++j/100;
					tempPV=-1*tvmPMT*((1-(1/Math.pow((1+(k*i)),tvmN)))/(k*i))-(tvmFV/Math.pow((1+(k*i)),tvmN));
					if(i > 0.01){
						dPVNew = Math.abs(Math.abs(tvmPV) - Math.abs(tempPV));
						if(dPVNew==0){
							i=++j/100;
							found=true;
							break;
						}else if((dPVNew > dPVOld)&&(dPVOld < (0.1 * Math.abs(tvmPV)))){
							found=true;
							nextDecimal=true;
							break;
						}else{
							dPVOld = dPVNew;
						}
					}else{
						dPVOld = Math.abs(tvmPV - tempPV);
					}
				}while (i<=1.01);
				if(found&&nextDecimal){
					j=0;
					found=false;
					nextDecimal=false;
					do{
						i=++j/1000;
						tempPV=-1*tvmPMT*((1-(1/Math.pow((1+(k*i)),tvmN)))/(k*i))-(tvmFV/Math.pow((1+(k*i)),tvmN));
						if(i > 0.001){
							dPVNew = Math.abs(Math.abs(tvmPV) - Math.abs(tempPV));
							if(dPVNew==0){
								i=++j/1000;
								found=true;
								break;
							}else if((dPVNew > dPVOld)&&(dPVOld < (0.1 * Math.abs(tvmPV)))){
								found=true;
								nextDecimal=true;
								break;
							}else{
								dPVOld = dPVNew;
							}
						}else{
							dPVOld = Math.abs(tvmPV - tempPV);
						}
					}while (i<=1.001);
					i = j/1000 - 0.001;
					setI = false;
					if(i == 1.001 && !found){
						document.forms["calc"].cdisp.value = "I%YR=No result found";
						SetLCD1();
						decimalOn=false;
						newFigure=false;
						calculate=false;
						tvmI = 0;
						return;
					}
				}
				if(found&&nextDecimal){
					j=0;
					found=false;
					nextDecimal=false;
					do{
						i=++j/10000;
						tempPV=-1*tvmPMT*((1-(1/Math.pow((1+(k*i)),tvmN)))/(k*i))-(tvmFV/Math.pow((1+(k*i)),tvmN));
						if(i > 0.0001){
							dPVNew = Math.abs(Math.abs(tvmPV) - Math.abs(tempPV));
							if(dPVNew==0){
								i=++j/10000;
								found=true;
								break;
							}else if((dPVNew > dPVOld)&&(dPVOld < (0.1 * Math.abs(tvmPV)))){
								found=true;
								nextDecimal=true;
								break;
							}else{
								dPVOld = dPVNew;
							}
						}else{
							dPVOld = Math.abs(tvmPV - tempPV);
						}
					}while (i<=1.0001);
					i = j/10000 - 0.0001;
					setI = false;
					if(i == 1.0001 && !found){
						document.forms["calc"].cdisp.value = "I%YR=No result found";
						SetLCD1();
						decimalOn=false;
						newFigure=false;
						calculate=false;
						tvmI = 0;
						return;
					}
				}
				if(found&&nextDecimal){
					j=0;
					found=false;
					nextDecimal=false;
					do{
						i=++j/100000;
						tempPV=-1*tvmPMT*((1-(1/Math.pow((1+(k*i)),tvmN)))/(k*i))-(tvmFV/Math.pow((1+(k*i)),tvmN));
						if(i > 0.00001){
							dPVNew = Math.abs(Math.abs(tvmPV) - Math.abs(tempPV));
							if(dPVNew==0){
								i=++j/100000;
								found=true;
								break;
							}else if((dPVNew > dPVOld)&&(dPVOld < (0.1 * Math.abs(tvmPV)))){
								found=true;
								nextDecimal=true;
								break;
							}else{
								dPVOld = dPVNew;
							}
						}else{
							dPVOld = Math.abs(tvmPV - tempPV);
						}
					}while (i<=1.00001);
					i = j/100000 - 0.00001;
					setI = false;
					if(i == 1.00001 && !found){
						document.forms["calc"].cdisp.value = "I%YR=No result found";
						SetLCD1();
						decimalOn=false;
						newFigure=false;
						calculate=false;
						tvmI = 0;
						return;
					}
				}
				if(found&&nextDecimal){
					j=0;
					found=false;
					nextDecimal=false;
					do{
						i=++j/1000000;
						tempPV=-1*tvmPMT*((1-(1/Math.pow((1+(k*i)),tvmN)))/(k*i))-(tvmFV/Math.pow((1+(k*i)),tvmN));
						if(i > 0.000001){
							dPVNew = Math.abs(Math.abs(tvmPV) - Math.abs(tempPV));
							if(dPVNew==0){
								i=++j/1000000;
								found=true;
								break;
							}else if((dPVNew > dPVOld)&&(dPVOld < (0.1 * Math.abs(tvmPV)))){
								found=true;
								nextDecimal=true;
								break;
							}else{
								dPVOld = dPVNew;
							}
						}else{
							dPVOld = Math.abs(tvmPV - tempPV);
						}
					}while (i<=1.000001);
					i = j/1000000 - 0.000001;
					setI = false;
					if(i == 1.000001 && !found){
						document.forms["calc"].cdisp.value = "I%YR=No result found";
						SetLCD1();
						decimalOn=false;
						newFigure=false;
						calculate=false;
						tvmI = 0;
						return;
					}
				}
				if(setI){
					i = j/100 - 0.01;
					setI = false;
					if(i == 1.01 && !found){
						document.forms["calc"].cdisp.value = "I%YR=No result found";
						SetLCD1();
						decimalOn=false;
						newFigure=false;
						calculate=false;
						tvmI = 0;
						return;
					}
				}
				tvmI = (k*i);
				calculate=false;
			}
		}
	}
	gCalcOut = FormatDisp((RoundOff(tvmI*100)).toString());
	//thisVal = RoundOff(tvmI*100);
	thisVal = tvmI*100;
	thisDisp = RoundOff(tvmI*100).toString();
	document.forms["calc"].cdisp.value = "I&#37;YR= " + gCalcOut;
	decimalOn=false;
	newFigure=false;
	SetLCD1();
}

function GetPV(){
	if(tvmI==0||tvmN==0){
		if(newFigure){
			tvmPV=thisVal;
			calculate=true;
		}
	}else{
		if(newFigure){
			tvmPV=thisVal;
			calculate=true;
		}else{
			if(calculate){
				tvmPV=-1*tvmPMT*((1-(1/Math.pow((1+tvmI),tvmN)))/tvmI)-(tvmFV/Math.pow((1+tvmI),tvmN));
				calculate=false;
			}
		}
	}
	gCalcOut = FormatDisp(RoundOff(tvmPV).toString());
	//thisVal = RoundOff(tvmPV);
	thisVal = tvmPV;
	thisDisp = RoundOff(tvmPV).toString();
	document.forms["calc"].cdisp.value = "PV= " + gCalcOut;
	decimalOn=false;
	newFigure=false;
	SetLCD1();
}

function GetFV(){
	if(tvmI==0||tvmN==0){
		if(newFigure){
			tvmFV=thisVal;
			calculate=true;
		}
	}else{
		if(newFigure){
			tvmFV=thisVal;
			calculate=true;
		}else{
			if(calculate){
				tvmFV=-1*(tvmPV + tvmPMT*(1-(1/Math.pow((1+tvmI),tvmN)))/tvmI)*Math.pow((1+tvmI),tvmN);
				calculate=true;
			}
		}
	}
	gCalcOut = FormatDisp(RoundOff(tvmFV).toString());
	//thisVal = RoundOff(tvmFV);
	thisVal = tvmFV;
	thisDisp = RoundOff(tvmFV).toString();
	document.forms["calc"].cdisp.value = "FV= " + gCalcOut;
	decimalOn=false;
	newFigure=false;
	SetLCD1();
}

function GetPMT(){
	if(tvmI==0||tvmN==0){
		if(newFigure){
			tvmPMT=thisVal;
			calculate=true;
		}
	}else{
		if(newFigure){
			tvmPMT=thisVal;
			calculate=true;
		}else{
			if(calculate){
				if(tvmN<=0){
					document.forms["calc"].cdisp.value = "Invalid value in N";
					SetLCD1();
					decimalOn=false;
					newFigure=false;
					return;
				}
				tvmPMT=tvmI*(((Math.pow((1+tvmI),tvmN)*tvmPV)+tvmFV)/(1-Math.pow((1+tvmI),tvmN)));
				calculate=true;
			}
		}
	}
	gCalcOut = FormatDisp(RoundOff(tvmPMT).toString());
	//thisVal = RoundOff(tvmPMT);
	thisVal = tvmPMT;
	thisDisp = RoundOff(tvmPMT).toString();
	document.forms["calc"].cdisp.value = "PMT= " + gCalcOut;
	decimalOn=false;
	newFigure=false;
	SetLCD1();
}

function SetDate1(){
	if(tvmDate2==null){
		if(newFigure&&!calculated){
			if(!ValidDate()){
				document.forms["calc"].cdisp.value = "Invalid Date";
				SetLCD1();
				newFigure=false;
				decimalOn=false;
				return;
			}
			var mm = thisDisp.substr(0,thisDisp.indexOf("."));
			var dd = thisDisp.substr(thisDisp.indexOf(".")+1,2);
			var yyyy = thisDisp.substr(thisDisp.indexOf(".")+3,4);
			tvmDate1 = new Date(Number(yyyy),Number(mm)-1,Number(dd));
			RecallDate(tvmDate1);
		}else{
			if(tvmDate1!=null)RecallDate(tvmDate1);
		}
	}else{
		if(newFigure&&!calculated){
			if(!ValidDate()){
				document.forms["calc"].cdisp.value = "Invalid Date";
				SetLCD1();
				newFigure=false;
				decimalOn=false;
				return;
			}
			var mm = thisDisp.substr(0,thisDisp.indexOf("."));
			var dd = thisDisp.substr(thisDisp.indexOf(".")+1,2);
			var yyyy = thisDisp.substr(thisDisp.indexOf(".")+3,4);
			tvmDate1 = new Date(Number(yyyy),Number(mm)-1,Number(dd));
			RecallDate(tvmDate1);
		}else{
			if(!calculated){
				tvmDate1 = new Date(tvmDate2.getTime()-(tvmDays*86400000));
			}
			RecallDate(tvmDate1);
		}
	}
	newFigure=false;
	decimalOn=false;
}

function SetDate2(){
	if(tvmDate1==null){
		if(newFigure&&!calculated){
			if(!ValidDate()){
				document.forms["calc"].cdisp.value = "Invalid Date";
				SetLCD1();
				newFigure=false;
				decimalOn=false;
				return;
			}
			var mm = thisDisp.substr(0,thisDisp.indexOf("."));
			var dd = thisDisp.substr(thisDisp.indexOf(".")+1,2);
			var yyyy = thisDisp.substr(thisDisp.indexOf(".")+3,4);
			tvmDate2 = new Date(Number(yyyy),Number(mm)-1,Number(dd));
			RecallDate(tvmDate2);
		}else{
			if(tvmDate2!=null)RecallDate(tvmDate2);
		}
	}else{
		if(newFigure&&!calculated){
			if(!ValidDate()){
				document.forms["calc"].cdisp.value = "Invalid Date";
				SetLCD1();
				newFigure=false;
				decimalOn=false;
				return;
			}
			var mm = thisDisp.substr(0,thisDisp.indexOf("."));
			var dd = thisDisp.substr(thisDisp.indexOf(".")+1,2);
			var yyyy = thisDisp.substr(thisDisp.indexOf(".")+3,4);
			tvmDate2 = new Date(Number(yyyy),Number(mm)-1,Number(dd));
			RecallDate(tvmDate2);
		}else{
			if(!calculated){
				tvmDate2 = new Date(tvmDate1.getTime()+(tvmDays*86400000));
			}
			RecallDate(tvmDate2);
		}
	}
	newFigure=false;
	decimalOn=false;
}

function GetDays(){
	if(tvmDate1==null||tvmDate2==null||tvmDate1==""||tvmDate2==""||calculated){
		if(newFigure){
			tvmDays=Math.round(thisVal);
			calculated=false;
		}else{
			thisVal=tvmDays;
			thisDisp=thisVal;
			dateActive = true;
			DisplayFigure();
		}
	}else{
		if(newFigure){
			tvmDays=Math.round(thisVal);
		}else{
			if(tvmDate2>tvmDate1){
				tvmDays=Math.round((tvmDate2-tvmDate1)/86400000);
			}else{
				tvmDays=Math.round((tvmDate1-tvmDate2)/86400000);
			}
			thisVal=tvmDays;
			thisDisp=thisVal;
			dateActive = true;
			DisplayFigure();
		}
	}
	newFigure=false;
	decimalOn=false;
}

function RecallDate(dt){
	var mm = dt.getMonth()+1;
	var dd = dt.getDate();
	var yyyy = dt.getFullYear();
	if(dd<=9){
		thisDisp = mm+".0"+dd+yyyy;
	}else{
		thisDisp = mm+"."+dd+yyyy;
	}
	thisVal = Number(thisDisp);
	var wday = "";
	switch(dt.getDay()){
	case 0: wday = "SUN"; break;
	case 1: wday = "MON"; break;
	case 2: wday = "TUE"; break;
	case 3: wday = "WED"; break;
	case 4: wday = "THU"; break;
	case 5: wday = "FRI"; break;
	case 6: wday = "SAT"; break;
	}
	thisDisp = thisDisp + " " + wday;
	dateActive = true;
	DisplayFigure();
	newFigure=false;
}
function ValidDate(){
	if(thisDisp.indexOf("-")!=-1||thisDisp.indexOf(",")!=-1||thisDisp.indexOf(".")==-1||thisDisp.indexOf(".")<1||thisDisp.indexOf(".")>2)return false;
	if((thisDisp.length-thisDisp.indexOf(".")-1)!=6)return false;
	var mm = thisDisp.substr(0,thisDisp.indexOf("."));
	var dd = thisDisp.substr(thisDisp.indexOf(".")+1,2);
	var yyyy = thisDisp.substr(thisDisp.indexOf(".")+3,4);
	if(Number(mm)<=0||Number(mm)>12)return false;
	if(mm==2){
		if(GetLeap(yyyy)){
			if(dd>0&&dd<=29){
				return true;
			}else{
				return false;
			}
		}else{
			if(dd>0&&dd<=28){
				return true;
			}else{
				return false;
			}
		}
	}else if(mm==4||mm==6||mm==9||mm==11){
		if(dd>0&&dd<=30){
			return true;
		}else{
			return false;
		}
	}else{
		if(dd>0&&dd<=31){
			return true;
		}else{
			return false;
		}
	}
}

function GetLeap(yyyy){
	if (((yyyy % 4 == 0) && (yyyy % 100 != 0)) || (yyyy % 400 == 0)){
		return true;
	}else{
		return false;
	}
}

function DoCalculate(){

	var tot = 0;
	switch(thisOperation){
	case "cadd":
		tot = eval(lastVal + lastOperand);
		lastVal = tot;
		thisVal = tot;
		thisDisp = tot;
		DisplayFigure();
		break;
	case "csubtract":
		tot = eval(lastVal - lastOperand);
		lastVal = tot;
		thisVal = tot;
		thisDisp = tot;
		DisplayFigure();
		break;
	case "cdivide":
		tot = eval(lastVal / lastOperand);
		lastVal = tot;
		thisVal = tot;
		thisDisp = tot;
		DisplayFigure();
		break;
	case "cmultiply":
		tot = eval(lastVal * lastOperand);
		lastVal = tot;
		thisVal = tot;
		thisDisp = tot;
		DisplayFigure();
		break;
	case "cpower":
		tot = Math.pow(lastVal, lastOperand);
		lastVal = tot;
		thisVal = tot;
		thisDisp = tot;
		DisplayFigure();
		break;
	}
	calculated=true;
	newFigure=true;
}

function SetDecimal(num){
	roundOff = num;
	roundOffActive=true;
	switch(num){
		case 2:
			ReWriteLayer('<font size=1 color=#ffffff face=Arial,Helvetica,Tahoma,Verdana>&nbsp;DECIMALS: </font><a href="javascript:SetDecimal(2);"style="text-decoration: none;"><font size=1 face="Arial,Helvetica,Tahoma,Verdana" style="text-decoration:none; color:#ffff00">2</font></a>&nbsp;<a href="javascript:SetDecimal(4);"style="text-decoration: none;"><font size=1 face="Arial,Helvetica,Tahoma,Verdana" style="text-decoration:none; color:#ffffff">4</font></a>&nbsp;<a href="javascript:SetDecimal(6);"style="text-decoration: none;"><font size=1 face="Arial,Helvetica,Tahoma,Verdana" style="text-decoration:none; color:#ffffff">6</font></a>',"d2");
			break;
		case 4:
			ReWriteLayer('<font size=1 color=#ffffff face=Arial,Helvetica,Tahoma,Verdana>&nbsp;DECIMALS: </font><a href="javascript:SetDecimal(2);"style="text-decoration: none;"><font size=1 face="Arial,Helvetica,Tahoma,Verdana" style="text-decoration:none; color:#ffffff">2</font></a>&nbsp;<a href="javascript:SetDecimal(4);"style="text-decoration: none;"><font size=1 face="Arial,Helvetica,Tahoma,Verdana" style="text-decoration:none; color:#ffff00">4</font></a>&nbsp;<a href="javascript:SetDecimal(6);"style="text-decoration: none;"><font size=1 face="Arial,Helvetica,Tahoma,Verdana" style="text-decoration:none; color:#ffffff">6</font></a>',"d2");
			break;
		case 6:
			ReWriteLayer('<font size=1 color=#ffffff face=Arial,Helvetica,Tahoma,Verdana>&nbsp;DECIMALS: </font><a href="javascript:SetDecimal(2);"style="text-decoration: none;"><font size=1 face="Arial,Helvetica,Tahoma,Verdana" style="text-decoration:none; color:#ffffff">2</font></a>&nbsp;<a href="javascript:SetDecimal(4);"style="text-decoration: none;"><font size=1 face="Arial,Helvetica,Tahoma,Verdana" style="text-decoration:none; color:#ffffff">4</font></a>&nbsp;<a href="javascript:SetDecimal(6);"style="text-decoration: none;"><font size=1 face="Arial,Helvetica,Tahoma,Verdana" style="text-decoration:none; color:#ffff00">6</font></a>',"d2");
			break;
	}
	thisDisp = thisVal.toString();
	switch((document.forms["calc"].cdisp.value).substr(0,2)){
		case "N=": GetN(); break;
		case "I&": GetI(); break;
		case "PV": GetPV(); break;
		case "PM": GetPMT(); break;
		case "FV": GetFV(); break;
		default : if(!newFigure || calculated)DisplayFigure();
	}
}

function ReWriteLayer(Text,LName) {
	MM_setTextOfLayer(LName, "", Text);
}


function RoundOff(val){
	if(roundOffActive){
		var tmpval = val*(Math.pow(10,roundOff));
		tmpval = Math.round(tmpval);
		return tmpval/(Math.pow(10,roundOff));
	}else{
		return val;
	}
}

function ClearAll(){
	decimalOn = false;
	newOperation = true;
	lastVal = 0;
	thisVal=0;
	thisOperation = "";
	thisDisp=""
	addToMemOn = false;
	memRecall = false;
	memOperationActive = false;
	refreshDisp=false;
	equalActive=false;
	tvmN = 0;
	tvmI = 0;
	tvmPV = 0;
	tvmPMT = 0;
	tvmFV = 0;
	tvmDate1 = null;
	tvmDate2 = null;
	tvmDays = 0;	
	for(i=0;i<cMemory.length;i++){cMemory[i] = 0};
	newFigure = false;
	document.forms["calc"].cdisp.value="0";
	gCalcOut = document.forms["calc"].cdisp.value;
	SetLCD1();
}

function ClearDisp(){
	decimalOn = false;
	newOperation = true;
	lastVal = 0;
	thisVal=0;
	thisOperation = "";
	thisDisp=""
	addToMemOn = false;
	memRecall = false;
	memOperationActive = false;
	refreshDisp=false;
	equalActive=false;
	newFigure = false;
	document.forms["calc"].cdisp.value="0";
	gCalcOut = document.forms["calc"].cdisp.value;
	SetLCD1();
}

function SetValue(val){	//to be accessed from other windows
	thisDisp="";
	validationStr = "-.1234567890";
	for(i=0;i<val.length;i++){
		if(validationStr.indexOf(val.substr(i,1))!=-1){
			thisDisp = thisDisp + val.substr(i,1);
		}
	}
	thisVal = Number(thisDisp);
	newFigure = true;
	roundOffActive = false;
	DisplayFigure();
	roundOffActive = true;
}

function SetLCD1(){
	var tmpStr = '<font size=2 color=#000000 face=Arial,Helvetica,Tahoma,Verdana>' + document.forms["calc"].cdisp.value + '</font>';
	MM_setTextOfLayer("LCD1","",tmpStr);
}

function SetLCD2(){
	var tmpStr = '<table width=196 border=0 cellspacing=2 cellpadding=0><tr>';
	var tmpStr2 = '';
	switch(tvm){
	case "tvm":
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600"><font size=1 color="#ffffff" face=Arial,Helvetica,Tahoma,Verdana>N</font></td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600"><font size=1 color="#ffffff" face=Arial,Helvetica,Tahoma,Verdana>I&#37;YR</font></td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600"><font size=1 color="#ffffff" face=Arial,Helvetica,Tahoma,Verdana>PV</font></td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600"><font size=1 color="#ffffff" face=Arial,Helvetica,Tahoma,Verdana>PMT</font></td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600"><font size=1 color="#ffffff" face=Arial,Helvetica,Tahoma,Verdana>FV</font></td>';
		tmpStr = tmpStr + '<td align=center width=36 bgcolor="#666600">&nbsp;</td>';
		tmpStr2 = '<font size=1 color=#313100 face=Arial,Helvetica,Tahoma,Verdana><b>TVM</b></font>&nbsp;<font size=1 color=#ABAB79 face=Arial,Helvetica,Tahoma,Verdana><b>DAY</b></font>';
		break;
	case "tim":
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600"><font size=1 color="#ffffff" face=Arial,Helvetica,Tahoma,Verdana>Dt 1</font></td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600"><font size=1 color="#ffffff" face=Arial,Helvetica,Tahoma,Verdana>Dt 2</font></td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600"><font size=1 color="#ffffff" face=Arial,Helvetica,Tahoma,Verdana>DAY</font></td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600">&nbsp;</td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#666600">&nbsp;</td>';
		tmpStr = tmpStr + '<td align=center width=36 bgcolor="#666600">&nbsp;</td>';
		tmpStr2 = '<font size=1 color=#ABAB79 face=Arial,Helvetica,Tahoma,Verdana><b>TVM</b></font>&nbsp;<font size=1 color=#313100 face=Arial,Helvetica,Tahoma,Verdana><b>DAY</b></font>';
		break;
	default:
		//tmpStr = tmpStr + '<td align=center width=196 bgcolor="#cccc99">&nbsp;</td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#BBBB8C">&nbsp;</td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#BBBB8C">&nbsp;</td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#BBBB8C">&nbsp;</td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#BBBB8C">&nbsp;</td>';
		tmpStr = tmpStr + '<td align=center width=32 bgcolor="#BBBB8C">&nbsp;</td>';
		tmpStr = tmpStr + '<td align=center width=36 bgcolor="#BBBB8C">&nbsp;</td>';
		tmpStr2 = '<font size=1 color=#ABAB79 face=Arial,Helvetica,Tahoma,Verdana><b>TVM</b></font>&nbsp;<font size=1 color=#ABAB79 face=Arial,Helvetica,Tahoma,Verdana><b>DAY</b></font>';
	}
	tmpStr = tmpStr + '</tr></table>';
	MM_setTextOfLayer("LCD2","",tmpStr);
	MM_setTextOfLayer("LCD3","",tmpStr2);
}

function ToggleTVM(){
	switch(tvm){
	case "":
		tvm = "tvm";
		break;
	case "tvm":
		tvm = "tim";
		break;
	case "tim":
		tvm = "";
		break;
	}
	SetLCD2();
}

/*
function ShowSPad(){
	if(spadWin==null || spadWin=="" || spadWin.closed){
		if(navigator.appName=="Netscape"){
			spadWin = window.open("fcalspad.htm","spadWin","width=390,height=200,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0");
		}else{
			spadWin = window.open("fcalspad.htm","spadWin","width=367,height=194,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0");
		}
	}else{
		spadWin.focus();
	}
}
*/

function ShowHelp(){
window.open("calculator_help.pdf","helpWin","width=800,height=600,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=1,top=0,left=0");
	/*if(helpWin==null || helpWin=="" || helpWin.closed){
		//helpWin = window.open("fcalhelp.htm","helpWin","width=250,height=275,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=1");
		helpWin = window.open("calculator_help.pdf","helpWin","width=800,height=600,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=1,top=0,left=0");
	}else{
		helpWin.focus();
	}*/
	helpWin=null
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}

function MM_setTextOfLayer(objId,x,newText) { //v9.0
  with (document) if (getElementById && ((obj=getElementById(objId))!=null))
    with (obj) innerHTML = unescape(newText);
}

function ToDoOnClose(){
	if(!(spadWin=="" || spadWin==null || spadWin.closed))spadWin.close();
	if(!(helpWin=="" || helpWin==null || helpWin.closed))helpWin.close();
	opener.parent.codeFrame.resetPopVars();
	
}

//----------Set up keypress capture-----------
function check_keypress (e)
{
	var keycode = ( window.Event ) ? e.which : event.keyCode;
	var zero_key = 48;
	var nine_key = 57;
	var decimal_key = 46;
	var C_key = 32;
	var plus_key = 43;
	var minus_key = 45;
	var multiply_key = 42;
	var divide_key = 47;
	var cr_key = 13;
	var equals_key = 61;

	// CONVERT CHARACTER KEYS TO UPPER CASE
	if ( keycode >= 97 && keycode <= 122 )
		keycode -= 32;

	if ( keycode >= zero_key && keycode <= nine_key ){
		var Num = keycode - zero_key;
		AddDigit ( Num.toString() );
		return ( false );
	}else if ( keycode == decimal_key ){
		AddDigit ( "cdecimal" );
		return ( false );
	}else if ( keycode == equals_key || keycode == cr_key ){
		AddOperation ( "cequal" );
		return ( false );
	}else if ( keycode == plus_key ){
		AddOperation ( "cadd" );
		return ( false );
	}else if ( keycode == minus_key ){
		AddOperation ( "csubtract" );
		return ( false );
	}else if ( keycode == multiply_key ){
		AddOperation ( "cmultiply" );
		return ( false );
	}else if ( keycode == divide_key ){
		AddOperation ( "cdivide" );
		return ( false );
	}else if ( keycode == C_key ){
		ClearAll();
		return ( false );
	}

	return ( true );
}

document.onkeypress = check_keypress;

isLoaded = true;