
function classAICC(strMode){
	strDebugInfo = "Initializing AICC objects...";
	this.strMode = strMode;
	this.Initialize = funcInitialize;
	this.Finish = funcFinish;
	this.CommitData = funcCommitData;
	this.Student_ID = funcGetStudentID;
	this.Student_Name = funcGetStudentName;
	this.Output_File = funcSetOutputFile;
	this.Lesson_Location = funcLessonLocation;
	this.Credit = funcGetCredit;
	this.Lesson_Status = funcLessonStatus;
	this.Completion_Status = funcCompletionStatus; // added for SCORM 2004
	this.Success_Status = funcSuccessStatus; // added for SCORM 2004
	this.Exit = funcExit;
	this.Entry = funcGetEntry;
	this.File_Path = funcPath;
	this.Score = funcScore;
	this.Time = funcTime;
	this.Suspend_Data = funcSuspendData;
	this.Launch_Data = funcGetLaunchData;
	this.SendInteraction = funcSendInteraction;
	this.GetLearnerResponse = funcGetLearnerResponse;
	this.GetLastError = funcGetLastError;
	this.GetErrorString = funcGetErrorString;
	this.GetDiagnostic = funcGetDiagnostic;
	this.lastError = 0;
	this.errorString = ""
	this.diagnostic = "";
	strDebugInfo = "AICC objects initialized";
}


function funcInitialize()
{
	appendLog("Calling Inititialize("+this.strMode+")");
	switch(this.strMode)
	{
		case "STA": // Stand-alone mode
			flgStatus = false;
			flgStatus = CallCookie(courseID+"_"+courseBID);
			break;
			//StartLoading();
		case "HACP": // HTTP/S mode
			appendLog("Initializing HACP mode");
			AICC_Cmd = "GetParam";
			flgStatus = false;
			callLMS();
			break;
		case "API": // API mode SCORM 1.2
			flgStatus = false;
			flgStatus = apiObject.LMSInitialize("");
			this.lastError = this.GetLastError();
			if(this.lastError == 0)
			{
				StartLoading();
			}
			else
			{
				alert("Error received from LMS. \n(1) LMSInitialize failed. \nError string: " + this.errorString);
			}
			break;
		case "API2": // API mode SCORM 2004
		/*var result = "";
		
			try
			{
				result = apiObject.Initialize("");
			
}
			catch(err)
			{
				if(confirm('Alert: LMS initialization failed!\n\nYou can choose to try again using a different browser or continue this session. If you choose to continue, the results will not be sent back to the LMS but you will be able to see your results at the end and also have the option to download your responses.\n\nSelect Ok to continue. Select Cancel to end this session.'))
				{
					this.strMode = "STA";
					flgStatus = false;
					flgStatus = CallCookie(courseID+"_"+courseBID);
					StartLoading();
				}else
				{
					parent.window.location.replace("exitmsg.htm");
				}
				break;
			}
			
			if(result == "true")
			{
				StartLoading();
			}
			else
			{
				this.lastError = this.GetLastError();
				alert("Error received from LMS. \n(1) Initialize failed. \nError string: " + this.errorString);
			}*/
			StartLoading();

			break;
	}
}

function funcFinish()
{
	appendLog("Calling Finish");
	switch(this.strMode)
	{
		case "STA":
			flgStatus = false;
			flgStatus = populateAICC_Data();
			flgStatus = false;
			flgStatus = createCookie(courseID+"_"+courseBID);
			break;
		case "HACP":
			if(AICC_Cmd == "ExitAU") return;
			flgStatus = this.CommitData();
			AICC_Cmd = "ExitAU";
			appendLog("ExitAU set");
			if(exitCalled)
			{
				timeoutid1 = setTimeout("CheckForData();",500);
			}
			else
			{
				var cdt1 = new Date();
				var cdt2 = new Date();
				do
				{
					cdt2 = new Date();
				}
				while(cdt2-cdt1<2000);
				CallExit();
			}
			break;
		case "API":
			flgStatus = false;
			flgStatus = apiObject.LMSFinish("");
			//this.lastError = this.GetLastError();
			break;
		case "API2":
			if(apiObject.Terminate("") == "false")
			{
				this.lastError = this.GetLastError();
				alert("Error received from LMS. \n(2) Terminate failed. \nError string: " + this.errorString);
			}
			break;

	}
	if(debugmode == "true")
	{
		wrtToDebugWin();
		wrtToDebugLogWin();
	}
}

function funcCommitData()
{
	appendLog("Calling Commit");
	switch(this.strMode)
	{
		case "STA":
			flgStatus = false;
			flgStatus = populateAICC_Data();
			flgStatus = false;
			flgStatus = createCookie(courseID+"_"+courseBID);
			break;
		case "HACP":
			flgStatus = false;
			flgStatus = populateAICC_Data();
			AICC_Cmd = "PutParam";
			flgStatus = false;
			flgStatus = callLMS();
			break;
		case "API":
			flgStatus = false;
			flgStatus = apiObject.LMSCommit("");
			this.lastError = this.GetLastError();
			break;
		case "API2":
			if(apiObject.Commit("") == "false")
			{
				this.lastError = this.GetLastError();
				alert("Error received from LMS. \n(3) Commit failed. \nError string: " + this.errorString);
			}
			break;
	}
	if(debugmode == "true")
	{
		wrtToDebugWin();
		wrtToDebugLogWin();
	}
}

function funcGetStudentID()
{
	appendLog("Calling GetStudentID");
	switch(this.strMode)
	{
		case "STA":
			return getDataFrmArray(AICC_CorDTArr, "student_id");
			break;
		case "HACP":
			return getDataFrmArray(AICC_CorDTArr, "student_id");
			break;
		case "API":
			setDataToArray(AICC_CorDTArr, "student_id", apiObject.LMSGetValue('cmi.core.student_id'));
			this.GetLastError();
			return getDataFrmArray(AICC_CorDTArr, "student_id");
			break;
		case "API2":
			var resp = apiObject.GetValue('cmi.learner_id');
			this.GetLastError();
			return resp;
			break;
	}
}

function funcGetStudentName()
{
	appendLog("Calling GetStudentName");
	switch(this.strMode)
	{
		case "STA":
			return getDataFrmArray(AICC_CorDTArr, "student_name");
			break;
		case "HACP":
			return getDataFrmArray(AICC_CorDTArr, "student_name");
			break;
		case "API":
			setDataToArray(AICC_CorDTArr, "student_name", apiObject.LMSGetValue('cmi.core.student_name'));
			this.GetLastError();
			return getDataFrmArray(AICC_CorDTArr, "student_name");
			break;
		case "API2":
			var resp = apiObject.GetValue('cmi.learner_name');
			this.GetLastError();
			return resp;
			break;
	}
}

function funcSetOutputFile()
{
	appendLog("Calling SetOutputFile");
	switch(this.strMode){
		case "STA":
			break;
		case "HACP":
			break;
		case "API":
			break;
		case "API2":
			break;
	}
}

function funcLessonLocation(param)
{
	appendLog("Calling LessonLocation("+param+")");
	switch(this.strMode)
	{
		case "STA":
			if(param == "" || param == null)
			{
				if (getDataFrmArray(AICC_CorDTArr, "lesson_location") == null || getDataFrmArray(AICC_CorDTArr, "lesson_location") == "")
				{
					return "";
				}
				else
				{
					return getDataFrmArray(AICC_CorDTArr, "lesson_location");
				}
			}
			else {setDataToArray(AICC_CorDTArr, "lesson_location", param);}
			break;
		case "HACP":
			if(param == "" || param == null){
				if (getDataFrmArray(AICC_CorDTArr, "lesson_location") == null || getDataFrmArray(AICC_CorDTArr, "lesson_location") == "") {return "";}
				else {return getDataFrmArray(AICC_CorDTArr, "lesson_location");}
			}
			else {
			setDataToArray(AICC_CorDTArr, "lesson_location", param);}
			break;
		case "API":
			if(param == "" || param == null){
				setDataToArray(AICC_CorDTArr, "lesson_location", apiObject.LMSGetValue('cmi.core.lesson_location'));
				this.GetLastError();
				return getDataFrmArray(AICC_CorDTArr, "lesson_location");
			}
			else{
				apiObject.LMSSetValue("cmi.core.lesson_location", param);
				this.GetLastError();
				setDataToArray(AICC_CorDTArr, "lesson_location",param);
			}
			break;
		case "API2":
			if(param == "" || param == null){
				var resp = apiObject.GetValue('cmi.location');
				this.GetLastError();
				return resp;
			}
			else{
				if(apiObject.SetValue("cmi.location", param) == "false"){
					this.lastError = this.GetLastError();
					alert("Error received from LMS. \n(4) SetValue(\"cmi.location\", \""+param+"\") failed. \nError string: " + this.errorString);
				}
			}
			break;
	}
}

function funcGetCredit(){
	appendLog("Calling GetCredit");
	switch(this.strMode){
		case "STA":
			return getDataFrmArray(AICC_CorDTArr, "credit");
			break;
		case "HACP":
			return getDataFrmArray(AICC_CorDTArr, "credit");
			break;
		case "API":
			setDataToArray(AICC_CorDTArr, "credit", apiObject.LMSGetValue('cmi.core.credit'));
			this.GetLastError();
			return getDataFrmArray(AICC_CorDTArr, "credit");
			break;
		case "API2":
			var resp = apiObject.GetValue('cmi.credit');
			this.GetLastError();
			return resp;
			break;
	}
}

function funcLessonStatus(param){
	appendLog("Calling LessonStatus(" + param + ")");
	switch(this.strMode){
		case "STA":
			if(param == "" || param == null){
				var tmpls = getDataFrmArray(AICC_CorDTArr, "lesson_status");
				var tmpchr = tmpls.substr(0,1).toLowerCase();
				if(tmpchr == "p")tmpls="passed";
				if(tmpchr == "f")tmpls="failed";
				if(tmpchr == "c")tmpls="completed";
				if(tmpchr == "i")tmpls="incomplete";
				if(tmpchr == "n")tmpls="not attempted";
				if(tmpchr == "b")tmpls="browsed";
				setDataToArray(AICC_CorDTArr, "lesson_status",tmpls);
				return tmpls;
			}
			else {setDataToArray(AICC_CorDTArr, "lesson_status", param);}
			break;
		case "HACP":
			if(param == "" || param == null){
				var tmpls = getDataFrmArray(AICC_CorDTArr, "lesson_status");
				var tmpchr = tmpls.substr(0,1).toLowerCase();
				if(tmpchr == "p")tmpls="passed";
				if(tmpchr == "f")tmpls="failed";
				if(tmpchr == "c")tmpls="completed";
				if(tmpchr == "i")tmpls="incomplete";
				if(tmpchr == "n")tmpls="not attempted";
				if(tmpchr == "b")tmpls="browsed";
				setDataToArray(AICC_CorDTArr, "lesson_status",tmpls);
				return tmpls;
			}
			else {setDataToArray(AICC_CorDTArr, "lesson_status", param);}
			break;
		case "API":
			if(param == "" || param == null){
				setDataToArray(AICC_CorDTArr, "lesson_status", apiObject.LMSGetValue('cmi.core.lesson_status'));
				this.GetLastError();
				return getDataFrmArray(AICC_CorDTArr, "lesson_status");
			}
			else{
				apiObject.LMSSetValue("cmi.core.lesson_status", param);
				this.GetLastError();
				setDataToArray(AICC_CorDTArr, "lesson_status", param);
			}
			break;
		case "API2":
			// Do nothing. Not required for SCORM 2004
			break;
	}
}
function funcCompletionStatus(param){ //SCORM 2004 function
	appendLog("Calling CompletionStatus(" + param + ")");
	if(param == "" || param == null){
		var resp = apiObject.GetValue("cmi.completion_status");
		this.GetLastError();
		return resp;
	}else{
		if(apiObject.SetValue("cmi.completion_status", param) == "false"){
			this.lastError = this.GetLastError();
			alert("Error received from LMS. \n(5) SetValue(\"cmi.completion_status\", \""+param+"\") failed. \nError string: " + this.errorString);
		}
	}
}
function funcSuccessStatus(param){ //SCORM 2004 function
	appendLog("Calling SuccessStatus(" + param + ")");
	if(param == "" || param == null){
		var resp = apiObject.GetValue("cmi.success_status");
		this.GetLastError();
		return resp;
	}else{
		if(apiObject.SetValue("cmi.success_status", param) == "false"){
			this.lastError = this.GetLastError();
			alert("Error received from LMS. \n(6) SetValue(\"cmi.success_status\", \""+param+"\") failed. \nError string: " + this.errorString);
		}
	}
}
function funcExit(param){
	appendLog("Calling Exit("+param+")");
	switch(this.strMode){
		case "STA":
			if(param == "" || param == null){
				if(getDataFrmArray(AICC_CorDTArr, "exit") == null || getDataFrmArray(AICC_CorDTArr, "exit") == ""){return "";}
				else{return getDataFrmArray(AICC_CorDTArr, "exit");}
			}
			else{ setDataToArray(AICC_CorDTArr, "exit", param);}
			break;
		case "HACP":
			if(param != "" && param != null){
				setDataToArray(AICC_CorDTArr, "exit", param);
			}
			break;
		case "API":
			if(param == null || param == "normal") param = "";
			apiObject.LMSSetValue("cmi.core.exit", param);
			this.GetLastError();
			setDataToArray(AICC_CorDTArr, "exit", param);
			break;
		case "API2":
			if(param == null) param = "";
			if(apiObject.SetValue("cmi.exit", param) == "false"){
				this.lastError = this.GetLastError();
				alert("Error received from LMS. \n(7) SetValue(\"cmi.exit\", \""+param+"\") failed. \nError string: " + this.errorString);
			}
			break;
	}
}

function funcGetEntry(){
	appendLog("Calling GetEntry");
	switch(this.strMode){
		case "STA":
			return getDataFrmArray(AICC_CorDTArr, "entry");
			break;
		case "HACP":
			return getDataFrmArray(AICC_CorDTArr, "entry");
			break;
		case "API":
			setDataToArray(AICC_CorDTArr, "entry", apiObject.LMSGetValue('cmi.core.entry'));
			this.GetLastError();
			return getDataFrmArray(AICC_CorDTArr, "entry");
			break;
		case "API2":
			var resp = apiObject.GetValue('cmi.entry');
			this.GetLastError();
			return resp;
			break;
	}
}

function funcPath(){
	appendLog("Calling Path");
	switch(this.strMode){
		case "STA":
			break;
		case "HACP":
			break;
		case "API":
			break;
	}
}

function funcScore(param){
	appendLog("Calling Score("+param+")");
	switch(this.strMode){
		case "STA":
			if(param == "" || param == null){
				if(getDataFrmArray(AICC_CorDTArr, "score") == null || getDataFrmArray(AICC_CorDTArr, "score") == ""){return "";}
				else{return getDataFrmArray(AICC_CorDTArr, "score");}
			}
			else {setDataToArray(AICC_CorDTArr, "score", param);}
			break;
		case "HACP":
			if(param == "" || param == null){
				if(getDataFrmArray(AICC_CorDTArr, "score") == null || getDataFrmArray(AICC_CorDTArr, "score") == ""){return "";}
				else{return getDataFrmArray(AICC_CorDTArr, "score");}
			}
			else {setDataToArray(AICC_CorDTArr, "score", param);}
			break;
		case "API":
			if(param == "" || param == null){
				setDataToArray(AICC_CorDTArr, "score_raw", apiObject.LMSGetValue('cmi.core.score.raw'));
				setDataToArray(AICC_CorDTArr, "score_max", apiObject.LMSGetValue('cmi.core.score.max'));
				setDataToArray(AICC_CorDTArr, "score_min", apiObject.LMSGetValue('cmi.core.score.min'));
				this.GetLastError();
				return getDataFrmArray(AICC_CorDTArr, "score_raw") + "," + getDataFrmArray(AICC_CorDTArr, "score_max") + "," + getDataFrmArray(AICC_CorDTArr, "score_min");
			}
			else{
				tmpscores = param.split(",");
				apiObject.LMSSetValue("cmi.core.score.raw", tmpscores[0]);
				apiObject.LMSSetValue("cmi.core.score.max", tmpscores[1]);
				apiObject.LMSSetValue("cmi.core.score.min", tmpscores[2]);
				setDataToArray(AICC_CorDTArr, "score_raw", tmpscores[0]);
				setDataToArray(AICC_CorDTArr, "score_max", tmpscores[1]);
				setDataToArray(AICC_CorDTArr, "score_min", tmpscores[2]);
				this.GetLastError();
			}
			break;
		case "API2":
			if(param == "" || param == null)
			{
				var resp1 = apiObject.GetValue('cmi.score.raw').split(".")[0];
				var resp2 = apiObject.GetValue('cmi.score.max').split(".")[0];
				var resp3 = apiObject.GetValue('cmi.score.min').split(".")[0];
				this.GetLastError();
				return resp1 + "," + resp2 + "," + resp3;
			}
			else
			{
				tmpscores = param.split(",");
				if(apiObject.SetValue("cmi.score.raw", (tmpscores[0]==""||tmpscores[0]==null)?"0.0":((tmpscores[0].indexOf(".")!=-1)?tmpscores[0]:tmpscores[0]+".0")) == "false")
				{
					this.lastError = this.GetLastError();
					alert("Error received from LMS. \n(8) SetValue(\"cmi.score.raw\", \""+(tmpscores[0]==""||tmpscores[0]==null)?"0.0":((tmpscores[0].indexOf(".")!=-1)?tmpscores[0]:tmpscores[0]+".0")+"\") failed. \nError string: " + this.errorString);
				}
				if(apiObject.SetValue("cmi.score.max", (tmpscores[1]==""||tmpscores[1]==null)?"0.0":((tmpscores[1].indexOf(".")!=-1)?tmpscores[1]:tmpscores[1]+".0")) == "false"){
					this.lastError = this.GetLastError();
					alert("Error received from LMS. \n(9) SetValue(\"cmi.score.max\", \""+(tmpscores[1]==""||tmpscores[1]==null)?"0.0":((tmpscores[1].indexOf(".")!=-1)?tmpscores[1]:tmpscores[1]+".0")+"\") failed. \nError string: " + this.errorString);
				}
				if(apiObject.SetValue("cmi.score.min", (tmpscores[2]==""||tmpscores[2]==null)?"0.0":((tmpscores[2].indexOf(".")!=-1)?tmpscores[2]:tmpscores[2]+".0")) == "false"){
					this.lastError = this.GetLastError();
					alert("Error received from LMS. \n(10) SetValue(\"cmi.score.min\", \""+(tmpscores[2]==""||tmpscores[2]==null)?"0.0":((tmpscores[2].indexOf(".")!=-1)?tmpscores[2]:tmpscores[2]+".0")+"\") failed. \nError string: " + this.errorString);
				}
			}
			break;
	}
}

function funcTime(param)
{
	appendLog("Calling Time("+param+")");
	switch(this.strMode)
	{
		case "STA":
			if(param == "" || param == null)
			{
				if(getDataFrmArray(AICC_CorDTArr, "time") == null || getDataFrmArray(AICC_CorDTArr, "time") == "")
				{
					return "0000:00:00";
				}
				else
				{
					return getDataFrmArray(AICC_CorDTArr, "time");
					}
			}
			else
			{
				setDataToArray(AICC_CorDTArr, "time", param);
			}
			break;
		case "HACP":
			if(param == "" || param == null)
			{
				if(getDataFrmArray(AICC_CorDTArr, "time") == null || getDataFrmArray(AICC_CorDTArr, "time") == ""){return "0000:00:00";
				}
				else{return getDataFrmArray(AICC_CorDTArr, "time");
				}
			}
			else {setDataToArray(AICC_CorDTArr, "time", param);}
			break;
		case "API":
			if(param == "" || param == null){
				setDataToArray(AICC_CorDTArr, "time", apiObject.LMSGetValue('cmi.core.session_time'));
				this.GetLastError();
				return getDataFrmArray(AICC_CorDTArr, "time");
			}
			else{
				apiObject.LMSSetValue("cmi.core.session_time", param);
				setDataToArray(AICC_CorDTArr, "time", param);
				this.GetLastError();
			}
			break;
		case "API2":
			if(param == "" || param == null){
				var resp = apiObject.GetValue('cmi.session_time');
				this.GetLastError();
				return resp;
			}
			else{
				if(apiObject.SetValue("cmi.session_time", param) == "false"){
					this.lastError = this.GetLastError();
					alert("Error received from LMS. \n(11) SetValue(\"cmi.session_time\", \""+param+"\") failed. \nError string: " + this.errorString);
				}
			}
			break;
	}
}

function funcSuspendData(param){
	appendLog("Calling SuspendData("+param+")");
	switch(this.strMode){
		case "STA":
			if(param == "" || param == null) return AICC_LesDT;
			else AICC_LesDT = param;
			break;
		case "HACP":
			if(param == "" || param == null) return AICC_LesDT;
			else AICC_LesDT = param;
			break;
		case "API":
			if(param == "" || param == null){
				AICC_LesDT = apiObject.LMSGetValue("cmi.suspend_data");
				this.GetLastError();
				return AICC_LesDT;
			}else{
				apiObject.LMSSetValue("cmi.suspend_data", param);
				this.GetLastError();
				AICC_LesDT = param;
			}
			break;
		case "API2":
			if(param == "" || param == null){
				var resp = apiObject.GetValue("cmi.suspend_data");
				this.GetLastError();
				return resp;
			}else{
				if(apiObject.SetValue("cmi.suspend_data", param) == "false"){
					this.lastError = this.GetLastError();
					alert("Error received from LMS. \n(12) SetValue(\"cmi.suspend_data\", \""+param+"\") failed. \nError string: " + this.errorString);
				}
			}
			break;
	}
}

function funcGetLaunchData(){
	appendLog("Calling GetLaunchData");
	switch(this.strMode){
		case "STA":
			if(AICC_CorVE == null || AICC_CorVE == ""){ // For BS: If launchdata is null, return the static exit page.
				return "scoexitpage=exitmsg.htm"
			}else{
				return AICC_CorVE;
			}
			break;
		case "HACP":
			if(AICC_CorVE == null || AICC_CorVE == ""){ // For BS: If launchdata is null, return the static exit page.
				return "scoexitpage=exitmsg.htm"
			}else{
				return AICC_CorVE;
			}
			break;
		case "API":
			AICC_CorVE = apiObject.LMSGetValue("cmi.launch_data");
			this.GetLastError();
			if(AICC_CorVE == null || AICC_CorVE == ""){ // For BS: If launchdata is null, return the static exit page.
				return "scoexitpage=exitmsg.htm"
			}else{
				return AICC_CorVE;
			}
			break;
		case "API2":
			var resp = apiObject.GetValue("cmi.launch_data");
			this.GetLastError();
			if(resp == null || resp == ""){ // For BS: If launchdata is null, return the static exit page.
				return "scoexitpage=exitmsg.htm"
			}else{
				return resp;
			}
			break;
	}
}
function funcSendInteraction(n,id,result,desc,type,resp){
	/* For BS: If SCO is launched from Brightspace strip mathemetical symbols
		from the id as they might throw errors.                       */
	if(top.D2L){id = id.replace(/[*+\-=.\/]/gi, '_')}

	appendLog("Calling SendInteraction: "+n+", "+id+", "+result+", "+desc+", "+type+", "+resp);
	switch(this.strMode){
		case "API":
			if(result == "incorrect") result = "wrong";
			apiObject.LMSSetValue("cmi.interactions."+n+".id", id);
			this.GetLastError();
			apiObject.LMSSetValue("cmi.interactions."+n+".result", result);
			this.GetLastError();
			if(type == "long-fill-in"){
				apiObject.LMSSetValue("cmi.interactions."+n+".type ", "fill-in");
				this.GetLastError();
				apiObject.LMSSetValue("cmi.interactions."+n+".student_response ", resp);
				this.GetLastError();
			}
			break;
		case "API2":
			if(apiObject.SetValue("cmi.interactions."+n+".id", id) == "false"){
				this.lastError = this.GetLastError();
				alert("Error received from LMS. \n(13) SetValue(\"cmi.interactions."+n+".id\", \""+id+"\") failed. \nError string: " + this.errorString);
			}
			if(apiObject.SetValue("cmi.interactions."+n+".result", result) == "false"){
				this.lastError = this.GetLastError();
				alert("Error received from LMS. \n(14) SetValue(\"cmi.interactions."+n+".result\", \""+result+"\") failed. \nError string: " + this.errorString);
			}
			if(desc != null && desc != ""){ // For BS: If desc is empty don't send it
				if(apiObject.SetValue("cmi.interactions."+n+".description", desc) == "false"){
					this.lastError = this.GetLastError();
					alert("Error received from LMS. \n(15) SetValue(\"cmi.interactions."+n+".description\", \""+desc+"\") failed. \nError string: " + this.errorString);
				}
			}
			if(type == "long-fill-in"){
				if(apiObject.SetValue("cmi.interactions."+n+".type", type) == "false"){
					this.lastError = this.GetLastError();
					alert("Error received from LMS. \n(16) SetValue(\"cmi.interactions."+n+".type\", \""+type+"\") failed. \nError string: " + this.errorString);
				}
				if(apiObject.SetValue("cmi.interactions."+n+".learner_response", resp) == "false"){
					this.lastError = this.GetLastError();
					alert("Error received from LMS. \n(17) SetValue(\"cmi.interactions."+n+".learner_response\", \""+resp+"\") failed. \nError string: " + this.errorString);
				}
			}
			break;
	}
}
function funcGetLearnerResponse(n){
	appendLog("Calling GetLearnerResponse: "+n);
	switch(this.strMode){
		case "API":
			var sresponse = apiObject.LMSGetValue("cmi.interactions."+n+".student_response ");
			this.GetLastError();
			return sresponse;
			break;
		case "API2":
			var sresponse = apiObject.GetValue("cmi.interactions."+n+".learner_response");
			this.lastError = this.GetLastError();
			//alert("Error received from LMS. \n(18) GetValue(\"cmi.interactions."+n+".learner_response\") failed. \nError string: " + this.errorString);
			return sresponse;
			break;
	}
}
function funcGetLastError()
{
	appendLog("Calling GetLastError");
	switch(this.strMode){
		case "STA":
			break;
		case "HACP":
			break;
		case "API":
			var lerror = Number(apiObject.LMSGetLastError());
			setDataToArray(AICC_ErrArr, "error", lerror);
			if(lerror != 0)
			{
				appendLog("Error received from LMS. " + lerror);
				this.errorString = this.GetErrorString(lerror);
				this.diagnostic = this.GetDiagnostic(lerror);
			}
			return getDataFrmArray(AICC_ErrArr, "error");
			break;
		case "API2":
			var lerror = Number(apiObject.GetLastError());
			if(lerror != 0){
				appendLog("Error received from LMS. " + lerror);
				this.errorString = this.GetErrorString(lerror);
				this.diagnostic = this.GetDiagnostic(lerror);
			}
			return lerror;
			break;
	}
}
function funcGetErrorString(errornum)
{
	appendLog("Calling GetErrorString");
	switch(this.strMode)
	{
		case "STA":
			break;
		case "HACP":
			break;
		case "API":
			var lerrorstr = apiObject.LMSGetErrorString(errornum);
			appendLog("Error String: " + lerrorstr);
			setDataToArray(AICC_ErrArr, "error_string", lerrorstr);
			return getDataFrmArray(AICC_ErrArr, "error_string");
			break;
		case "API2":
			var lerrorstr = apiObject.GetErrorString(errornum);
			appendLog("Error String: " + lerrorstr);
			return lerrorstr;
			break;
	}
}
function funcGetDiagnostic(errornum)
{
	appendLog("Calling GetDiagnostic");
	switch(this.strMode)
	{
		case "STA":
			break;
		case "HACP":
			break;
		case "API":
			var ldiagstr = apiObject.LMSGetDiagnostic(errornum);
			appendLog("Error Diagnostic: " + ldiagstr);
			setDataToArray(AICC_ErrArr, "error_diagnostic", ldiagstr);
			return getDataFrmArray(AICC_ErrArr, "error_diagnostic");
			break;
		case "API2":
			var ldiagstr = apiObject.GetDiagnostic(errornum);
			appendLog("Error Diagnostic: " + ldiagstr);
			return ldiagstr;
			break;
	}
}
///////////////////////////////
