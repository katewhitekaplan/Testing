/*
 * Copyright (c) 2011 Kaplan, Inc. All rights reserved.
*/
 
function LearnerDataObject()
{
	this.launchData = "";
	this.studentName = "";
	this.lesson = "";
	this.progress = "";
	this.lastVisited = "";
	this.GetVal = GetVal;
	this.bookmarkString = "";
	this.testData = "";
	this.courseStatus = "incomplete";
	this.completionStatus = "not attempted";
	this.successStatus = "unknown";
	this.Time = "0000:00:00";
	this.score = "";
	this.finalScore = "";
	this.Set = Set;
	this.Get = Get;
	this.InitLearnerData = InitLearnerData;
	this.InitTestData = InitTestData;
	//this.SetBookmark = SetBookmark;
	this.GetBookmark = GetBookmark;
	this.SetResponse = SetResponse;
	this.GetResponse = GetResponse;
	this.SetProgress = SetProgress;
	this.GetProgress = GetProgress;
	this.GetScore = GetScore;
	this.SetScore = SetScore;
	this.GetQuestionSequence = GetQuestionSequence;
	this.SetCourseCompletion = SetCourseCompletion;
	this.GetFinalScore = GetFinalScore;
	this.SetCustomExamData = SetCustomExamData;
	this.GetCustomExamData = GetCustomExamData;
	this.GetTestResponses = GetTestResponses;
	this.courseID = "";
	this.timeLimit = "";
	this.sequence = "";
	this.answered = "";
	this.notAttempted = "";
	this.markedForReview = "";
	this.e2TrainData = "";
	this.customExamData = "";
}
function GetVal()
{
	return this.progress + "~" + this.score + "~" + this.testData + "~" + this.lastVisited + "~" + this.customExamData + "~" + this.completionStatus;;
}
function Set()
{
	objAICC.Lesson_Location(this.bookmarkString);
	if(objAICC.strMode == "API2")
	{
		this.e2TrainData = "TimeLimit="+this.timeLimit+"&Sequence="+this.sequence+"&Answered="+this.answered+"&NotAttempted="+this.notAttempted+"&MarkedForReview="+this.markedForReview+"&SCOData="+this.GetVal();
		//alert(this.e2TrainData)
		objAICC.Suspend_Data(this.e2TrainData);
	}
	else
	{
		objAICC.Suspend_Data(this.GetVal());
	}
	if(objAICC.strMode == "API2")
	{
		if(justLaunched){
			objAICC.Completion_Status("not attempted");
		}else{
			objAICC.Completion_Status(this.completionStatus);
		}
		if(this.successStatus != "unknown")
		{
			objAICC.Score(this.finalScore);
			objAICC.Success_Status(this.successStatus);
		}
	}
	else
	{
		objAICC.Score(this.finalScore);
		objAICC.Lesson_Status(this.courseStatus);
	}
	objAICC.Time(this.Time); 
}
function Get()
{
	this.studentName = objAICC.Student_Name();
	if(this.studentName.indexOf(",") != -1)
	{
		var tmpName = this.studentName.split(",");
		this.studentName = tmpName[1] + " " + tmpName[0];
	}
	this.bookmarkString = objAICC.Lesson_Location();
	if(objAICC.strMode == "API2")
	{
		this.e2TrainData = objAICC.Suspend_Data();
		var tmpSD = GetParamValue("SCOData",this.e2TrainData.split("&"), "=")
	}
	else
	{
		var tmpSD = objAICC.Suspend_Data();
	}
	if(tmpSD!=null && tmpSD!="")
	{
		tmpSDArray = tmpSD.split("~");;
		this.progress = tmpSDArray[0];
		this.score = tmpSDArray[1];
		this.testData = tmpSDArray[2];
		this.lastVisited = tmpSDArray[3];
		this.customExamData = tmpSDArray[4];
		this.completionStatus = tmpSDArray[5];
	}
	if(objAICC.strMode == "API2")
	{
		//this.completionStatus = objAICC.Completion_Status();
		this.successStatus = objAICC.Success_Status();
	}
	else
	{
		var temp = objAICC.Lesson_Status();
		if(temp != "passed" && temp != "failed" && temp != "completed")
		{
			this.courseStatus = "incomplete";
		}
		else
		{
			this.courseStatus = temp;
		}
	}
	this.launchData = objAICC.Launch_Data();
	this.finalScore = objAICC.Score();
}
function InitLearnerData(tunits)
{
	var bkstr = "";
	var pgstr = "";
	var scstr = "";
	var tdstr = "";
	var tlessons;
	for(var i=0; i<tunits.length; i++){
		tlessons = tunits[i].getElementsByTagName("lesson");
		for(var j=0; j<tlessons.length; j++){
			bkstr = bkstr + "-1,";
			pgstr = pgstr + ",,,;";
			scstr = scstr + ",,,,,,,;";
			tdstr = tdstr + ";";
		}
		bkstr = bkstr + "]";
		pgstr = pgstr + "]";
		scstr = scstr + "]";
		tdstr = tdstr + "]";
	}
	this.bookmarkString = bkstr;
	this.testData = tdstr;
	this.progress = pgstr;
	this.score = scstr;
	this.lastVisited = "";
	this.customExamData = "";
}
function InitTestData(koarray, u, l)
{
	var uarray = this.testData.split("]");
	var larray = uarray[u].split(";");
	var tmpArray = new Array();
	for(i=0;i<koarray.length;i++){
			tmpArray[i] = koarray[i] + "::::";
 	}
	larray[l] = tmpArray.join(",");
	uarray[u] = larray.join(";");
	this.testData = uarray.join("]");
}

/*
function SetBookmark(u,l,f)
{
	var units = this.bookmarkString.split("]");
	var lessons = units[u].split(",");
	lessons[l] = f;
	units[u] = lessons.join(",");
	this.bookmarkString = units.join("]");
}
*/
function GetBookmark(u,l)
{
	if(this.bookmarkString != "")
	{
		var units = this.bookmarkString.split("]");
		var lessons = units[u].split(",");
		return Number(lessons[l]);
	}
	else
	{
		return -1;
	}
}
function SetResponse(qid,response,whethercorrect,prevalue,u,l,check_review_page)
{
	var uarray = this.testData.split("]");
	var larray = uarray[u].split(";");
	var responseArray = larray[l].split(",");
	for(i=0;i<responseArray.length;i++){
		if(responseArray[i].split(":")[0] == qid)
		{
			responseArray[i] = qid +":"+ response+":"+ whethercorrect+":"+prevalue+":"+check_review_page;			
		}
	}
	larray[l] = responseArray.join(",");
	uarray[u] = larray.join(";");
	this.testData = uarray.join("]");
}
function GetResponse(qid,u,l)
{
	var uarray = this.testData.split("]");
	var larray = uarray[u].split(";");
	var responseArray = larray[l].split(",");
	var response = null;
	for(i=0;i<responseArray.length;i++)
	{
		response = responseArray[i].split(":");
		if(response[0] == qid)
		{
			return response;
		}
	}
}
function SetProgress(completion,examresult,where,examtime,completiondate,u,l)
{
	var uarray = this.progress.split("]");
	var larray = uarray[u].split(";");
	larray[l] = completion +","+ examresult+","+ where + "," + examtime + "," + completiondate;
	uarray[u] = larray.join(";");
	this.progress = uarray.join("]");
}
function GetProgress(u,l)
{
	var uarray = this.progress.split("]");
	var larray = uarray[u].split(";");
	return larray[l].split(",");
}
function SetScore(mode,passpercent,numcorrect,numattempted,totalquestions,percentcorrect,examtime,examdate,u,l)
{
	var uarray = this.score.split("]");
	var larray = uarray[u].split(";");
	larray[l] = mode + "," + passpercent + "," + numcorrect + "," + numattempted + "," + totalquestions + "," + percentcorrect + "," + examtime + "," + examdate;
	uarray[u] = larray.join(";");
	this.score = uarray.join("]");
	if(mode == "exam mode")
	{
		var tmpscore = this.finalScore.split(",");
		//if(tmpscore == null || tmpscore == "" || (percentcorrect >= Number(tmpscore[0]))){ 
		this.finalScore = percentcorrect  + ",100,0";
		//}
	}
}
function GetScore(u,l)
{
	var uarray = this.score.split("]");
	var larray = uarray[u].split(";");
	return larray[l].split(",");
}
function GetQuestionSequence(u,l)
{
	var uarray = this.testData.split("]");
	var larray = uarray[u].split(";");
	var qarray = larray[l].split(",");
	var seqArray = new Array();
	for(var i=0;i<qarray.length;i++){
		seqArray[i] = qarray[i].split(":")[0];
	}
	return seqArray;
}
function SetCourseCompletion(completionstr)
{
	this.courseStatus = completionstr;
}
function GetFinalScore()
{
	return this.finalScore.split(",")[0];
}
function SetCustomExamData(totalquestions, timed, testduration)
{
	this.customExamData = totalquestions + ":" + timed + ":" + testduration;
}
function GetCustomExamData()
{
	return this.customExamData.split(":");
}
function GetTestResponses(u,l)
{
	var uarray = this.testData.split("]");
	var larray = uarray[u].split(";");
	var responseArray = larray[l].split(",");
	return responseArray;
}