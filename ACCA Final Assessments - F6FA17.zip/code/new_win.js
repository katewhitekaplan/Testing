/*
 * Copyright (c) 2011 Kaplan, Inc. All rights reserved.
*/

/* openPopup(URL, name, width, height)
 * This function checks to see if a browser's DOM supports the screen property of window, and if so,
 * establishes the center of the user's screen and adds 'left' and 'top' params to window.open's features list.
 *
 * @URL			the URL of the page that opens in this popup
 * @width		the width of the popup
 * @height	the height of the popup
 */
function openPopup(URL, width, height) 
{
		if (window.screen) {
			var left = (screen.width - width) / 2;
			var top = (screen.height - height) / 2;
			var screenPosition = 'left=' + left + ',top=' + top;
		}
		date = new Date();
		winName = date.getMilliseconds();
		
		thisWin = window.open(URL, winName, 'width=' + width + ',height=' + height + ',toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes' + ((screenPosition != '') ? ',' + screenPosition : ''));
}

var winCheckTimer;
function SetFocusOnThisWin()
{
		if(thisWin == null || thisWin == "" || thisWin.closed)
		{
			winCheckTimer = setTimeout("SetFocusOnThisWin()", 200);
		}		
		else
		{
			thisWin.focus();
			clearTimeout(winCheckTimer);
		}
}
function openUlinkPopup(URL, name, width, height, windowfeatures) 
{
		if (window.screen) 
		{
			var left = (screen.width - width) / 2;
			var top = (screen.height - height) / 4;
			var screenPosition = 'left=' + left + ',top=' + top;
		}
		date = new Date();
		winName = date.getMilliseconds();		
		thisWin = window.open(URL, winName, 'width=' + width + ',height=' + height + ',' + windowfeatures + ((screenPosition != '') ? ',' + screenPosition : ''));
}


function glossaryPopup(URL) 
{
	openPopup(URL, '495','375');
}

function helpPopup(URL) 
{
	var width = 738;
	var height = 630;
	
	if (window.screen) {
			var left = (screen.width - width) / 2;
			var top = (screen.height - height) / 2;
			var screenPosition = 'left=' + left + ',top=' + top;
		}
		date = new Date();
		winName = date.getMilliseconds();
		
		thisWin = window.open(URL, winName, 'width=' + width + ',height=' + height + ',toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes' + ((screenPosition != '') ? ',' + screenPosition : ''));
}

function LaunchCalculator(URL) 
{
	var width = 260;
	var height = 190;
	if (window.screen) {
			var left = (screen.width - width) / 2;
			var top = (screen.height - height) / 2;
			var screenPosition = 'left=' + left + ',top=' + top;
		}
		date = new Date();
		winName = date.getMilliseconds();
		
		thisWin = window.open(URL, winName, 'width=' + width + ',height=' + height + ',screenX=0,screenY=100,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no' + ((screenPosition != '') ? ',' + screenPosition : ''));
}




function ulinkPopup(URL, name, width, height, windowfeatures) {
	var winprops = windowfeatures.split(",");
	var prop = null;
	for(var i=0;i<winprops.length;i++){
		prop = winprops[i].split("=");
		if(prop[1] == "") prop[1] = "yes";
		if(prop[1] == "true") prop[1] = "yes";
		if(prop[1] == "false") prop[1] = "no";
		winprops[i] = prop.join("=");
	}
	windowfeatures = winprops.join(",");
	openUlinkPopup(URL, name, width, height, windowfeatures);
}

function explanationPopup(URL) {
	openPopup(URL,'495','375');
}

function sectionReferencePopup(URL) {
	openPopup(URL,'495','375');
}
																																																																																													
function keyPopup(URL) {
	openPopup(URL,'495','375');
}

function referencePopup(URL) {
	var width = 500;
	var height = 400;
	if (window.screen) {
			var left = (screen.width - width) / 2;
			var top = (screen.height - height) / 2;
			var screenPosition = 'left=' + left + ',top=' + top;
		}
		date = new Date();
		winName = date.getMilliseconds();
		
		thisWin = window.open(URL, winName, 'width=' + width + ',height=' + height + ',toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no' + ((screenPosition != '') ? ',' + screenPosition : ''));
}


function ScratchpadPopup(URL) {
	var width = 500;
	var height = 400;
	if (window.screen) {
			var left = (screen.width - width) / 2;
			var top = (screen.height - height) / 2;
			var screenPosition = 'left=' + left + ',top=' + top;
		}
		date = new Date();
		winName = date.getMilliseconds();
		
		thisWin = window.open(URL, winName, 'width=' + width + ',height=' + height + ',toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no' + ((screenPosition != '') ? ',' + screenPosition : ''));
}

/* height and width are pulled from the mediaAsset's xml file and passed */
function mediaPopup(URL, mediaWidth, mediaHeight) {
	var newPopupWidth;
	var offset = 0;
	if (mediaWidth < 817) {
		newPopupWidth = 817 + offset;
	} else {
		newPopupWidth = mediaWidth + offset;
	}
	if(navigator.appName.indexOf("Microsoft") >= 0){
		var popupHeight = eval(mediaHeight + 111);
	}else{
		var popupHeight = eval(mediaHeight + 124);
	}
	openPopup(URL, newPopupWidth, popupHeight);
}
function ExhibitPopup(URL)
{
	var width = 738;
	var height = 630;
	
	if (window.screen) {
			var left = (screen.width - width) / 2;
			var top = (screen.height - height) / 2;
			var screenPosition = 'left=' + left + ',top=' + top;
		}
		date = new Date();
		winName = date.getMilliseconds();
		
		thisWin = window.open(URL, winName, 'width=' + width + ',height=' + height + ',toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes' + ((screenPosition != '') ? ',' + screenPosition : ''));
}
