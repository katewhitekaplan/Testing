function roll(which, name)
{   
   which.className = name;
}
function roll1(img_name, img_src)
{
   document.images[img_name].src = img_src;
   //document.getElementById('sub_but1').src = img_src;
}  
 
//////////////////// Menu Top Button 1 /////////////////////////////////   
   

function sylabus_image_over1(top_but1)
{
	document.getElementById('top_but1').className='menu_but_over1'
}
function sylabus_image_out1(top_but1)
{
	document.getElementById('top_but1').className='menu_but_out1'
}

//////////////////// Menu Top Button 2 /////////////////////////////////   
   

function sylabus_image_over2(top_but2)
{
	document.getElementById("top_but2").className='menu_but_over2'
}
function sylabus_image_out2(top_but2)
{
	document.getElementById("top_but2").className='menu_but_out2'
}


//////////////////// Menu Top Button 3 /////////////////////////////////   
   

function sylabus_image_over3(top_but3)
{
	document.getElementById(top_but3).className='menu_but_over2'
}
function sylabus_image_out3(top_but3)
{
	document.getElementById(top_but3).className='menu_but_out2'
}

//////////////////// Menu Top Button 4 /////////////////////////////////   
   

function sylabus_image_over4(top_but4)
{
	document.getElementById(top_but4).className='menu_but_over2'
}
function sylabus_image_out4(top_but4)
{
	document.getElementById(top_but4).className='menu_but_out2'
}

//////////////////// Menu Top Button 5 /////////////////////////////////   
   

function sylabus_image_over5(top_but5)
{
	document.getElementById(top_but5).className='menu_but_over2'
}
function sylabus_image_out5(top_but5)
{
	document.getElementById(top_but5).className='menu_but_out2'
}

//////////////////// Menu Top Button 6 /////////////////////////////////   
   

function sylabus_image_over6(top_but6)
{
	document.getElementById(top_but6).className='menu_but_over2'
}
function sylabus_image_out6(top_but6)
{
	document.getElementById(top_but6).className='menu_but_out2'
}

//////////////////// Finish Button /////////////////////////////////

function sylabus_image_over2(top_but1)
{
	document.getElementById('menu_exit').className='menu_finish_over'
}
function sylabus_image_out2(top_but1)
{
	document.getElementById('menu_exit').className='menu_finish_out'
}

//////////////////// Menu Button /////////////////////////////////

function help_image_over(bottom_help)
{
	document.getElementById('bottom_help').className='menu_help_over'
}
function help_image_out(bottom_help)
{
	document.getElementById('bottom_help').className='menu_help_out'
}

//////////////////// Start Assessment /////////////////////////////////

function start_assessment_over(Assessment)
{
	document.getElementById('Assessment').className='start_assessment_over'
}
function start_assessment_out(Assessment)
{
	document.getElementById('Assessment').className='start_assessment_out'
}