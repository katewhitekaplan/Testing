/*
 * Copyright (c) 2010 Kaplan, Inc. All rights reserved.
 */
 
// Menu button methods
function CallLesson(u,l){
	parent.codeFrame.CallLesson(u, l);
}
function ShowMenuDescription(u,l){
	parent.codeFrame.ShowMenuDescription(u, l);
}
function HideMenuDescription(u,l){
	parent.codeFrame.HideMenuDescription(u, l);
}
function FlashUpdateMenuitem(u,l){
	parent.codeFrame.FlashUpdateMenuitem(u, l);
}

// Menu Back Next methods
function NavNext(){
	parent.codeFrame.NavNext();
}
function NavPrevious(){
	parent.codeFrame.NavPrevious();
}
function ButtonMenu(){
	parent.codeFrame.ButtonMenu();
}
function FlashEnableNav(){
	parent.codeFrame.FlashEnableNav();
}

// Help Exit button methods
function ButtonHelp(){
	parent.codeFrame.ButtonHelp();
}
function ButtonExit(){
	parent.codeFrame.ButtonExit();
}
// Form elements
function RadioClick(which)
{
	parent.codeFrame.RadioClick(which);
}

function FillinKeyup(which, e){
	parent.codeFrame.FillinKeyup(which, e);	
}
function FillinOnChange(which){
	parent.codeFrame.FillinOnChange(which);	
}
function AddToSum(which, namestr){
	parent.codeFrame.AddToSum(which, namestr);	
}
function SelectOnChange(which){
	parent.codeFrame.SelectOnChange(which);
}
function MakeDraggable(makedragdata){
	YUI().use('dd-drop', 'dd-proxy', 'dd-constrain', function(Y) {
	for(var m=0;m<makedragdata.length;m++){
		var ddata = makedragdata[m][0];
		var constraintdiv = makedragdata[m][1];
		var qdata = makedragdata[m][2];
		var data = ddata;
		var drags = Y.Node.all(constraintdiv+' div.dragitem');
		drags.each(function(v, k) {
			var dd = new Y.DD.Drag({
				node: v,
				dragMode: 'intersect',
				data: data[v.get('id')]
			}).plug(Y.Plugin.DDProxy, {
				moveOnEnd: false
			}).plug(Y.Plugin.DDConstrained, {
				constrain2node: constraintdiv
			})
			dd.on('drag:start', function() {
			//In this event we setup some styles to make the nodes look pretty
				var p = this.get('dragNode'),
					n = this.get('node');
					if (!this._playerStart) {
						this._playerStart = this.nodeXY;
					}
				//Put the Drag's HTML inside the proxy
				p.set('innerHTML', n.get('innerHTML'));
				//set some styles on the proxy
				p.setStyles({
					backgroundColor: n.getStyle('backgroundColor'),
					color: n.getStyle('color'),
					opacity: .85
				});
			});
	
			dd.on('drag:end', function(e) {
				e.preventDefault();
			});
		});
		var drops = Y.Node.all(constraintdiv+' span.droparea');
		drops.each(function(v, k) {
			var drop = new Y.DD.Drop({
				node: v
			});
			for(var k=0;k<qdata.length;k++){
				if((drop.get('node').get("id").indexOf(qdata[k].questionID) != -1) && (qdata[k].prevalue != "")){
					drop.get('node').set('innerHTML', qdata[k].prevalue);
				}
			}
			drop.on('drop:hit', function(e) {
				var drag = e.drag;
				document.getElementById(this.get('node').get('id')).innerHTML = drag.get('node').get('innerHTML');
				parent.codeFrame.DropOnTarget(document.getElementById(this.get('node').get('id')), drag.get('data'), drag.get('node').get('innerHTML'));
			});
		});
	}
});
}

function MakeDraggable_popup()
{
	//var td1 = parent.contentFrame.document.getElementById("styled_popup").id
	//var td2 = parent.contentFrame.document.getElementById("wrapper_page").id
	
	YUI().use('dd-constrain', function(Y) 
	{
		var dd1 = new Y.DD.Drag({
			node: '#styled_popup'
		}).plug(Y.Plugin.DDConstrained, 
		{
			constrain2node: '#wrapper_page'
		}); 
	});
}
function MakeDraggable_review_popup()
{
	//var td1 = parent.contentFrame.document.getElementById("styled_popup").id
	//var td2 = parent.contentFrame.document.getElementById("wrapper_page").id
	
	YUI().use('dd-constrain', function(Y) 
	{
		var dd1 = new Y.DD.Drag({
			node: '#QusRewiew_popup'
		}).plug(Y.Plugin.DDConstrained, 
		{
			constrain2node: '#wrapper_qus_review'
		}); 
	});
}
