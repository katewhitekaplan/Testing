var version = {"name":"ACCA Exam Player", "number":"11.0.1.AEP", "date":"17-07-2017 15:41"};
/*
 * Common player - Player files separated from content so that the player files remain common across all SCOs of one type,
 * and can be maintained at one location. The content folder contains 'content' folder with all content, SCORM xmls and schema
 * and the index.htm file that points to this folder location.
 *
 * Copyright (c) Kaplan, Inc. All rights reserved.
 *
 *Respponsive engine
 */

// Search for SCORM API
var apiObject = getAPI(2);
if (apiObject != null){
	strMode = "API2";	// SCORM 2004 API
}else{
	var apiObject = getAPI(1);
	if (apiObject != null){
		strMode = "API";	// SCORM 1.2 API
	}else{
		// Not found go into standalone (cookie) mode
		strMode = "STA";
	}
}

// STRINGS
var SUSPEND_TEST_STR  = "You will be able to resume this test from this point at a later time. If you are certain you would like to suspend this test, please confirm by clicking \"OK.\"";
var LOGOUT_STR        = "Are you sure you wish to leave the training?";
var EXIT_STR          = "Are you sure you wish to leave the training?"
var EXAMTIMEOUT_STR   = "You have exceeded the time limit for this exam. All unanswered questions will be marked incorrect.";
var IMPROPER_EXIT_STR = "All remaining questions will be marked as incorrect.";

var isIE = isSafariMobile = isSafari = isFirefox = false;

if(navigator.userAgent.search(/Edge\/\d+/) != -1){
	var isEdge = true;
}else if((navigator.userAgent.indexOf("MSIE") != -1) || (window.location.hash = !!window.MSInputMethodContext)){
	var isIE = true
}else if(navigator.userAgent.indexOf("Safari") != -1){
	if(navigator.userAgent.indexOf("Mobile") != -1){
		var isSafariMobile = true;
	}else{
		var isSafari = true;
	}
}else if(navigator.userAgent.indexOf("Firefox") != -1){
	var isFirefox = true;
}
var usingXMLHTTP = false;

//For finishing logout tasks if browser window is closed without logging out
if(window.onbeforeunload){
	window.onbeforeunload = CatchImproperExit;
}else if(window.addEventListener) {
	window.addEventListener('unload', CatchImproperExit, false);
} else if(window.attachEvent){
	window.attachEvent('onunload', CatchImproperExit);
}

//Get dimensions for sizing content areas
var winWid=1356;
var winHei=909;
var scnWid=1356;
var scnHei=909;
var topOffset = 78;
var bottomOffset = 35;
var leftAndRightMargin = 0;
var topAndBottomMargin = 0;

function AdjustUI(){
	if( typeof( parent.contentFrame.window.innerHeight ) == 'number' ) {
		scnWid = parent.contentFrame.window.innerWidth;
		scnHei = parent.contentFrame.window.innerHeight;
  }
	if(typeof(scnHei) != 'number' ){
		scnHei = winHei;
		scnWid = winWid;
	}
  var newHeight = eval(scnHei - (topOffset + bottomOffset));
	if(parent.contentFrame.document.getElementById("ques_main")){
		parent.contentFrame.document.getElementById("ques_main").style.height = newHeight + "px";
	}
}

if(window.resize){
  window.resize = function(){AdjustUI()};
}else if(window.addEventListener) {
	window.addEventListener('resize', AdjustUI);
}
if(window.addEventListener){
  window.addEventListener('orientationchange', AdjustUI);
}

// global flags
/***************** For mode type issue (sumit)**********/
var selectedLessType;

/**********/
var thisWin;
var checkReview = "";
var req;
var configObj;
var configRoot;
var categoryObj;
var xmlObj;
var xslObj;
var xmlFileName;
//--Change for common engine-------------------------//
if(parent.commonEngine){
	var enginePath = this.location.href.substr(0,this.location.href.indexOf("/code/"));
	var basePath = parent.location.href.substr(0,parent.location.href.lastIndexOf("/"));
	var contentPath = unescape(basePath) + "/content/";
	var findpath = new RegExp(/(\.\.\/content\/)/g);
}else{
	var contentPath = "../content/";
}
//parent.commonEngine = false;
//---------------------------------------------------//
var cssPath = "../css/";
var xmlPath = "../xml/";
var courseConfigFileName = "scoconfig.xml";
var welcomeFileName = "IN_welcome.xml";
var testIntroFileName = "IN_testintro.xml";
var scotimeoutpage = "timeoutmsg.htm";
var scostaticexitpage = "exitmsg.htm";
var SCOID;
var SCOTitle;
var categoryRootID = 0;
var categoryRoot;
var currentScreenNum = 0;
var currentUnit = 0;
var currentLesson = 0;
var totalScreens;
var totalUnits;
var totalLessons;
var totalQuestions;
var questionBank;
var firstScreen = 0;
var lastScreen;
var currentLessonTitle = "Welcome back!";
var currentScreenType = "mainmenu";
var currentQuestionType = "Review All";
var currentUnitObj;
var currentLessonObj;
var currentScreenObj;
var courseType;
var glossary = "Y";
var coursetimeoutduration = 120;
var courseTimer;
var	finalpassrate = 70;
var completionstrategy;
var scoexitpage;
var scocloseonexit = true;
var selectedID = "";
var selectedOptionID = "";
var lessonType = "";
var timed = "N";
var examtimeoutduration = 60;
var passpercent = 70;;
var shuffle = "Y";
var showrationale = "Y";
var rationaleatend = "N";
var categoryweighted = null;
var totalNumDeliverables = 0;
var categoryItemCount = null;
var weightedTestSequence = null;
questionsToPresent = 0;
var allowsuspend = "Y";
var refXML;
var mediaPopupData;
var studentName = "";
var sessionTime = 0;
var sessionStartTime;
var sessionEndTime;
var examTime = 0;
var examTimedOut = false;
var testQuestionSequence;
var currentExamStatus;
var currentQuestionNum;
var lessonComplete = false;
var endTest = false;
var allowend = "Y";
var	allowback = "Y";
var	allowclear = "Y";
var	aftercomponentcompletepage = "Test Complete";
var returning = false;
var contentFrameReady = false;
var referenceWindowReady = false;
var mediaWindowReady = false;
var checktimer;
var resetlevel;
var aiccFinishCalled = false;
var aiccEntry;
var courseforcredit = false;
var currentDate = GetCurrentDate("long");
var learnerData = new LearnerDataObject();
var objAICC = new classAICC(strMode);
var buttonClicked = "";
var answerTypeCD;
var examTimeRemaining;
var	timeRemainingTimer;
var answerParameters;
var maxtestsize = 100; //used for build exam screen
var categoryDistribution = new Array();
var selectedCategories = new Array();
var customTestSequence = new Array();
var newTestSequence = new Array();
var totalBuildQuestions = 0;
var customTestTimed = false;
var customTestDuration = 0;
var maxselectedquestions = 0;
var justLaunched = true;
var exitNoSave = false;
var closeOnContentError = false;
var testCompleteLock = false;
var loadingReadingPassage = false;
var tmpXmlObj = null;
var currentScreenFlag = "";
var aatQuestionJump = 0;
var questiondragitems = "";
var reviewmode = false;
var checkanswer = false;
var clearresponse = false;
var IncompleteArray = new Array();
var SelectQuestionNum = null;
var IncompleteQuestionNum = null;
var Reviewtab = 0;
var seq =0;
var clocktimer = false;
var pagenum = false;
var InstructiontextCount =0;
var feedback_queslisttxttab =0;
var Lfeedback_queslisttxttab =0;
var check_review = false;
var SetCheckedval = 0;
var flagclick = false;
var currenthighlitestring = 0;
var datasavebypagenoarr = new Array();
var Textselectionarr = new Array();
var totalQuestionsForDisplay = "";
var firstIsAat = false;
var flagAllCompleteInLong = true;
var maxScoreOfLong = 0;
var flagNavigatorMode = false;
var totalnonLongnumCorrect = 0;
var flagLeftPaneFullyScrolled = false;
var flagRightPaneFullyScrolled = false;
var flagShortQFullyScrolled = false;
var navigatorSortAsc = false;
var totalcheckedinMCMCQ = 0;
var flagAllAttempted = true;
var flagIsAAT = false;
var flagAllCorrectAATForReview = true;
var percentCorrectLongQPart = 0;
var percentCorrectNonLongQPart = 0;
var totalAttempted = 0;
var dynamicScore = 0;
var currentQuestionTypeMode = "";
var highlightArray = new Array();
var flagReviewIncompAAT = false;
var redcrshr_lastpositionx = 0
var redcrshr_lastpositiony = 0
var qSequence = new Array();
var totalAatCorrect = 0
var totalaatQCount = 0;
var globaltotalaatQAttempted = 0;
var fiveMntsRem_popupshown = false;
var incompleteQuestionNumAAT = 0;
var incompleteQnum = 0;
var globalFlaggedQnum = 0;
var questionStatus = [];
var tempaatQuestionJump = 0;
var backtointro = false;
var sectionStart = false;
var loadingSectionStart = false;
var sectionStartLoaded = false;
var previousClicked = false;
var instructionRendered = false;
var questionRendered = false;
var spread;
var fbx;
var excelIo;
var editor;
var allresponsehtml;
var inreviewmode = false;
var totalQuestionsToInclude = 0;

var stylesheets = new stylesheetObject();
stylesheets.add("instruction", cssPath + "instruction.xsl");
stylesheets.add("question", cssPath + "question.xsl");
stylesheets.add("teststart", cssPath + "teststart.xsl");
stylesheets.add("testsummary", cssPath + "testsummary.xsl");
stylesheets.add("testcomplete", cssPath + "testcomplete.xsl");
stylesheets.add("testreview", cssPath + "testreview.xsl");
stylesheets.add("testfeedback", cssPath + "testfeedback.xsl");
stylesheets.add("questionreview", cssPath + "questionreview.xsl");
stylesheets.add("reference", cssPath + "reference.xsl");
stylesheets.add("aatreadingpassage", cssPath + "aatreadingpassage.xsl");
stylesheets.add("aatquestion", cssPath + "aatquestion.xsl");
stylesheets.add("readingpassage", cssPath + "readingpassage.xsl");

function stylesheetObject()
{
	this.obj = new Array();
	this.names = new Array();
	this.length = 0;
	this.loadingCtr = 0;
	this.allLoaded = false;
	this.add = function(objectname, xslfilename)
	{
		this.obj[objectname] = new Array();
		this.obj[objectname][0] = xslfilename;
		this.obj[objectname][1] = null;
		this.names[this.length] = objectname;
		this.length++;
	}
	this.loadXML = function()
	{
		if(! this.allLoaded)
		{
			var filename = this.obj[this.names[this.loadingCtr]][0];
			loadXMLDoc(filename, processReqChangeForStyleSheet);
		}
	}
}

//load xml file
function loadXMLDoc(url, processReqChangeObj)
{
	if(isIE && (!window.XMLHttpRequest || document.location.href.substr(0,8) == "file:///")){
		try{
			req = new ActiveXObject("Microsoft.XMLDOM");
			req.async=false;
			if(!req.load(url)){
				if(timed == "R"){
					clearInterval(timeRemainingTimer);
				}
				if(!req.load(xmlPath + "IN_dummy.xml")){
					if(confirm("There was an error loading content from the server. Please check your internet connection. If you are able to restore the connection, click on OK otherwise click on Cancel. Clicking on Cancel will close the SCO and you will lose any attempt data that was not sent to the server earlier.")){
						if(timed == "R"){
							clearInterval(timeRemainingTimer);
							timeRemainingTimer = setInterval("ProcessExamTimer();", 1000);
						}
						loadXMLDoc(url, processReqChangeObj);
					}else{
						exitNoSave = true;
						scocloseonexit = true;
						LogOut();
					}
				}else{
					var missingfile = url.substr(url.lastIndexOf("/")+1, url.length);
					if(lessonType == "exam" || lessonType == "test" || lessonType=="customtest"){
						alert("There was an error loading content ("+missingfile+") from the server!\nThe session will end now.");
						closeOnContentError = true;
						LogOut();
						return;
					}else{
						alert("There was an error loading content ("+missingfile+") from the server!");
						processReqChangeObj();
					}
				}
			}else{
				processReqChangeObj();
			}

		}catch(err){
			alert(err.message + '\n\nThere was a problem retrieving data');
		}
	}else if (window.XMLHttpRequest){
		try{
			usingXMLHTTP = true;
			req	= new XMLHttpRequest();
			req.onreadystatechange=processReqChangeObj;
			if(url.indexOf(cssPath) != -1){
				req.open("GET",url,true);
			}else{
				req.open("GET",url,false);
			}
			try {req.responseType = "msxml-document"} catch(err) {} // Helping IE11
			req.send(null);
		}catch(err){
			alert(err.message + '\n\nThere was a problem retrieving data');
		}
	}else if(document.implementation && document.implementation.createDocument){
		try{
			req= document.implementation.createDocument("","",null);
			req.onload = processReqChangeObj;
			req.load(url);
		}catch(err){
			alert(err.message + '\n\nThere was a problem retrieving data');
		}
	}
	else
	{
		alert('There was a problem retrieving data');
	}
}

// handle onreadystatechange event of req object
function processReqChangeForConfig()
{
	if(usingXMLHTTP)
	{
		if (req.readyState==4)
		{
			if (req.status==200)
			{
				configObj = req.responseXML;
				InitCourseData();
				xmlFileName = contentPath + GetNodeValue(configObj, "categoryfilename", 0);
				loadXMLDoc(xmlFileName, processReqChangeForCategory);
			}
		}
	}
	else
	{
		configObj=req;
		InitCourseData();
		xmlFileName = contentPath + GetNodeValue(configObj, "categoryfilename", 0);
		loadXMLDoc(xmlFileName, processReqChangeForCategory);
	}
}

function processReqChangeForCategory()
{
	if(usingXMLHTTP)
	{
		if (req.readyState==4)
		{
			if (req.status==200)
			{
				categoryObj=req.responseXML;
				xmlFileName = contentPath + courseConfigFileName; // Start with Main Menu instead of Welcome screen.
				stylesheets.loadXML();
				sessionStartTime = new Date();
			}
		}
	}
	else
	{
		categoryObj=req;
		xmlFileName = contentPath + courseConfigFileName; // Start with Main Menu instead of Welcome screen.
		stylesheets.loadXML();
		sessionStartTime = new Date();
	}
}

function processReqChangeForData()
{
	if(usingXMLHTTP)
	{
		if (req.readyState==4)
		{
			if (req.status==200)
			{
				xmlObj = req.responseXML;
				if(currentScreenType != "mainmenu")
				{
					transformXML();
				}
				else
				{
					CallLesson(0,0);
				}
			}
		}
	}
	else
	{
		xmlObj=req;
		if(currentScreenType != "mainmenu")
		{
			transformXML();
		}
		else
		{
			CallLesson(0,0);
		}
	}
}
function processReqChangeForStyleSheet() {
	if(usingXMLHTTP){
		if (req.readyState==4){
			if (req.status==200){
				//--Change for common engine-------------------------//
				var respXML = req.responseXML;
				if(parent.commonEngine){
					if(respXML.xml){
						respXML.xml.replace(findpath, contentPath);
					}else if(respXML.firstChild.xml){
						respXML.firstChild.xml.replace(findpath, contentPath);
					}else if(respXML.firstChild.innerHTML){
						respXML.firstChild.innerHTML.replace(findpath, contentPath);
					}
				}
				stylesheets.obj[stylesheets.names[stylesheets.loadingCtr]][1] = respXML;
				//--------------------------------------------------//
				stylesheets.loadingCtr++;
				if(stylesheets.loadingCtr != stylesheets.length){
					stylesheets.loadXML();
				}else{
					stylesheets.allLoaded = true;
					loadXMLDoc(xmlFileName, processReqChangeForData);
				}
			}
		}
	}else{
		//--Change for common engine-------------------------//
		var respXML = req
		if(parent.commonEngine){
			if(respXML.xml){
				respXML.xml.replace(findpath, contentPath);
			}else if(respXML.firstChild.xml){
				respXML.firstChild.xml.replace(findpath, contentPath);
			}else if(respXML.firstChild.innerHTML){
				respXML.firstChild.innerHTML.replace(findpath, contentPath);
			}
		}
		stylesheets.obj[stylesheets.names[stylesheets.loadingCtr]][1] = respXML;
		//--------------------------------------------------//
		stylesheets.loadingCtr++;
		if(stylesheets.loadingCtr != stylesheets.length){
			stylesheets.loadXML();
		}else{
			stylesheets.allLoaded = true;
			loadXMLDoc(xmlFileName, processReqChangeForData);
		}
	}

}
function InitCourseData()
{

	SCOID = GetNodeValue(configObj, "id", 0);
	learnerData.courseID = SCOID;
	SCOTitle = GetNodeValue(configObj, "title", 0);
	parent.document.title = SCOTitle;
	var scoconfig = GetNode(configObj, "configuration", 0);
	courseType = GetNodeValue(scoconfig, "coursetype", 0);
	try
	{
		categoryRootID = GetNodeValue(scoconfig, "categoryrootid", 0);
	}
	catch(e)
	{
		categoryRootID = null;
	}
	coursetimeoutduration = Number(GetNodeValue(configObj, "duration", 0)) * 60000;
	finalpassrate = Number(GetNodeValue(configObj, "finalpassrate", 0));
	completionstrategy = GetCompletionIDs(GetNode(configObj, "completionstrategy", 0));
	var tunits = configObj.getElementsByTagName("unit");
	InitTaskDataObj();
	learnerData.InitLearnerData(tunits);
}

function LoadStyleSheetObj(screenType)
{
	switch(screenType)
	{
		case "instruction" : xslObj = stylesheets.obj["instruction"][1]; break;
		case "question" : xslObj = stylesheets.obj["question"][1]; break;
		case "teststart" : xslObj = stylesheets.obj["teststart"][1]; break;
		case "testsummary" : xslObj = stylesheets.obj["testsummary"][1]; break;
		case "testcomplete" : xslObj = stylesheets.obj["testcomplete"][1]; break;
		case "testreview" : xslObj = stylesheets.obj["testreview"][1]; break;
		case "testfeedback" : xslObj = stylesheets.obj["testfeedback"][1]; break;
		case "questionreview" : xslObj = stylesheets.obj["questionreview"][1]; break;
		case "aatreadingpassage" :  xslObj = stylesheets.obj["aatreadingpassage"][1]; break;
		case "aatquestion" :  xslObj = stylesheets.obj["aatquestion"][1]; break;
		case "readingpassage" :  xslObj = stylesheets.obj["readingpassage"][1]; break;
	}
}

function CheckContentFrameReady()
{
	if(parent.contentFrame.document.getElementById("contentDiv"))
	{
		clearTimeout(checktimer);
		contentFrameReady = true;
		if(coursetimeoutduration > 0)
		{
			courseTimer = setTimeout("ProcessCourseTimeOut();",coursetimeoutduration);
		}
		transformXML();
	}
	else
	{
		checktimer = setTimeout("CheckContentFrameReady();", 100);
	}
}

function transformXML()
{
	if(currentScreenType == "question" || currentScreenType == "questionreview")
	{
		if(loadingSectionStart){
			LoadStyleSheetObj("instruction");
			currentScreenType = "instruction";
		}
		else if(loadingReadingPassage)
		{
			LoadStyleSheetObj("readingpassage");
		}
		else
		{
			LoadStyleSheetObj(currentScreenType);
		}
	}
	else
	{
		LoadStyleSheetObj(currentScreenType);
	}
	if(!contentFrameReady)
	{
		checktimer = setTimeout("CheckContentFrameReady();", 100);
		return;
	}
	if(isIE)
	{
		var temphtmobj = xmlObj.transformNode(xslObj);
		if(loadingReadingPassage || (currentScreenType=="aatreadingpassage"))
		{
			if(currentScreenFlag == "AAT")
			{
				parent.contentFrame.document.getElementById("contentDiv").innerHTML = temphtmobj;
			}
			else
			{
				parent.contentFrame.document.getElementById("questionsetstimulus").innerHTML = temphtmobj;
			}
		}
		else
		{
			if((currentScreenFlag == "AAT") && (currentScreenType=="aatquestion"))
			{
				var tqxml = GetNode(xmlObj, "question", 0);
				var ttstem = GetNode(tqxml, "questionStemXML",0);
				var ttcontent = GetNode(ttstem, "content",0);
				var ttqtype = GetNodeValue(ttcontent, "para", 0);
				if(ttqtype == "DRAGDROP")
				{
					if(parent.contentFrame.document.getElementById("dragitems_"+readingpassageid))
					{
						questiondragitems += StripHTML(temphtmobj);
						if(parent.contentFrame.document.getElementById("qdiv_"+questiondiv))
						{
							parent.contentFrame.document.getElementById("qdiv_"+questiondiv).innerHTML = "<span id='"+tqxml.getAttribute("questionID")+"_"+currentqid+":"+1 +"' class='droparea'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>";
						}
						else
						{
							alert("qdiv_"+questiondiv +" element not found!");
						}
					}
					else
					{
						alert("dragitems_"+readingpassageid +" element not found!");
					}
				}
				else
				{
					if(parent.contentFrame.document.getElementById("qdiv_"+questiondiv))
					{
						parent.contentFrame.document.getElementById("qdiv_"+questiondiv).innerHTML += temphtmobj;
					}
					else
					{
						alert("qdiv_"+questiondiv +" element not found!");
					}
				}
			}
			else
			{
				parent.contentFrame.document.getElementById("contentDiv").innerHTML = temphtmobj;
			}
		}
	}
	else
	{
		processor = new XSLTProcessor();
		processor.importStylesheet(xslObj);
		var newFragment = processor.transformToFragment(xmlObj, parent.contentFrame.document);
		if(loadingReadingPassage || (currentScreenType=="aatreadingpassage"))
		{
			if(currentScreenFlag == "AAT")
			{
				parent.contentFrame.document.getElementById("contentDiv").innerHTML = "";
			parent.contentFrame.document.getElementById("contentDiv").appendChild(newFragment);
			if(parent.contentFrame.document.getElementById("MainContentTable"))
			parent.contentFrame.document.getElementById("MainContentTable").style.marginLeft = "1px";
			}
			else
			{
			parent.contentFrame.document.getElementById("questionsetstimulus").innerHTML = "";
			parent.contentFrame.document.getElementById("questionsetstimulus").appendChild(newFragment);
			}
		}
		else
		{

		 if((currentScreenFlag == "AAT") && (currentScreenType=="aatquestion")){
				parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
				parent.contentFrame.document.getElementById("loading_shadow").style.display = "block";
			var qxml = GetNode(xmlObj, "question", 0);
			var tstem = GetNode(qxml, "questionStemXML",0);
			var tcontent = GetNode(tstem, "content",0);
			var tqtype = GetNodeValue(tcontent, "para", 0);
			if(tqtype == "DRAGDROP"){
				if(parent.contentFrame.document.getElementById("dragitems_"+readingpassageid)){
					questiondragitems += StripHTML(newFragment.firstChild.nodeValue);
					if(parent.contentFrame.document.getElementById("qdiv_"+questiondiv)){
						parent.contentFrame.document.getElementById("qdiv_"+questiondiv).innerHTML = "<span id='"+qxml.getAttribute("questionID")+"_"+currentqid+":"+1 +"' class='droparea'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>";
					}else{
						alert("qdiv_"+questiondiv +" element not found!");
					}
				}else{
					alert("dragitems_"+readingpassageid +" element not found!");
				}
			}else{
				if(parent.contentFrame.document.getElementById("qdiv_"+questiondiv)){
					parent.contentFrame.document.getElementById("qdiv_"+questiondiv).appendChild(newFragment);
				}else{
					alert("qdiv_"+questiondiv +" element not found!");
				}
			}
		}else{
			parent.contentFrame.document.getElementById("contentDiv").innerHTML = "";
			parent.contentFrame.document.getElementById("contentDiv").appendChild(newFragment);
		}

		}

	}
	if (currentScreenType != "testfeedbacknavigator")
	{
		if(studentName!='' || studentName.length!=0) {
			parent.contentFrame.document.getElementById("pagehead").innerHTML = SCOTitle+" - "+studentName;
		}
		else{
			parent.contentFrame.document.getElementById("pagehead").innerHTML = SCOTitle;
		}
	}
	AdjustUI();
	switch(currentScreenType)
	{
		case "welcome": break;
		case "mainmenu": break;
			if(!isIE) parent.contentFrame.document.getElementById("headerDiv").style.marginLeft = "1px";
			var tunits = configObj.getElementsByTagName("unit");
			for(var i=0;i<tunits.length;i++)
			{
				var tlessons = tunits.item(i).getElementsByTagName("lesson");
				var ltype;
				var tstr = ""
				for(var j=0;j<tlessons.length;j++)
				{
					var lessonProgress = learnerData.GetProgress(i,j)
					ltype = tlessons[j].getAttribute("questionset");
					if(ltype == "test" || ltype == "exam")
					{
						tstr = CorrectCase(lessonProgress[0], false);
						tstr2 = CorrectCase(lessonProgress[1], false);
						if(tstr != "" && tstr2 != "")
						{
							tstr = tstr + ", " + tstr2;
						}
						else if(tstr == "" && tstr2 != "")
						{
							tstr = tstr2;
						}
					}
				}
			}
			if(learnerData.lastVisited != null && learnerData.lastVisited != "")
			{
				var ul = learnerData.lastVisited.split(",");
			}
			break;
		case "instruction":
			//parent.contentFrame.initScrollCheck();
			/*if(!loadingSectionStart && !taskData[currentUnit][currentLesson][currentScreenNum].viewed) {
				console.warn((new Date()).getTime() + ": calling initScrollCheck")
				parent.contentFrame.initScrollCheck();
				setTimeout("console.warn((new Date()).getTime() + ': calling initScrollCheck timed'); parent.contentFrame.initScrollCheck()", 200)
			};*/
			if(lessonType == "test" || lessonType == "exam"){
				parent.contentFrame.document.getElementById("navigator_but").style.display = "table-cell";
				if(currentScreenNum == firstScreen){
					parent.contentFrame.document.getElementById("back_but_table").style.display = "none";
				}
				if(loadingSectionStart){
					loadingSectionStart = false;
				}
				questionRendered = false;
				instructionRendered = true;
			}
			break;
		case "teststart":
			break;
		case "question" :
			if(currentScreenFlag != "AAT")
			{
				//parent.contentFrame.initScrollCheck();
				parent.contentFrame.initSplitPanel();
				if(currentScreenObj.getAttribute("sectionstart") && currentScreenObj.getAttribute("sectionstart") != ""){
					sectionStart = true;
				}else{
					sectionStart = false;
				}
				if(!previousClicked && !loadingSectionStart && sectionStart && !instructionRendered && !inreviewmode){
					loadingSectionStart = true;
					xmlFileName = contentPath + currentScreenObj.getAttribute("sectionstart");
					loadXMLDoc(xmlFileName, processReqChangeForData);
					return;
				}

				if(loadingReadingPassage)
				{
					loadingReadingPassage = false;
					xmlObj = tmpXmlObj;
					return;
				}
				if(currentScreenObj.getAttribute("questionset") != undefined && currentScreenObj.getAttribute("questionset") != null){
					loadingReadingPassage = true;
					tmpXmlObj = xmlObj;
					xmlFileName = contentPath + currentScreenObj.getAttribute("readingpassage");
					parent.contentFrame.document.getElementById("questionsetstimulus").innerHTML = "<p>Loading reading passage...</p>"
					parent.contentFrame.document.getElementById("qset_stimulus").style.display = "table-cell";
          parent.contentFrame.document.getElementById("separator_cell").style.display = "table-cell";
					loadXMLDoc(xmlFileName, processReqChangeForData);
				}
        if(answerTypeCD=="SPREADSHEET"){
					var sdiv = parent.contentFrame.document.getElementById("ssembed");
          spread = new parent.contentFrame.GC.Spread.Sheets.Workbook(sdiv, { sheetCount: 1 });
					spread.options.enableFormulaTextbox = false;
					spread.options.tabNavigationVisible = false;
					spread.options.newTabVisible = false;
		      spread.invalidateLayout();
		      spread.repaint();
					var spreadNS = parent.contentFrame.GC.Spread.Sheets,
                sheet = spread.getSheet(0),
                SheetArea = spreadNS.SheetArea;
            sheet.suspendPaint();
            sheet.setRowCount(200, SheetArea.viewport);
            sheet.setColumnCount(100, SheetArea.viewport);
            sheet.resumePaint();

						var fdiv = parent.contentFrame.document.getElementById("formulaBar");
						fbx = new parent.contentFrame.GC.Spread.Sheets.FormulaTextBox.FormulaTextBox(fdiv);
            //fbx.autoComplete(false);
						fbx.showHelp(false);
            fbx.workbook(spread);

						parent.contentFrame.disableCopyPaste('questionsetstimulus');
						//parent.contentFrame.disableCopyPaste('question_cell');
        }
        if(answerTypeCD == "ESSAY"){
          parent.contentFrame.CKEDITOR.replace('EssayAnswer',{ removePlugins : 'elementspath, resize' });
          editor = parent.contentFrame.document.getElementById("EssayAnswer");
					parent.contentFrame.disableCopyPaste('questionsetstimulus');
					//parent.contentFrame.disableCopyPaste('question_cell');
        }
				var timedstr = (timed == "R")?("Time Remaining <span class=\"\"></span>"):"<span class=\"bold\">untimed</span>";
				parent.contentFrame.document.getElementById("pagetimer").innerHTML = timedstr ;
				if(currentQuestionType == "Review All" )
				{
					currentQuestionNum = testQuestionSequence[currentScreenNum];
					parent.contentFrame.document.getElementById("pagenumbering").innerHTML = GetCurrentQuestionNumForDisplay(currentScreenNum,testQuestionSequence) + " of " + (totalQuestionsForDisplay+GetSectionCCount());
				}
				else if(currentQuestionType == "Review Selected")
				{
					SelectQuestionNum = testQuestionSequence[currentQuestionNum];
					parent.contentFrame.document.getElementById("pagenumbering").innerHTML = GetCurrentQuestionNumForDisplay(SelectQuestionNum) + " of " + (totalQuestionsForDisplay+GetSectionCCount());
				}
				else if(currentQuestionType == "Review Incomplete")
				{

					parent.contentFrame.document.getElementById("pagenumbering").innerHTML = GetCurrentQuestionNumForDisplay(currentQuestionNum,IncompleteArray) + " of " + (totalQuestionsForDisplay+GetSectionCCount());
				}
				if(currentQuestionTypeMode == "Navigator Mode")
				{
					currentQuestionNum = testQuestionSequence[currentScreenNum];
					parent.contentFrame.document.getElementById("pagenumbering").innerHTML = GetCurrentQuestionNumForDisplay(currentScreenNum,testQuestionSequence) + " of " + (totalQuestionsForDisplay+GetSectionCCount());
				}
				ProcessAnswerParameters(GetNode(xmlObj,  "responseEvaluationStrategy",  0));
				if(lessonType == "test" || lessonType == "exam" || lessonType=="customtest")
				{
					if(currentQuestionType == "Review All" )
					{
						currentQuestionNum = testQuestionSequence[currentScreenNum];
						var lastResponse = learnerData.GetResponse(testQuestionSequence[currentScreenNum],currentUnit,currentLesson);

						if(questionStatus[currentScreenNum][1] == 1)
						{
							flagclick = true;
						}else{
							flagclick = false;
						}
						Flag_Withoutclick_Out();
					}
					if(currentQuestionType == "Review Selected")
					{
						SelectQuestionNum = testQuestionSequence[currentQuestionNum];
						var lastResponse = learnerData.GetResponse(testQuestionSequence[SelectQuestionNum],currentUnit,currentLesson);

						if(questionStatus[SelectQuestionNum][1] == 1)
						{
							flagclick = true;
						}else{
							flagclick = false;
						}
						Flag_Withoutclick_Out();
					}
					if(currentQuestionType == "Review Incomplete")
					{
						IncompleteQuestionNum = IncompleteArray[currentScreenNum];
						var lastResponse = learnerData.GetResponse(testQuestionSequence[IncompleteQuestionNum],currentUnit,currentLesson);
					}
					if(currentQuestionTypeMode == "Navigator Mode")
					{
						var lastResponse = learnerData.GetResponse(testQuestionSequence[currentScreenNum],currentUnit,currentLesson);
					}
					if(lastResponse != null)
					{
						if(lastResponse[1] != null && lastResponse[1] != "")
						{
  							SelectAnswer(lastResponse[1]);
						}
						else
						{
							selectedOptionID = "";
						}
					}
					else
					{
						selectedOptionID = "";
					}
					if(answerTypeCD == "ESSAY" || answerTypeCD == "SPREADSHEET"){
						var lastResponse = taskData[currentUnit][currentLesson][currentScreenNum].prevalue;
						if(lastResponse != null && lastResponse != "")
						{
							if(answerTypeCD == "ESSAY"){
								parent.contentFrame.CKEDITOR.instances.EssayAnswer.setData(lastResponse);
							}
							if(answerTypeCD == "SPREADSHEET"){
								spread.fromJSON(JSON.parse(lastResponse));
							}
						}else{
							selectedOptionID = "";
						}
					}
				}
				instructionRendered = false;
				questionRendered = true;
				previousClicked = false;
				//allresponsehtml += parent.contentFrame.document.getElementById("contentDiv").innerHTML;
				//if(answerTypeCD == "ESSAY" || answerTypeCD == "SPREADSHEET"){
					//if(!taskData[currentUnit][currentLesson][currentScreenNum].viewed) setTimeout("parent.contentFrame.initScrollCheck()", 200);
				/*}else{
					if(!taskData[currentUnit][currentLesson][currentScreenNum].viewed) parent.contentFrame.initScrollCheck();
				}*/
			}
			LoadReference();
			break;
		case "testfeedback":
			if (timed == "R"){
				parent.contentFrame.document.getElementById("pagetimer").innerHTML = "Time Remaining <span class=\"\">" + FormatTime(examTimeRemaining) +"</span>";}
			else{
				parent.contentFrame.document.getElementById("pagetimer").innerHTML = "<span class=\"bold\">untimed</span>";
			}
			//chk if only long question
			if(totalScreens == aatQuestionJump)
			{
				parent.contentFrame.document.getElementById("shortAnsReviewTbl").style.display = "none";
			}
			else
			{
				parent.contentFrame.document.getElementById("quesfeedbacklist").innerHTML = PreparefeedbackPage();
			}
			parent.contentFrame.document.getElementById("Testfeedback_head_id").innerHTML = "Item Review Screen";
			break;
		case "testfeedbacknavigator":
			//chk if only long question
			if(totalScreens == aatQuestionJump)
			{
				parent.contentFrame.document.getElementById("shortAnsReviewTbl").style.display = "none";
			}
			else
			{
				parent.contentFrame.document.getElementById("quesfeedbacklist").innerHTML = PreparefeedbackPageforNavigator();
			}
			parent.contentFrame.document.getElementById("Lquesfeedbacklist").innerHTML = LPreparefeedbackPageforNavigator();
			parent.contentFrame.document.getElementById("Lfeedback_result_text_id").innerHTML = GetLongFormQuestionTitle();
			var longanswerIncompleteNum = GetLonganswerCompletion();
			break;

		case "testsummary":
			var score = learnerData.GetScore(currentUnit,currentLesson);
			var division;
			if(rationaleatend == "N")
			{
				parent.contentFrame.document.getElementById("reviewinstruction").style.visibility = "hidden";
				parent.contentFrame.document.getElementById("navtestreview").style.visibility     = "hidden";
				parent.contentFrame.document.getElementById("navtestreview2").style.visibility    = "hidden";
			}
			parent.contentFrame.document.getElementById("testname").innerHTML = currentLessonTitle;
			parent.contentFrame.document.getElementById("teststatus").innerHTML = CorrectCase(currentExamStatus[0], false) + ", " + CorrectCase(currentExamStatus[1], false);
			parent.contentFrame.document.getElementById("testmode").innerHTML = CorrectCase(score[0], false);
			parent.contentFrame.document.getElementById("lastmodified").innerHTML = CorrectCase(score[7], true);
			parent.contentFrame.document.getElementById("testpassingscore").innerHTML = score[1] + "%";
			parent.contentFrame.document.getElementById("summary").innerHTML = PrepareCategoryBreakup(score);
			break;
		case "testcomplete":
			var score = learnerData.GetScore(currentUnit,currentLesson);
			//parent.contentFrame.document.getElementById('sectioncdownloads').innerHTML = GetSectionCDownloads();
			parent.contentFrame.document.getElementById("summary").innerHTML = PrepareCategoryBreakup(score);
			break;
		case "testreview":
			parent.contentFrame.document.getElementById("testname").innerHTML = currentLessonTitle;
			parent.contentFrame.document.getElementById("questionslist").innerHTML = PrepareReviewPage();
			break;
		case "questionreview":
			if(loadingReadingPassage)
			{
				loadingReadingPassage = false;
				return;
			}
			parent.contentFrame.document.getElementById("pagenumbering").innerHTML = GetCurrentQuestionNumForDisplay(currentScreenNum,testQuestionSequence) + " of " + totalQuestionsForDisplay;
			ProcessAnswerParameters(GetNode(xmlObj, "responseEvaluationStrategy", 0));
			var lastResponse = learnerData.GetResponse(testQuestionSequence[currentScreenNum],currentUnit,currentLesson);
			DisableAnswers(lastResponse);
			ShowRationale(lastResponse[2]);
			if(currentScreenObj.getAttribute("questionID") != undefined && currentScreenObj.getAttribute("questionID") != null)
			{
				if(currentScreenObj.getAttribute("questionset"))
				{
					loadingReadingPassage = true;
					xmlFileName = contentPath + currentScreenObj.getAttribute("readingpassage");
					parent.contentFrame.document.getElementById("questionsetstimulus").innerHTML = "<p>Loading reading passage...</p>"
					parent.contentFrame.document.getElementById("qset_stimulus").style.display = "table-cell";
          parent.contentFrame.document.getElementById("separator_cell").style.display = "table-cell";
					loadXMLDoc(xmlFileName, processReqChangeForData);
				}
			}
			parent.contentFrame.MakeDraggable_review_popup();
			LoadReference();
			break;
	}
	if(currentScreenFlag != "AAT")
	{
		SetNavButtons();
	}
}

function CallLesson(u,l)
{
	if(currentScreenType != "mainmenu")
		parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";

	var resume = false;
	reviewmode = false;

	currentUnit      = u;
	currentLesson    = l;
	currentUnitObj   = GetNode(configObj, "unit", u);
	totalLessons     = currentUnitObj.getElementsByTagName("lesson").length;
	currentLessonObj = GetNode(currentUnitObj, "lesson", l);
	totalScreens     = currentLessonObj.getElementsByTagName("screen").length;
	totalQuestionsToInclude = GetSectionABCount();
	if(backtointro){
		currentScreenNum = totalScreens - 1;
		backtointro = false;
	}else{
		currentScreenNum = 0;
	}
	currentScreenObj = GetNode(currentLessonObj, "screen", currentScreenNum);
	totalQuestions   = totalScreens;
	questionBank     = totalQuestions;
	totalQuestionsForDisplay = GetTotalQuestionsForDisplay();
	currentLessonTitle = currentLessonObj.getElementsByTagName("title")[0].firstChild.nodeValue;
	// made changes issue number 2 "SCO issues sent by client in the document "CIMA Online Test review 271114_MF"
	Projectdescription = "Welcome to Kaplan's online testing! <p>The objective tests are 15 minutes in length. They are made up of 10 questions. You will be able to go forwards in the test and backwards to see the previous questions that you may have already answered. </p><p>You will be presented with individual questions. You may also be presented with a set of questions associated to the same information. </p><p> The objective test will be computer marked and you will be given your score on completion of the test. </p><p>You may change your answers as many times as you like in the time available.<p> To begin, click the <b>Next</b> button at the bottom of each screen to progress to the next question or page. Good luck!</p>"
	lessonType  = currentLessonObj.getAttribute("type");
	firstScreen = 0;
	lastScreen  = totalScreens - 1;
	LoadLessonParameters();
	if(lessonType == "test" || lessonType == "exam" || lessonType == "customtest")
	{
		if(resume)
		{
			if(lessonType=="customtest")
			{
				var customExamData = learnerData.GetCustomExamData();
				totalBuildQuestions = Number(customExamData[0]);
				customTestTimed	= eval(customExamData[1]);
				examtimeoutduration = customTestDuration = Number(customExamData[2]);
				if(customTestTimed)
					timed = "R";
				else
					timed = "N";
				learnerData.timeLimit = ConvertToTimeFormat(eval(examtimeoutduration/1000));
				totalScreens = totalQuestions = totalBuildQuestions;
				lastScreen   = totalQuestions - 1;
			}
			currentScreenType = "testresume";
			xmlFileName = xmlPath + "IN_dummy.xml";
		}
		else
		{
			if(lessonType == "customtest")
			{
				categoryDistribution = new Array();
				selectedCategories   = new Array();
				customTestSequence   = new Array();
				totalBuildQuestions  = 0;
				customTestTimed      = false;
				customTestDuration   = 0;
				maxselectedquestions = 0;
				currentScreenType    = "buildcustomexam";
				xmlFileName          = xmlPath + "IN_dummy.xml";
			}
			else
			{
				currentScreenType = "teststart";
				xmlFileName = xmlPath + "../xml/IN_testintro.xml";
			}
		}
	}
	else
	{
		currentScreenType = currentScreenObj.getAttribute("type");
		if(currentScreenType == "question")answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentScreenNum);
		justLaunched = false;
	}
	learnerData.successStatus = "unknown";
	learnerData.lastVisited = u + "," + l;
	loadXMLDoc(xmlFileName, processReqChangeForData);
	return true;
}

function GetCompletionIDs(node)
{
		var andnode = GetNode(node, "and", 0);
		var ornode = GetNode(node, "or", 0);
		var tmpobj = new Object();
		if(andnode != null)
		{
			tmpobj.and = andnode.getElementsByTagName("id");
		}
		else
		{
			tmpobj.and = null;
		}
		if(ornode != null)
		{
			tmpobj.or = ornode.getElementsByTagName("id");
		}
		else
		{
			tmpobj.or = null;
		}
		return tmpobj;
}

function LoadLessonParameters()
{
	var lessonConfig = GetNode(currentLessonObj, "configuration", 0);
	if(lessonType == "test" || lessonType == "exam" || lessonType=="customtest")
	{
		timed = GetNodeValue(lessonConfig, "timed", 0);
		if(timed == "R")
		{
			examtimeoutduration = Number(GetNodeValue(lessonConfig, "duration", 0));
			learnerData.timeLimit = ConvertToTimeFormat(eval(examtimeoutduration/1000));
		}
		else
		{
			learnerData.timeLimit = "";
		}
		if(lessonType == "exam")
		{
			finalpassrate = passpercent = GetExamPassPercent(GetNode(lessonConfig, "passcriteria", 0));
		}
		else
		{
			passpercent = GetExamPassPercent(GetNode(lessonConfig, "passcriteria", 0));
		}
		shuffle = GetNodeValue(lessonConfig, "shuffle", 0);
		showrationale = GetNodeValue(lessonConfig, "showrationale", 0);
		rationaleatend = GetNodeValue(lessonConfig, "rationaleatend", 0);
		aftercomponentcompletepage = GetNodeValue(lessonConfig, "aftercomponentcompletepage", 0);
		if(!aftercomponentcompletepage)
		{
			aftercomponentcompletepage = "test_summary";
		}
		if(lessonType!="customtest")
		{
			ParseItemSets();
		}
	}
	else
	{
		showrationale = "Y";
	}
	glossary = GetNodeValue(lessonConfig, "glossary", 0);
	allowsuspend = GetNodeValue(lessonConfig, "allowsuspend", 0);
	allowsuspend = "N"
	allowend = GetNodeValue(lessonConfig, "allowend", 0);
	allowback = GetNodeValue(lessonConfig, "allowback", 0);
	allowclear = GetNodeValue(lessonConfig, "allowclear", 0);
}

function ParseItemSets()
{
	var questionset = new Array();
	for(var n=0;n<currentLessonObj.getElementsByTagName("itemset").length;n++)
	{
		questionset = questionset.concat(ParseItemSet(GetNode(currentLessonObj, "itemset", n)));
	}
	totalQuestions = totalScreens = questionset.length;
	lastScreen = totalQuestions - 1;
	newTestSequence = questionset;
}

function ParseItemSet(node)
{
	var isShuffle = GetNodeValue(node, "shuffle", 0);
	var questionSequence;
	if(GetNodeValue(node, "categoryweighted", 0))
	{
		if(GetNodeValue(node, "categoryweighted", 0) == "Y")
		{
			questionSequence = ParseCategoryWeightedSelectionParameters(node, isShuffle);
		}
	}
	else
	{
		questionSequence = new Array();
		var qsets = new Array();
		var currpos = Number(node.getElementsByTagName("id").item(0).getAttribute("sequence"));
		var tempqset = new Array();
		for(var m=0;m<node.getElementsByTagName("id").length;m++){
			if(Number(node.getElementsByTagName("id").item(m).getAttribute("sequence")) != currpos)
			{
				qsets.push(tempqset);
				var tempqset = new Array();
				currpos = Number(node.getElementsByTagName("id").item(m).getAttribute("questionset"));
				var qobject = new Object();
				qobject.sequence = Number(node.getElementsByTagName("id").item(m).getAttribute("questionset"));
				if(node.getElementsByTagName("id").item(m).getAttribute("sequence"))
					qobject.questionset = node.getElementsByTagName("id").item(m).getAttribute("sequence");
				qobject.setsequence = Number(node.getElementsByTagName("id").item(m).firstChild.nodeValue);
				qobject.questionposition = m;
				tempqset.push(qobject);
			}
			else
			{
				var qobject = new Object();
				qobject.sequence = Number(node.getElementsByTagName("id").item(m).getAttribute("questionset"));
				if(node.getElementsByTagName("id").item(m).getAttribute("sequence"))
				qobject.questionset = node.getElementsByTagName("id").item(m).getAttribute("sequence");
				qobject.setsequence = Number(node.getElementsByTagName("id").item(m).firstChild.nodeValue);
				qobject.questionposition = m;
				tempqset.push(qobject);
			}
		}
		qsets.push(tempqset);
		if(isShuffle == "Y")
		{
			//Randomize sets
			qsets = RandomizeQsetArray(qsets);
		}
		//Flatten array
		for(var m=0; m<qsets.length;m++)
		{
			for(var n=0;n<qsets[m].length;n++)
			{
				questionSequence.push(qsets[m][n].questionposition);
			}
		}
	}
	return questionSequence;
}

function RandomizeQsetArray(questionSequence)
{
	var arrylength = questionSequence.length;
	var now = null;
	var seed = null;
	var random_number = null;
	var range = null;
	var rounded_number = null;
	var randomizedSequence = new Array();
	for(var i=0;i<arrylength;i++)
	{
		now = new Date();
		seed = now.getSeconds();
		random_number = Math.random(seed);
		range = random_number * questionSequence.length;
		rounded_number = Math.round(range);
		if (rounded_number == questionSequence.length)
		{
			rounded_number = 0
		};
		var spliced = questionSequence.splice(rounded_number,1);
		randomizedSequence.push(spliced[0]);
	}
	return randomizedSequence;
}

function GetExamPassPercent(node)
{
	var n1 = GetNode(node, "deliverableStatusCriterion", 0);
	var n2 = GetNode(n1, "quantity", 0);
	return Number(GetNodeValue(n2, "amount", 0));
}

function SetNavButtons()
{
	switch(currentScreenType)
	{
		case "teststart":
			break;
		case "instruction":
			if(lessonType != "test" || lessonType != "exam"){
				if(currentScreenNum <= 0)
					parent.contentFrame.document.getElementById("back_but_table").style.display="none";
				break;
			}
		case "question":
			/*if(currentScreenNum == 0)
			{
				if(parent.contentFrame.document.getElementById("back_but_table"))
					parent.contentFrame.document.getElementById("back_but_table").style.display="none"
			}*/
			if(answerTypeCD == "SPREADSHEET" || answerTypeCD == "ESSAY"){
				parent.contentFrame.document.getElementById("Symbol_btn").style.display = "table-cell";
			}else{
				parent.contentFrame.document.getElementById("Symbol_btn").style.display = "none";
			}
			if(Reviewtab >= 1)
			{
				if(parent.contentFrame.document.getElementById("review_but_table"))
				{
					parent.contentFrame.document.getElementById("review_but_table").style.display = "block";
				}
				parent.contentFrame.document.getElementById("navigator_but").style.display = "none"

				if(currentScreenNum == testQuestionSequence.length &&  currentQuestionType == "Review All")
				{
					parent.contentFrame.document.getElementById("next_but_table").style.display="none"
				}
				if(currentQuestionType == "Review Incomplete"){

					var count = 0;
					if(currentQuestionNum+1==questionStatus.length){
						parent.contentFrame.document.getElementById("next_but_table").style.display="none"
					}
					for(var i=currentQuestionNum+1; i<questionStatus.length;i++){
						if(questionStatus[i][0] == 1){
							count =1
							break;
						}
					}
					if (count==0)parent.contentFrame.document.getElementById("next_but_table").style.display="none"
					var count1 = 0;
					if(currentQuestionNum-1==-1){
						parent.contentFrame.document.getElementById("back_but_table").style.display="none"
					}
					for(var i=currentQuestionNum-1; i>=0;i--){
						if(questionStatus[i][0] == 1){
							count1 =1
							break;
						}
					}
					if (count1==0)parent.contentFrame.document.getElementById("back_but_table").style.display="none"
					if (count1==1)parent.contentFrame.document.getElementById("back_but_table").style.display="block"
				}
				if(currentQuestionType == "Review Selected"){
					var count = 0;
					if(SelectQuestionNum+1==questionStatus.length){
						parent.contentFrame.document.getElementById("next_but_table").style.display="none"
					}
					for(var i=SelectQuestionNum+1; i<questionStatus.length;i++){
						if(questionStatus[i][1] == 1){
							count =1
							break;
						}
					}
					if (count==0)parent.contentFrame.document.getElementById("next_but_table").style.display="none"
					var count1 = 0;
					if(SelectQuestionNum-1==-1){
						parent.contentFrame.document.getElementById("back_but_table").style.display="none"
					}
					for(var i=SelectQuestionNum-1; i>=0;i--){
						if(questionStatus[i][1] == 1){
							count1 =1
							break;
						}
					}
					if (count1==0)parent.contentFrame.document.getElementById("back_but_table").style.display="none"
					if (count1==1)parent.contentFrame.document.getElementById("back_but_table").style.display="block"
				}
				if(currentQuestionType == "Review All"){
					if ((currentScreenNum+1) == totalQuestions){
						parent.contentFrame.document.getElementById("next_but_table").style.display="none"
					}else if(currentScreenNum <= 0){
						parent.contentFrame.document.getElementById("back_but_table").style.display="none"
					}else{
						parent.contentFrame.document.getElementById("next_but_table").style.display="block"
					}
				}

				//disable next button in case of Review All
				if((currentScreenNum+1) == totalQuestions)
				{
					parent.contentFrame.document.getElementById("next_but_table").style.display="none"
				}
			}
			break;
		case "aatquestion":
			if(reviewmode)
			{
				parent.contentFrame.document.getElementById("legendLong").style.display="block";
				if(parent.contentFrame.document.getElementById("Test_Summary_id"))
				{
					parent.contentFrame.document.getElementById("Test_Summary_id").style.display="block";
					parent.contentFrame.document.getElementById("TablesAndFormulae_id").style.visibility="hidden";;
				}
				if(parent.contentFrame.document.getElementById("Navigator_Screen_id"))
				{
					parent.contentFrame.document.getElementById("Navigator_Screen_id").style.display="none";
					parent.contentFrame.document.getElementById("navigator_but").style.display="none";
				}
				if(totalScreens == aatQuestionJump)
				{
					if(parent.contentFrame.document.getElementById("next_but_table"))
							{
								parent.contentFrame.document.getElementById("next_but_table").style.display="none";
							}
				}
				if(parent.contentFrame.document.getElementById("review_but_table"))
				{
					parent.contentFrame.document.getElementById("review_but_table").style.display = "none";
				}

				ShowRationale(getCorrectStatusAAT(currentScreenNum));

				if(parent.contentFrame.document.getElementById("clockwith_timer"))parent.contentFrame.document.getElementById("clockwith_timer").style.display = "none";
				if(parent.contentFrame.document.getElementById("clockwith_timer_shadow"))parent.contentFrame.document.getElementById("clockwith_timer_shadow").style.display = "block";
				if(parent.contentFrame.document.getElementById("TablesAndFormulae"))parent.contentFrame.document.getElementById("TablesAndFormulae").style.display = "none";
				if(parent.contentFrame.document.getElementById("TablesAndFormulae_id"))parent.contentFrame.document.getElementById("TablesAndFormulae_id").style.display = "none";

				if(parent.contentFrame.document.getElementById("topBarScratchpad"))parent.contentFrame.document.getElementById("topBarScratchpad").style.display = "none";
				if(parent.contentFrame.document.getElementById("check_review"))parent.contentFrame.document.getElementById("check_review").style.display = "none";
			}
			else{
				parent.contentFrame.document.getElementById("Test_Summary_id").style.display="none";
				parent.contentFrame.document.getElementById("Test_Summary_id_td").style.display="none";
			}
			if (currentQuestionNum == 0)
			{
				if(parent.contentFrame.document.getElementById("back_but_table"))
					parent.contentFrame.document.getElementById("back_but_table").style.display="none"
			}
			if (currentScreenNum-(aatQuestionJump-1) == 0)
			{
				if(parent.contentFrame.document.getElementById("back_but_table"))
					parent.contentFrame.document.getElementById("back_but_table").style.display="none"
			}

            if(Reviewtab >= 1)
            {
				if(parent.contentFrame.document.getElementById("review_but_table") && reviewmode == false)
				{	parent.contentFrame.document.getElementById("review_but_table").style.display = "block"
				}
				parent.contentFrame.document.getElementById("navigator_but").style.display = "none";
				if(currentQuestionType == "Review Incomplete"){
					//Next Button Visible/not
					var count = 0;
					if(currentScreenNum+1 == questionStatus.length){
						parent.contentFrame.document.getElementById("next_but_table").style.display="none";
					}
					for(var i=currentScreenNum+1; i<questionStatus.length;i++){
						if(questionStatus[i][0] == 1){
							count =1
							break;
						}
					}
					if (count==0)parent.contentFrame.document.getElementById("next_but_table").style.display="none";

					//Back Button Visible/not
					var count1 = 0;
					if(currentScreenNum-1 == -1){
						parent.contentFrame.document.getElementById("back_but_table").style.display="none";
					}
					for(var i=currentScreenNum-1; i>=0;i--){
						if(questionStatus[i][0] == 1){
							count1 =1
							break;
						}
					}
					if (count1==0)parent.contentFrame.document.getElementById("back_but_table").style.display="none";
				}
				if(currentQuestionType == "Review Selected"){
					//Next Button Visible/not
					var count = 0;
					if(currentScreenNum+1 == questionStatus.length){
						parent.contentFrame.document.getElementById("next_but_table").style.display="none";
					}
					for(var i=currentScreenNum+1; i<questionStatus.length;i++){
						if(questionStatus[i][1] == 1){

							count =1
							break;
						}
					}
					if (count==0)parent.contentFrame.document.getElementById("next_but_table").style.display="none";

					//Back Button Visible/not
					var count1 = 0;
					if(currentScreenNum-1 == -1){
						parent.contentFrame.document.getElementById("back_but_table").style.display="none";
					}
					for(var i=currentScreenNum-1; i>=0;i--){
						if(questionStatus[i][1] == 1){
							count1 =1
							break;
						}
					}
					if (count1==0)parent.contentFrame.document.getElementById("back_but_table").style.display="none";

				}
            }
       	 break;
		case "questionreview":
			if(currentScreenNum == 0)
			{
				parent.contentFrame.document.getElementById("back_but_table").style.display="none"
			}
			if(currentScreenNum == lastScreen)
			{
				parent.contentFrame.document.getElementById("next_but_table").style.display="none"
			}
			break;
		case "testreview":
			break;
		case "testcomplete":
			break;
		case "testsummary":
			break;
		case "testfeedback":
			break;
		case "testfeedbacknavigator":
			break;
	}
}

function Stop_teststart_popup()
{
	parent.contentFrame.document.getElementById("teststart_popup").style.display= "none";
}

function Stop_invalid_char_popup()
{
	parent.contentFrame.document.getElementById("invalid_char_popup").style.display= "none";
	if(parent.contentFrame.document.getElementById("answer"))parent.contentFrame.document.getElementById("answer").focus();
	if(parent.contentFrame.document.getElementById("answer1"))parent.contentFrame.document.getElementById("answer1").focus();
	if(parent.contentFrame.document.getElementById("answer2"))parent.contentFrame.document.getElementById("answer2").focus();
	if(parent.contentFrame.document.getElementById("answer3"))parent.contentFrame.document.getElementById("answer3").focus();
	if(parent.contentFrame.document.getElementById("answer4"))parent.contentFrame.document.getElementById("answer4").focus();
	if(parent.contentFrame.document.getElementById("answer5"))parent.contentFrame.document.getElementById("answer5").focus();
	if(parent.contentFrame.document.getElementById("answer6"))parent.contentFrame.document.getElementById("answer6").focus();
}

function Stop_notfullyscrolled_popup()
{
	parent.contentFrame.document.getElementById("notfullyscrolled_popup").style.display= "none";
}


function scrollHandler(theElement){
   		if((theElement.scrollHeight - theElement.scrollTop) + "px" == theElement.style.height)
	      flagLeftPaneFullyScrolled = true;
}

function scrollHandler2(theElement){
   		if((theElement.scrollHeight - theElement.scrollTop) + "px" == theElement.style.height)
	      flagRightPaneFullyScrolled = true;
}

function scrollHandlerShortQ(theElement){
   		if((theElement.scrollHeight - theElement.scrollTop) + "px" == theElement.style.height)
		{
	      flagShortQFullyScrolled = true;
		}
}

function NavNext()
{
 /* //check for scroll on the page
 if(!(sectionStart && instructionRendered) && (currentScreenType == "question" || currentScreenType == "instruction")) // && (parent.contentFrame.document.getElementById("ques_main").clientHeight < parent.contentFrame.document.getElementById("ques_main").scrollHeight) && !flagShortQFullyScrolled && false)
	{
		if(!taskData[currentUnit][currentLesson][currentScreenNum].viewed){
			parent.contentFrame.checkScroll();
			if(!taskData[currentUnit][currentLesson][currentScreenNum].viewed){
				parent.contentFrame.document.getElementById("notfullyscrolled_popup").style.display= "block";
				taskData[currentUnit][currentLesson][currentScreenNum].viewed = true;
				return;
			}
		}
	}*/
	if(inreviewmode){
		instructionRendered = false;
		questionRendered = true;
	}
	if(currentScreenType == "questionreview")
	{
		NavNextReviewQuestion();
		return;
	}
	if(sectionStart && instructionRendered){
		loadingSectionStart = false;
		sectionStartLoaded = true;
		currentScreenType = "question";
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
		loadXMLDoc(xmlFileName, processReqChangeForData);
		return;
	}
	if((currentScreenType == "question" || currentScreenType == "instruction")){
		taskData[currentUnit][currentLesson][currentScreenNum].viewed = true;
	}
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	if(questionRendered) AddToResponses();
	if(currentScreenNum == lastScreen)
	{
			if(lessonType=="test" || lessonType == "exam" || lessonType == "customtest")
			{
        if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT")
  			{
  				selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
					taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
  				taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
  				taskData[currentUnit][currentLesson][currentScreenNum].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
  				taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
  			}
				if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT"){
					var rows = spread.getSheet(0).getDirtyRows();
					if (rows.length > 0) {
						selectedOptionID = TrimStr(GetHTMFromSheet());
						taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
					}else{
						selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID;
					}
					taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
  				taskData[currentUnit][currentLesson][currentScreenNum].prevalue = JSON.stringify(spread.toJSON());
  				taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
				}
			if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
			{
				if(parent.contentFrame.document.getElementById("answer")){
					selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
				}
				if(parent.contentFrame.document.getElementById("answer1")){
					var inputs = parent.contentFrame.document.getElementsByTagName("input")
					selectedOptionID = ""
					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="text")
						{
							selectedOptionID += "##T##" + TrimStr(parent.contentFrame.document.getElementsByTagName("input")[i].value);
							if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
				}
			}

			if(answerTypeCD == "MATCHING")
			{
				var isSelected = false
				selectedOptionID = "";
				for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++)
				{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
					if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
				}
				if(!isSelected)selectedOptionID = "";
			}

			if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
			{
				var isChecked = false
				selectedOptionID = "";
				var inputs = parent.contentFrame.document.getElementsByTagName("input")
				for(var i=0;i<inputs.length;i++)
				{
					if(inputs[i].type=="checkbox")
					{
						if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
						{
						selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
						}
					if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
					}
				}
				if(!isChecked)selectedOptionID = "";
			}

			if(currentScreenFlag != "AAT")
			{
				if(questionRendered){
					if(lessonType == "exam"){
						SendInteractionInfo(currentScreenNum, selectedOptionID, currentScreenObj,currentLesson,flagclick);
					}
					learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
				}
				if(selectedOptionID != ""){
					questionStatus[currentQuestionNum][0] = 0
				}
			}
			endTest = true;
			var lessonStatus = learnerData.GetProgress(currentUnit,currentLesson);
			if(lessonStatus[0] == "completed")
			{
				var completion = "completed";
				var where = totalScreens + " of " + totalScreens;
				var completionDate = lessonStatus[4];
			}
			else if(lessonComplete)
			{
				var completion = "completed";
				var where = totalScreens + " of " + totalScreens;
				var completionDate = GetCurrentDate("long");
			}
			else
			{
				var completion = "not completed";
				var where = eval(currentScreenNum+1) + " of " + totalScreens;
				var completionDate = "";
			}
			learnerData.SetProgress(completion,lessonStatus[1],lessonStatus[2],lessonStatus[3],lessonStatus[4],currentUnit,currentLesson);
			learnerData.SetCourseCompletion(GetCourseCompletion());
			NavTestFeedback();
		}

		else
		{
			buttonClicked = "next";
			NavExitLesson();
		}
		return;
	}
	currentScreenNum++;

	//---complete lesson on last screen-------------------------//
	if(currentScreenNum == lastScreen) lessonComplete = true;
	//----------------------------------------------------------//
	if(lessonType == "test" || lessonType == "exam" || lessonType=="customtest")
	{
    if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT")
    {
      selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
			taskData[currentUnit][currentLesson][currentScreenNum-1].id = currentScreenNum;
      taskData[currentUnit][currentLesson][currentScreenNum-1].selectedOptionID = selectedOptionID;
      taskData[currentUnit][currentLesson][currentScreenNum-1].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
      taskData[currentUnit][currentLesson][currentScreenNum-1].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
    }
		if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT"){
			var rows = spread.getSheet(0).getDirtyRows();
			if (rows.length > 0) {
				selectedOptionID = TrimStr(GetHTMFromSheet());
				taskData[currentUnit][currentLesson][currentScreenNum-1].selectedOptionID = selectedOptionID;
			}else{
				selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum-1].selectedOptionID;
			}
			taskData[currentUnit][currentLesson][currentScreenNum-1].id = currentScreenNum;
			taskData[currentUnit][currentLesson][currentScreenNum-1].prevalue = JSON.stringify(spread.toJSON());
			taskData[currentUnit][currentLesson][currentScreenNum-1].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
		}
		if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
		{
			if(parent.contentFrame.document.getElementById("answer")){
				selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
			}
			if(parent.contentFrame.document.getElementById("answer1")){
					var inputs = parent.contentFrame.document.getElementsByTagName("input")
					selectedOptionID = ""
					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="text")
						{
							selectedOptionID += "##T##" + TrimStr(parent.contentFrame.document.getElementsByTagName("input")[i].value);
						if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
				}
		}
		if(answerTypeCD == "MATCHING")
			{
				var isSelected = false
				selectedOptionID = "";
				for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++)
				{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
					if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
				}
				if(!isSelected)selectedOptionID = "";
		}

		if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
		{
			var isChecked = false
			selectedOptionID = "";
			var inputs = parent.contentFrame.document.getElementsByTagName("input")
			for(var i=0;i<inputs.length;i++)
			{
				if(inputs[i].type=="checkbox")
				{
				    if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
					{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
					}
				}
				if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
			}
			if(!isChecked)selectedOptionID = "";
		}

		if(currentScreenFlag != "AAT")
		{
			if(questionRendered){
				if(lessonType == "exam"){
					SendInteractionInfo(currentScreenNum-1, selectedOptionID, currentScreenObj,currentLesson,flagclick);
				}
				learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
			}
		}else
			if(lessonType == "exam"){
				{
					for(var i = 0; i<aatQuestionJump; i++)
					{
						SendInteractionInfo(i, i, currentScreenObj,currentLesson,flagclick);
					}
				}
			var resp = learnerData.GetResponse(aatqstartpos,currentUnit,currentLesson);
			learnerData.SetResponse(aatqstartpos,resp[1],resp[2],"",currentUnit,currentLesson,flagclick);
		}
		if(currentQuestionType == "Review All" )
		{
			currentQuestionNum = testQuestionSequence[currentScreenNum];
		}
		else if(currentQuestionType == "Review Selected")
		{
			for (var ii=currentQuestionNum+1; ii<testQuestionSequence.length; ii++){
				if(questionStatus[ii][1] == 1){
					currentQuestionNum = ii
					break;
				}
			}
		}
		else if(currentQuestionType == "Review Incomplete")
		{
			if (currentScreenFlag == "AAT")
			{
				for (var ii=currentScreenNum; ii<testQuestionSequence.length; ii++){
					if(questionStatus[ii][0] == 1){
						currentQuestionNum = ii
						break;
					}
				}
			}
			else
			{
				for (var ii=currentQuestionNum+1; ii<testQuestionSequence.length; ii++){
					if(questionStatus[ii][0] == 1){
						currentQuestionNum = ii
						break;
					}
				}
			}
		}
		if (currentQuestionTypeMode == "Navigator Mode")
		{
			currentQuestionNum = testQuestionSequence[currentScreenNum];
		}
		currentScreenObj = GetNode(currentLessonObj, "screen", currentQuestionNum);
		currentScreenType = currentScreenObj.getAttribute("type");
		if(currentScreenType == "question")answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
	}
	else
	{
		currentScreenObj = GetNode(currentLessonObj, "screen", currentScreenNum);
		currentScreenType = currentScreenObj.getAttribute("type");
		if(currentScreenType == "question")answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentScreenNum);
	}
	selectedOptionID = "";
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		currentScreenFlag = "AAT";
		if (incompleteQuestionNumAAT == 0){
			incompleteQuestionNumAAT = currentScreenNum+1
		}
		else{
			incompleteQuestionNumAAT = incompleteQuestionNumAAT+1
		}

		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		currentScreenFlag = "";
		loadXMLDoc(xmlFileName, processReqChangeForData);
	}
	/***************** For mode type issue (sumit)**********/
	if (selectedLessType == "exam") {
		parent.contentFrame.document.getElementById("navigator_but").style.display="none";
		parent.contentFrame.document.getElementById("foot_note").style.display="none";

	}
	/***************/
}


function NavPrevious()
{
	previousClicked = true;
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	if(questionRendered) AddToResponses();
	if(currentScreenType == "questionreview")
	{
		NavPreviousReviewQuestion();
		return;
	}
	if(inreviewmode){
		instructionRendered = true;
		questionRendered = false;
	}
	if(sectionStart && questionRendered){
		if(lessonType == "test" || lessonType == "exam" || lessonType=="customtest")
		{
	    if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT")
	    {
	      selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
				taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
	      taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
	      taskData[currentUnit][currentLesson][currentScreenNum].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
	      taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
	    }
			if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT"){
				var rows = spread.getSheet(0).getDirtyRows();
				if (rows.length > 0) {
					selectedOptionID = TrimStr(GetHTMFromSheet());
					taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
				}else{
					selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID;
				}
				taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
				taskData[currentUnit][currentLesson][currentScreenNum].prevalue = JSON.stringify(spread.toJSON());
				taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
			}
	    if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
			{
				if(parent.contentFrame.document.getElementById("answer")){
					selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
				}
			if(parent.contentFrame.document.getElementById("answer1")){
						var inputs = parent.contentFrame.document.getElementsByTagName("input")
						selectedOptionID = ""
						for(var i=0;i<inputs.length;i++)
						{
							if(inputs[i].type=="text")
							{
								selectedOptionID += "##T##" + TrimStr(parent.contentFrame.document.getElementsByTagName("input")[i].value);
								if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
							}
						}
						if(!isChecked)selectedOptionID = "";
					}
			}
			if(answerTypeCD == "MATCHING")
			{
				var isSelected = false
				selectedOptionID = "";
				for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++)
				{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
					if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
				}
				if(!isSelected)selectedOptionID = "";
			}
			if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
			{
				var isChecked = false
				selectedOptionID = "";
				var inputs = parent.contentFrame.document.getElementsByTagName("input")
				for(var i=0;i<inputs.length;i++)
				{
					if(inputs[i].type=="checkbox")
					{
					    if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
						{
						selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
						}
					if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
					}
				}
				if(!isChecked)selectedOptionID = "";
			}
			if(currentScreenFlag != "AAT")
			{
				if(questionRendered){
					if(lessonType == "exam"){
						SendInteractionInfo(currentScreenNum, selectedOptionID, currentScreenObj,currentLesson,flagclick);
					}
					learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
				}
			}
			if(currentQuestionType == "Review All" )
			{
				currentQuestionNum = testQuestionSequence[currentScreenNum];
			}
			else if(currentQuestionType == "Review Selected")
			{
				for (var ii=currentQuestionNum-1; ii>=0; ii--){
						if(questionStatus[ii][1] == 1){
							currentQuestionNum = ii
							break;
						}
					}
			}
			else if(currentQuestionType == "Review Incomplete")
			{
				for (var ii=currentQuestionNum-1; ii>=0; ii--){
						if(questionStatus[ii][0] == 1){
							currentQuestionNum = ii
							break;
						}
					}
			}

			if (currentQuestionTypeMode == "Navigator Mode")
			{
				currentQuestionNum = testQuestionSequence[currentScreenNum];
			}

			currentScreenObj = GetNode(currentLessonObj, "screen", currentQuestionNum);
			currentScreenType = currentScreenObj.getAttribute("type");
			if(currentScreenType == "question")answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
			xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
		}
		loadingSectionStart = true;
		xmlFileName = contentPath + currentScreenObj.getAttribute("sectionstart");
		loadXMLDoc(xmlFileName, processReqChangeForData);
		return;
	}
	if(currentScreenFlag == "AAT")
	{
		if((currentScreenNum-(aatQuestionJump-1)) == firstScreen)
		{
			buttonClicked = "back";
			NavExitLesson();
			return;
		}
		currentScreenNum -= aatQuestionJump;
	}
	else
	{
		if(currentScreenNum == firstScreen)
		{
			SetNavButtons();
			NavExitLesson();
			return;
		}
		currentScreenNum--;
	}
	if(lessonType == "test" || lessonType == "exam" || lessonType=="customtest")
	{
    if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT" && !instructionRendered)
    {
      selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
			taskData[currentUnit][currentLesson][currentScreenNum+1].id = currentScreenNum;
      taskData[currentUnit][currentLesson][currentScreenNum+1].selectedOptionID = selectedOptionID;
      taskData[currentUnit][currentLesson][currentScreenNum+1].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
      taskData[currentUnit][currentLesson][currentScreenNum+1].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
    }
		if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT" && !instructionRendered){
			var rows = spread.getSheet(0).getDirtyRows();
			if (rows.length > 0) {
				selectedOptionID = TrimStr(GetHTMFromSheet());
				taskData[currentUnit][currentLesson][currentScreenNum+1].selectedOptionID = selectedOptionID;
			}else{
				selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum+1].selectedOptionID;
			}
			taskData[currentUnit][currentLesson][currentScreenNum+1].id = currentScreenNum;
			taskData[currentUnit][currentLesson][currentScreenNum+1].prevalue = JSON.stringify(spread.toJSON());
			taskData[currentUnit][currentLesson][currentScreenNum+1].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
		}
    if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT" && !instructionRendered)
		{
			if(parent.contentFrame.document.getElementById("answer")){
				selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
			}
		if(parent.contentFrame.document.getElementById("answer1")){
					var inputs = parent.contentFrame.document.getElementsByTagName("input")
					selectedOptionID = ""
					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="text")
						{
							selectedOptionID += "##T##" + TrimStr(parent.contentFrame.document.getElementsByTagName("input")[i].value);
							if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
				}
		}
		if(answerTypeCD == "MATCHING" && !instructionRendered)
		{
			var isSelected = false
			selectedOptionID = "";
			for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++)
			{
				selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
				if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
			}
			if(!isSelected)selectedOptionID = "";
		}
		if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER" && !instructionRendered)
		{
			var isChecked = false
			selectedOptionID = "";
			var inputs = parent.contentFrame.document.getElementsByTagName("input")
			for(var i=0;i<inputs.length;i++)
			{
				if(inputs[i].type=="checkbox")
				{
				    if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
					{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
					}
				if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
				}
			}
			if(!isChecked)selectedOptionID = "";
		}
		if(currentScreenFlag != "AAT")
		{
			if(questionRendered){
				if(lessonType == "exam"){
					SendInteractionInfo(currentScreenNum+1, selectedOptionID, currentScreenObj,currentLesson,flagclick);
				}
				learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
			}
		}
		if(currentQuestionType == "Review All" )
		{
			currentQuestionNum = testQuestionSequence[currentScreenNum];
		}
		else if(currentQuestionType == "Review Selected")
		{
			for (var ii=currentQuestionNum-1; ii>=0; ii--){
					if(questionStatus[ii][1] == 1){
						currentQuestionNum = ii
						break;
					}
				}
		}
		else if(currentQuestionType == "Review Incomplete")
		{
			for (var ii=currentQuestionNum-1; ii>=0; ii--){
					if(questionStatus[ii][0] == 1){
						currentQuestionNum = ii
						break;
					}
				}
		}

		if (currentQuestionTypeMode == "Navigator Mode")
		{
			currentQuestionNum = testQuestionSequence[currentScreenNum];
		}

		currentScreenObj = GetNode(currentLessonObj, "screen", currentQuestionNum);
		currentScreenType = currentScreenObj.getAttribute("type");
		if(currentScreenType == "question")answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
	}
	else
	{
		currentScreenObj = GetNode(currentLessonObj, "screen", currentScreenNum);
		currentScreenType = currentScreenObj.getAttribute("type");
		if(currentScreenType == "question")answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentScreenNum);
	}
	selectedOptionID = "";
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		currentScreenFlag = "AAT";
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		currentScreenFlag = "";
		loadXMLDoc(xmlFileName, processReqChangeForData);
	}
	if (selectedLessType == "exam") {
		parent.contentFrame.document.getElementById("navigator_but").style.display="none";
		parent.contentFrame.document.getElementById("foot_note").style.display="none";

	}
}

function but_hide()
{
 parent.contentFrame.document.getElementById("back").style.display = "none"
}


function but_show()
{
 parent.contentFrame.document.getElementById("back").style.display = ""
}


function NavNextReviewQuestion()
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	questionRendered = true;
	if(currentScreenNum == lastScreen)
	{
		return;
	}
	currentScreenNum++;
	currentQuestionNum = testQuestionSequence[currentScreenNum];
	currentScreenObj = GetNode(currentLessonObj, "screen", currentQuestionNum);
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		currentScreenFlag = "AAT";
		reviewmode = true;
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		currentScreenFlag = "";
		currentScreenType = "questionreview";
		answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
		loadXMLDoc(xmlFileName, processReqChangeForData);
		parent.contentFrame.document.getElementById("check_review").style.visibility="hidden";
		SetNavButtons()
	}
}


function NavPreviousReviewQuestion()
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	instructionRendered = true;
	if(currentScreenFlag == "AAT")
	{
		if((currentScreenNum-(aatQuestionJump-1)) == firstScreen)
		{
			return;
		}
		currentScreenNum -= aatQuestionJump;
	}
	else
	{
		if(currentScreenNum == firstScreen)
		{
			return;
		}
		currentScreenNum--;
	}
	currentQuestionNum = testQuestionSequence[currentScreenNum];
	currentScreenObj = GetNode(currentLessonObj, "screen", currentQuestionNum);

	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		currentScreenFlag = "AAT";
		reviewmode = true;
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
		parent.contentFrame.document.getElementById("clockwith_timer").style.visibility="hidden";
		parent.contentFrame.document.getElementById("check_review").style.visibility="hidden";
	}
	else
	{
		currentScreenFlag = "";
		currentScreenType = "questionreview";
		answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
		loadXMLDoc(xmlFileName, processReqChangeForData);
		parent.contentFrame.document.getElementById("check_review").style.visibility="hidden"
		SetNavButtons()
	}
}

/***************** For mode type issue (sumit)**********/
function testfeedback_NavExit()
{
	var incopleteQues=0;
	for(var i=0;i<testQuestionSequence.length;i++)

		{
			var learnerResponse = learnerData.GetResponse(testQuestionSequence[i],currentUnit, currentLesson);
			if(learnerResponse[1] == "" || learnerResponse[1] == null)
			{
				flagAllAttempted = false;

				incopleteQues=incopleteQues+1;
			}
		}
		if(flagAllAttempted)
		{
			parent.contentFrame.document.getElementById("endTestPopupText").innerHTML = "This will end this exam. If you have incomplete items this will be marked incorrect. Do you wish to exit?";

		}

		if (selectedLessType == "test") {
			parent.contentFrame.document.getElementById("Endtest_Page").style.left = parent.document.documentElement.clientWidth/2 - 196
			parent.contentFrame.document.getElementById("Endtest_Page").style.top = parent.document.documentElement.clientHeight/2 - 105
			parent.contentFrame.document.getElementById("Endtest_Page").style.display= "block";
		}else{
			parent.contentFrame.document.getElementById("EndExam_Page").style.display= "block";
			parent.contentFrame.document.getElementById("incomplete_que").innerHTML= incopleteQues;
			parent.contentFrame.document.getElementById("inco_que").innerHTML= incopleteQues;
		}

}
/***************** For mode type issue (sumit)**********/
function testfeedback_ready()
{

	if(flagAllAttempted)
	{

		flagNavigatorMode = false;

		if (selectedLessType == "test") {
			parent.contentFrame.document.getElementById("Endtest_Page").style.display= "none";
			NavEndTest();

		}else{
			parent.contentFrame.document.getElementById("EndExam_Page").style.display= "none";
			LogOut();
		}
	}
	else
	{
		if (selectedLessType == "test") {
			parent.contentFrame.document.getElementById("Endtest_Page").style.display= "none";
			parent.contentFrame.document.getElementById("Endtest_Page_Confirm").style.left = parent.document.documentElement.clientWidth/2 - 196
			parent.contentFrame.document.getElementById("Endtest_Page_Confirm").style.top = parent.document.documentElement.clientHeight/2 - 105
			parent.contentFrame.document.getElementById("Endtest_Page_Confirm").style.display= "block";
		}else{
			parent.contentFrame.document.getElementById("EndExam_Page").style.display= "none";
			parent.contentFrame.document.getElementById("EndExam_Page_Confirm").style.display= "block";
		}
	}
}

/***************** For mode type issue (sumit)**********/
function testfeedback_ready_confirm()
{
	parent.contentFrame.document.getElementById("Endtest_Page_Confirm").style.display= "none";
	flagNavigatorMode = false;

	if (selectedLessType == "test") {
		NavEndTest();
	}else{
		LogOut();
	}

}



function testfeedback_close()
{
if(selectedLessType == "test"){
	parent.contentFrame.document.getElementById("Endtest_Page").style.display= "none";
	}else{
		parent.contentFrame.document.getElementById("EndExam_Page").style.display= "none";
	}
}

function testfeedback_close_confirm()
{
	if(selectedLessType == "test"){
		parent.contentFrame.document.getElementById("Endtest_Page_Confirm").style.display= "none";
	}else{
		parent.contentFrame.document.getElementById("EndExam_Page_Confirm").style.display= "none";
	}

}

function NavExit()
{
	NavExitLesson();
}


function NavExitLesson()
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	var lessonStatus = learnerData.GetProgress(currentUnit,currentLesson);
	if((lessonType == "exam" || lessonType == "test" || lessonType=="customtest") && currentScreenType == "question")
	{
		if(lessonStatus[0] == "completed")
		{
			var completion = "completed";
			var where = totalScreens + " of " + totalScreens;
			var completionDate = lessonStatus[4];
		}
		else if(lessonComplete)
		{
			var completion = "completed";
			var where = totalScreens + " of " + totalScreens;
			var completionDate = GetCurrentDate("long");
		}
		else
		{
			var completion = "not completed";
			var where = eval(currentScreenNum+1) + " of " + totalScreens;
			var completionDate = "";
		}
		if(lessonStatus[1] == "passed")
		{
			var examresult = "passed";
		}
		else
		{
			var examresult = "not passed";
		}
	}
	else
	{
		if((lessonStatus[0] == "completed"))
		{
			var completion = "completed";
			var where = totalScreens + " of " + totalScreens;
			var examresult = "";
			var completionDate = lessonStatus[4];
		}
		else if(lessonComplete)
		{
			var completion = "completed";
			var where = totalScreens + " of " + totalScreens;
			var examresult = "";
			var completionDate = GetCurrentDate("long");
		}
		else
		{
			var completion = "active";
			var where = eval(currentScreenNum+1) + " of " + totalScreens;
			var examresult = "";
			var completionDate = "";
		}
	}
	learnerData.SetProgress(completion,examresult,where,examTime,completionDate,currentUnit,currentLesson);
	SetSessionTime();
	learnerData.SetCourseCompletion(GetCourseCompletion());
	learnerData.Set();
	objAICC.CommitData();
	if(!aiccFinishCalled)
	{
		lessonComplete = false;
		if((currentScreenNum == firstScreen) && (buttonClicked == "back"))
		{
			buttonClicked = "";
			if(currentLesson > 0)
			{
				tmpcurrentLessonObj = GetNode(currentUnitObj, "lesson", eval(Number(currentLesson)-1));
				tmplastscreen = tmpcurrentLessonObj.getElementsByTagName("screen").length - 1;
				CallLesson(currentUnit, eval(Number(currentLesson)-1));
			}
			else
			{
				NavMainMenu();
			}
		}
		else if((currentScreenNum == lastScreen) && (buttonClicked == "next"))
		{
			buttonClicked = "";
			if(currentLesson < totalLessons-1)
			{
				CallLesson(currentUnit, eval(Number(currentLesson)+1));
			}
			else
			{
				NavMainMenu();
			}
		}
		else
		{
			NavMainMenu();
		}
	}
}
/*
function NavEndTest()
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";

	if (lessonType == "exam") testCompleteLock = true;
	NavTestSummary();
}
*/
function NavEndTest()
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	lessonComplete = true;
	NavTestComplete();
	/*
	switch(aftercomponentcompletepage.toLowerCase())
	{
		case "test_complete":
			NavTestComplete();
			break;
		case "test_summary":
			NavTestSummary();
			break;
		case "test_review":
			NavTestReview();
			break;
		default:
			NavExitLesson();
	}*/
}

function EndTest()
{
	/*
	if(!examTimedOut)
	{
		if(!confirm(END_TEST_STR)) return;
		examTimedOut = false;
	}
	*/

	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	if(examTimeRemaining <= 0)
	{
		parent.contentFrame.document.getElementById("Endtest_popup").style.display = "block";
		examTimedOut = false;
	}
	if(lessonType == "exam" || lessonType == "test" || lessonType=="customtest")
	{
		if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT")
		{
		  selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
			taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
		  taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
		  taskData[currentUnit][currentLesson][currentScreenNum].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
		  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
		}
		if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT"){
			var rows = spread.getSheet(0).getDirtyRows();
			if (rows.length > 0) {
				selectedOptionID = TrimStr(GetHTMFromSheet());
				taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
			}else{
				selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID;
			}
			taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
			taskData[currentUnit][currentLesson][currentScreenNum].prevalue = JSON.stringify(spread.toJSON());
		  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
		}
    if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT"){
			if(parent.contentFrame.document.getElementById("answer")){
				selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
				}
			if(parent.contentFrame.document.getElementById("answer1")){
					var inputs = parent.contentFrame.document.getElementsByTagName("input")
					selectedOptionID = ""
					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="text")
						{
							selectedOptionID += "##T##" + TrimStr(parent.contentFrame.document.getElementsByTagName("input")[i].value);
							if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
				}

		}
		if(answerTypeCD == "MATCHING")
		{
			var isSelected = false
			selectedOptionID = "";
			for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++){
				selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
				if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
			}
			if(!isSelected)selectedOptionID = "";
		}
		if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
		{
			var isChecked = false
			selectedOptionID = "";
			var inputs = parent.contentFrame.document.getElementsByTagName("input")
			for(var i=0;i<inputs.length;i++)
			{
				if(inputs[i].type=="checkbox")
				{
				    if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
					{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
					}
				if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
				}
			}
			if(!isChecked)selectedOptionID = "";
		}
		if(currentScreenFlag != "AAT"){
			if(questionRendered){
			  if(lessonType == "exam"){
			    SendInteractionInfo(currentScreenNum, selectedOptionID, currentScreenObj,currentLesson,flagclick);
			  }
			  learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
			}
		}
		endTest = true;
		NavEndTest();
	}
	else
	{
		selectedOptionID = "";
		NavExitLesson();
	}
}
function SuspendTest()
{
	if(!confirm(SUSPEND_TEST_STR))
	return;
	if(lessonType == "exam" || lessonType == "test" || lessonType=="customtest")
	{
		if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT")
		{
		  selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
			taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
		  taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
		  taskData[currentUnit][currentLesson][currentScreenNum].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
		  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
		}
		if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT"){
			var rows = spread.getSheet(0).getDirtyRows();
			if (rows.length > 0) {
				selectedOptionID = TrimStr(GetHTMFromSheet());
				taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
			}else{
				selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID;
			}
			taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
			taskData[currentUnit][currentLesson][currentScreenNum].prevalue = JSON.stringify(spread.toJSON());
		  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
		}
		if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
		{
			if(parent.contentFrame.document.getElementById("answer")){
				selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
				}
			if(parent.contentFrame.document.getElementById("answer1")){
					var inputs = parent.contentFrame.document.getElementsByTagName("input")
					selectedOptionID = ""
					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="text")
						{
							selectedOptionID += "##T##" + TrimStr(parent.contentFrame.document.getElementsByTagName("input")[i].value);
							if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
				}

		}
		if(answerTypeCD == "MATCHING")
		{
			var isSelected = false
			selectedOptionID = "";
			for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++){
				selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
				if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
			}
			if(!isSelected)selectedOptionID = "";
		}
		if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
		{
			var isChecked = false
			selectedOptionID = "";
			var inputs = parent.contentFrame.document.getElementsByTagName("input")
			for(var i=0;i<inputs.length;i++)
			{
				if(inputs[i].type=="checkbox")
				{
				    if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
					{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
					}
				if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
				}
			}
			if(!isChecked)selectedOptionID = "";
		}
		if(currentScreenFlag != "AAT"){
			if(questionRendered){
			  if(lessonType == "exam"){
			    SendInteractionInfo(currentScreenNum, selectedOptionID, currentScreenObj,currentLesson,flagclick);
			  }
			  learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
			}
		}
	}
	if(timed == "R")
	{
		clearInterval(timeRemainingTimer);
		examTime = examtimeoutduration - examTimeRemaining;
	}
	selectedOptionID = "";
	NavExitLesson();
}
function UpdatePartialData()
{
	var lessonStatus = learnerData.GetProgress(currentUnit,currentLesson);
	if(lessonStatus[0] == "completed")
	{
		var where = totalScreens + " of " + totalScreens;
	}
	else
	{
		var where = eval(currentScreenNum+1) + " of " + totalScreens;
	}
	if(examTime == null || examTime == undefined) examTime = lessonStatus[3];
	learnerData.SetProgress(lessonStatus[0],lessonStatus[1],where,examTime,lessonStatus[4],currentUnit,currentLesson);
	SetSessionTime();
	learnerData.Set();
	objAICC.CommitData();
}
function Clear()
{
	selectedOptionID = "";
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		currentScreenFlag = "AAT";
		clearresponse = true;
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		var inputObjs = parent.contentFrame.document.getElementsByTagName("input");
		for(var i=0;i<inputObjs.length;i++)
		{
			if(inputObjs[i].id == "answer")
			{
				if(answerTypeCD == "MC_LID")
				{
					inputObjs[i].checked = false;
				}
				if(answerTypeCD == "FILLIN_SINGLE_ANSWER")
				{
					inputObjs[i].value = "";
				}
			}
		}
		if(answerTypeCD == "MATCHING")
		{
			var selectObjs = parent.contentFrame.document.getElementsByTagName("select");
			for(var i=0;i<selectObjs.length;i++)
			{
				selectObjs[i].selectedIndex = 0;
			}
		}
		parent.contentFrame.document.getElementById("rationale").style.display = "none";
	}
}

function Cancel()
{
	backtointro = true;
	CallLesson(currentUnit, currentLesson-1);
	//NavMainMenu();
}

function NavMainMenu()
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	currentScreenNum = 0;
	Reviewtab = 0;
	currentScreenType = "teststart";
	xmlObj = configObj;
	currentLessonTitle = currentLessonTitle;
	transformXML();
}

function NavTestComplete()
{
	if(endTest)
	{
		SetExamData();
	}
	currentScreenType = "testcomplete";
	xmlFileName = xmlPath + "IN_dummy.xml";
	loadXMLDoc(xmlFileName, processReqChangeForData);
	endTest = false;
}

function NavTestReview()
{

	if(!returning || endTest)
	{
		SetExamData();
	}
	returning = false;
	currentScreenType = "testreview";
	xmlFileName = xmlPath + "IN_dummy.xml";

	loadXMLDoc(xmlFileName, processReqChangeForData);
	endTest = false;
}

function NavTestSummary()
{
	if(endTest)
	{
		SetExamData();
	}
	currentScreenType = "testsummary";
	xmlFileName = xmlPath + "IN_dummy.xml";
	loadXMLDoc(xmlFileName, processReqChangeForData);
	endTest = false;
}

function NavTestFeedback()
{
	currentQuestionTypeMode = "";
	globalFlaggedQnum = 0;
	if(parent.contentFrame.document.getElementById("Review_Screen_id"))
	{
		if(lessonType == "exam" || lessonType == "test" || lessonType=="customtest")
		{
			if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT")
			{
			  selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
				taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
			  taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
			  taskData[currentUnit][currentLesson][currentScreenNum].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
			  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
			}
			if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT"){
				var rows = spread.getSheet(0).getDirtyRows();
				if (rows.length > 0) {
					selectedOptionID = TrimStr(GetHTMFromSheet());
					taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
				}else{
					selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID;
				}
				taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
				taskData[currentUnit][currentLesson][currentScreenNum].prevalue = JSON.stringify(spread.toJSON());
			  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
			}
			if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
			{
				if(parent.contentFrame.document.getElementById("answer")){
					selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
					}
				if(parent.contentFrame.document.getElementById("answer1")){
					var inputs = parent.contentFrame.document.getElementsByTagName("input")
					selectedOptionID = ""
					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="text")
						{
							selectedOptionID += "##T##" + TrimStr(parent.contentFrame.document.getElementsByTagName("input")[i].value);
							if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
				}
			}
			if(answerTypeCD == "MATCHING")
			{
				var isSelected = false
				selectedOptionID = "";
				for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++){
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
					if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
				}
				if(!isSelected)selectedOptionID = "";
			}
			if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
			{
				var isChecked = false
				selectedOptionID = "";
				var inputs = parent.contentFrame.document.getElementsByTagName("input")
				for(var i=0;i<inputs.length;i++)
				{
					if(inputs[i].type=="checkbox")
					{
						if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
						{
						selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
						}
					if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
					}
				}
				if(!isChecked)selectedOptionID = "";
			}
			if(selectedOptionID != ""){
				questionStatus[currentQuestionNum][0] = 0
			}
			if(currentScreenFlag != "AAT"){
				if(questionRendered){
				  if(lessonType == "exam"){
				    SendInteractionInfo(currentScreenNum, selectedOptionID, currentScreenObj,currentLesson,flagclick);
				  }
				  learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
				}
			}
		}
	}
	currentScreenType = "testfeedback";
	xmlFileName = xmlPath + "IN_dummy.xml";
	loadXMLDoc(xmlFileName, processReqChangeForData);
}

function NavTestFeedbackNavigatorSort()
{

	if (navigatorSortAsc)
		{
			parent.contentFrame.document.getElementById("quesfeedbacklist").innerHTML = PreparefeedbackPageforNavigator();
			navigatorSortAsc = false;
		}
	else
		{
			parent.contentFrame.document.getElementById("quesfeedbacklist").innerHTML = PreparefeedbackPageforNavigatorDesc();
			navigatorSortAsc = true;
		}
}

function NavTestFeedbackNavigator()
{
	highlightArray[currentScreenNum] = parent.contentFrame.storeHighlights();
	if(currentScreenFlag != "AAT"){
		if(questionRendered){
			if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT")
			{
			  selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
				taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
			  taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
			  taskData[currentUnit][currentLesson][currentScreenNum].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
			  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
			}
			if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT"){
				var rows = spread.getSheet(0).getDirtyRows();
				if (rows.length > 0) {
					selectedOptionID = TrimStr(GetHTMFromSheet());
					taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
				}else{
					selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID;
				}
				taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
				taskData[currentUnit][currentLesson][currentScreenNum].prevalue = JSON.stringify(spread.toJSON());
			  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
			}
			if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
			{
				if(parent.contentFrame.document.getElementById("answer")){
					selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
					}
				if(parent.contentFrame.document.getElementById("answer1")){
					var inputs = parent.contentFrame.document.getElementsByTagName("input")

					selectedOptionID = ""

					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="text")
						{
							selectedOptionID += "##T##" + TrimStr(parent.contentFrame.document.getElementsByTagName("input")[i].value);
							if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
				}
			}
			if(answerTypeCD == "MATCHING")
			{
				var isSelected = false
				selectedOptionID = "";
				for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++){
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
					if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
				}
				if(!isSelected)selectedOptionID = "";
			}
			if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
			{
				var isChecked = false
				selectedOptionID = "";
				var inputs = parent.contentFrame.document.getElementsByTagName("input")
				for(var i=0;i<inputs.length;i++)
				{
					if(inputs[i].type=="checkbox")
					{
						if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
						{
						selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
						}
					if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
					}
				}
				if(!isChecked)selectedOptionID = "";
			}
			if(lessonType == "exam"){
				SendInteractionInfo(currentScreenNum, selectedOptionID, currentScreenObj,currentLesson,flagclick);
			}
			learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
		}
	}
	else
	{
		if(lessonType == "exam"){
		var resp = learnerData.GetResponse(aatqstartpos,currentUnit,currentLesson);
		learnerData.SetResponse(aatqstartpos,resp[1],resp[2],"",currentUnit,currentLesson,flagclick);
		}
	}
	parent.contentFrame.document.getElementById("navigator_popup").style.display = "block"
	if(totalScreens == aatQuestionJump)
	{
		parent.contentFrame.document.getElementById("shortAnsReviewTbl").style.display = "none";
	}
	else
	{

		parent.contentFrame.document.getElementById("quesfeedbacklist").innerHTML = PreparefeedbackPageforNavigator();
		navigatorSortAsc = false;
	}
	var longanswerIncompleteNum = GetLonganswerCompletion();
}



/*function NavTestFeedback()
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	currentScreenNum++;
	if(lessonType == "test" || lessonType == "exam" || lessonType=="customtest")
	{
		if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
		{
			selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
		}
		if(answerTypeCD == "MATCHING")
			{
				var isSelected = false
				selectedOptionID = "";
				for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++)
				{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
					if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
				}
				if(!isSelected)selectedOptionID = "";
		}

		if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
		{
			var isChecked = false
			selectedOptionID = "";
			var inputs = parent.contentFrame.document.getElementsByTagName("input")
			for(var i=0;i<inputs.length;i++)
			{
				if(inputs[i].type=="checkbox")
				{
				    if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
					{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
					}
				if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
				}
			}
			if(!isChecked)selectedOptionID = "";
		}

		if(currentScreenFlag != "AAT")
		{

			if(lessonType == "exam")
			SendInteractionInfo(currentScreenNum-1, selectedOptionID, currentScreenObj,currentLesson,flagclick);
			learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
		}
		if(currentQuestionType == "Review All" )
		{
			currentQuestionNum = testQuestionSequence[currentScreenNum];
		}
		else if(currentQuestionType == "Review Selected")
		{
			SelectQuestionNum = SelectcheckArray[currentScreenNum];
			currentQuestionNum = testQuestionSequence[SelectQuestionNum];
		}
		else if(currentQuestionType == "Review Incomplete")
		{
			IncompleteQuestionNum     = IncompleteArray[currentScreenNum];
			currentQuestionNum = testQuestionSequence[IncompleteQuestionNum];
		}
		currentScreenType = "testfeedback";
		if(currentScreenType == "testfeedback")
		answerTypeCD = currentScreenObj.attributes[4].value;
		xmlFileName = xmlPath + "IN_dummy.xml";
	    loadXMLDoc(xmlFileName, processReqChangeForData);
	}
	else
	{
		currentScreenType = "testfeedback";
		if(currentScreenType == "testfeedback")
		answerTypeCD = currentScreenObj.attributes[4].value;
		xmlFileName = xmlPath + "IN_dummy.xml";
	    loadXMLDoc(xmlFileName, processReqChangeForData);
	}
	selectedOptionID = "";
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		currentScreenFlag = "AAT";
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		currentScreenFlag = "";
		loadXMLDoc(xmlFileName, processReqChangeForData);
	}
	if(lessonType == "test" || lessonType == "exam" || lessonType=="customtest")
	{
		if(currentScreenType != "questionreview" && !reviewmode)
		{
			UpdatePartialData();
		}
	}
}*/

function NavReviewQuestion(qnum)
{
	currentQuestionType = "Review All"
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	currentScreenNum   = qnum;
	currentQuestionNum = testQuestionSequence[currentScreenNum]
	currentScreenObj   = GetNode(currentLessonObj, "screen", currentQuestionNum);
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		reviewmode = true;
		currentScreenFlag = "AAT";
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
		parent.contentFrame.document.getElementById("clockwith_timer").style.visibility="hidden";
		parent.contentFrame.document.getElementById("check_review").style.visibility="hidden";
	}
	else
	{
		currentScreenType = "questionreview";
		answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
		loadXMLDoc(xmlFileName, processReqChangeForData);
		parent.contentFrame.document.getElementById("check_review").style.visibility="hidden";
	}
}

function NavNavigatorQuestion(qnum, renderquestion)
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	if((currentScreenType == "question") && questionRendered) AddToResponses();
	currentScreenNum = qnum;
	currentQuestionNum = testQuestionSequence[currentScreenNum]
	currentScreenObj   = GetNode(currentLessonObj, "screen", currentQuestionNum);
	currentQuestionTypeMode = "Navigator Mode";
	currentQuestionType = "Review All";
  instructionRendered = renderquestion;
	reviewmode = false;

	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		currentScreenFlag = "AAT";
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		currentScreenFlag = currentScreenObj.getAttribute("flag")
		currentScreenType = "question";
		answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
		loadXMLDoc(xmlFileName, processReqChangeForData);
	}
	flagNavigatorMode = true;
	SetNavButtons();
}



//------------------Add Feedback ReviewAll functon()---------------------//
function Review_checkboxselect(id)
{
	var count=0;
	for(var i=0; i<questionStatus.length;i++)	{
		if(questionStatus[i][1] == 1){
			count =1
			break;
		}
	}

	if(count<=0)
	{
		parent.contentFrame.document.getElementById("Not_selected").style.display ="block"
	}
	else
	{
		parent.contentFrame.document.getElementById("Not_Incompleted").style.display ="none"
		ReviewfeedbackQuestion(id)
	}
}


function Not_selected_close()
{
	parent.contentFrame.document.getElementById("Not_selected").style.display ="none"
}

function Review_IncompleteQuestion(id)
{
	var count=0;

	for(var i=0; i<questionStatus.length;i++)	{
		if(questionStatus[i][0] == 1){
			count =1
			break;
		}
	}
	if(count<=0)
	{
		parent.contentFrame.document.getElementById("Not_Incompleted").style.display ="block"
	}
	else
	{
		parent.contentFrame.document.getElementById("Not_Incompleted").style.display ="none"
		ReviewfeedbackQuestion(id)
	}
}


function Not_Incompleted_close()
{
	parent.contentFrame.document.getElementById("Not_Incompleted").style.display ="none"
}


function ReviewfeedbackQuestion(id1)
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	inreviewmode = true;
	currentScreenNum   = 0;
	switch(id1)
	{
	case "Review_All_id":
	case "reviewallbtntext":
		currentQuestionType  = "Review All";
		currentQuestionNum = testQuestionSequence[currentScreenNum];
	break;
	case "Review_Incomplete_id":
	case "reviewincompletebtntext":
		currentQuestionType = "Review Incomplete";
		for(var i=0; i<questionStatus.length;i++)	{
			if(questionStatus[i][0] == 1){
				IncompleteQuestionNum = i
				break;
			}
		}
		currentQuestionNum = testQuestionSequence[IncompleteQuestionNum];
	break;
	case "Review_Selected_id":
	case "reviewselectedbtntext":
		currentQuestionType = "Review Selected";
		for(var i=0; i<questionStatus.length;i++)	{
			if(questionStatus[i][1] == 1){
				SelectQuestionNum = i
				break;
			}
		}

		currentQuestionNum = testQuestionSequence[SelectQuestionNum];
	break;
	}
	currentScreenObj = GetNode(currentLessonObj, "screen", currentQuestionNum);
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		currentScreenFlag = "AAT";
		firstIsAat = true;
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		instructionRendered = true;
		currentScreenType = "question";
		answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
		loadXMLDoc(xmlFileName, processReqChangeForData);
	}
	Reviewtab++;
	SetNavButtons()
}


function NavTestIntro()
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	currentScreenType = "testintro";
	xmlFileName = xmlPath + testIntroFileName;
	loadXMLDoc(xmlFileName, processReqChangeForData);
}

function StepStartTest_open()
{
	parent.contentFrame.document.getElementById("teststart_popup").style.left = parent.document.documentElement.clientWidth/2 - 291
	parent.contentFrame.document.getElementById("teststart_popup").style.top = parent.document.documentElement.clientHeight/2 - 85
	parent.contentFrame.document.getElementById("teststart_popup").style.display= "block";
}

function Invalid_Char_open()
{
	parent.contentFrame.document.getElementById("invalid_char_popup").style.display= "block";
}

function StepStartTest()
{
	StartTest()
}

function PoppupButOver(id){
	parent.contentFrame.document.getElementById(id).className = "popup_table_text_Over"
}
function PoppupButOut(id){
  if(parent.contentFrame.document.getElementById(id))
	parent.contentFrame.document.getElementById(id).className = "popup_table_text_Out"
}

function StartTest()
{
	/***************** For mode type issue (sumit)**********/
	selectedLessType=parent.contentFrame.document.getElementById("hiddenlesson_type").value;

	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";

	currentScreenFlag = "";
	if(lessonType == "customtest")
	 {
		testQuestionSequence = customTestSequence;
		learnerData.SetCustomExamData(totalBuildQuestions.toString(), customTestTimed.toString(), customTestDuration.toString());
	}
	else
	{
		testQuestionSequence = newTestSequence;
		allresponsehtml = new Array();
		for(var i = 0;i<testQuestionSequence.length;i++){
		  questionStatus[i] = new Array();
		  questionStatus[i][0] = 0;
		  questionStatus[i][1] = 0;
			allresponsehtml[i] = "";
		}

	}
	learnerData.InitTestData(testQuestionSequence, currentUnit, currentLesson);
	currentScreenType = "question";
	currentScreenNum = 0;
	currentQuestionNum = testQuestionSequence[currentScreenNum];
	currentScreenObj   = GetNode(currentLessonObj, "screen", currentQuestionNum);
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		justLaunched = false;
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
		justLaunched = false;
		loadXMLDoc(xmlFileName, processReqChangeForData);
	}
	if(timed == "R")
	{
		examTimeRemaining = examtimeoutduration;
		timeRemainingTimer = setInterval("ProcessExamTimer();", 1000);
	}
	examTime = 0;
/***************** For mode type issue (sumit)**********/
	if (selectedLessType == "exam") {
		parent.contentFrame.document.getElementById("navigator_but").style.display="none"
		parent.contentFrame.document.getElementById("foot_note").style.display="none"
	}
	return true;
}

function ProcessExamTimer()
{
		if(examTimeRemaining <= 0)
		{
			clearInterval(timeRemainingTimer);
			ProcessExamTimeOut();
			return;
		}
		if(examTimeRemaining <= 300000 && examTimeRemaining > 0)
		{
			if(!fiveMntsRem_popupshown){
				ProcessExamTimefivemnts();
				fiveMntsRem_popupshown = true;
			}
		}
		examTimeRemaining -= 1000;
		if(parent.contentFrame.document.getElementById("pagetimer") || parent.contentFrame.document.getElementById("totalquestionsfeebback"))
		{
	  		 parent.contentFrame.document.getElementById("pagetimer").innerHTML = "Time Remaining <span class=\"\">" + FormatTime(examTimeRemaining) +"</span>";
		}
}

function ResumeTest()
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	testQuestionSequence = learnerData.GetQuestionSequence(currentUnit, currentLesson);
	selectedOptionID = "";
	currentScreenType = "question";

	if(currentQuestionType == "Review All" )
	{
		currentQuestionNum = testQuestionSequence[currentScreenNum];
	}
	else if(currentQuestionType == "Review Selected")
	{
		currentQuestionNum = testQuestionSequence[SelectQuestionNum];
	}
	else if(currentQuestionType == "Review Incomplete")
	{
		IncompleteQuestionNum  = IncompleteArray[currentScreenNum];
		currentQuestionNum     = testQuestionSequence[IncompleteQuestionNum];
	}

	currentScreenObj = GetNode(currentLessonObj, "screen", currentQuestionNum);
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		SetTaskResponses(currentUnit, currentLesson);
		currentScreenFlag = "AAT";
		justLaunched = false;
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		currentScreenFlag = "";
		answerTypeCD = currentScreenObj.getAttribute("answerTypeCD");
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", currentQuestionNum);
		justLaunched = false;
		loadXMLDoc(xmlFileName, processReqChangeForData);
	}
	examTime = Number(learnerData.GetProgress(currentUnit, currentLesson)[3]);
	if(timed == "R")
	{
		examTimeRemaining  = examtimeoutduration-examTime;
		timeRemainingTimer = setInterval("ProcessExamTimer();", 1000);
	}
}
function SetExamData()
{
	CalculateScore();
	SetSessionTime();
	learnerData.SetCourseCompletion(GetCourseCompletion());
	learnerData.Set();
	objAICC.CommitData();
}

function LogOut()
{
	if(!exitNoSave)
	{
		aiccFinishCalled = true;
		SetSessionTime();
		learnerData.SetCourseCompletion(GetCourseCompletion());
		learnerData.Set();
		objAICC.CommitData();
		if(objAICC.strMode == "API2")
		{
			objAICC.Exit("normal");
		}
		else
		{
			objAICC.Exit("logout");
		}
		objAICC.Finish();
	}
	if(scocloseonexit)
	{
		if(top.window.opener == null)
		{
			if(isIE)
			{
				top.window.opener = top;
				top.window.close();
			}
			else
			{
				parent.window.location.replace(scostaticexitpage);
			}
		}
		else
		{
			top.window.close();
		}
	}
	else
	{
		parent.window.location.replace(scoexitpage);
	}
}


function ProcessCourseTimeOut()
{
	if(courseTimer)
	{
		clearTimeout(courseTimer);
	}
	aiccFinishCalled = true;

	if(currentScreenType == "question")
	{
		if(lessonType == "exam" || lessonType == "test" || lessonType=="customtest")
		{
			if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT")
			{
			  selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
				taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
			  taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
			  taskData[currentUnit][currentLesson][currentScreenNum].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
			  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
			}
			if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT"){
				var rows = spread.getSheet(0).getDirtyRows();
				if (rows.length > 0) {
					selectedOptionID = TrimStr(GetHTMFromSheet());
					taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
				}else{
					selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID;
				}
				taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
				taskData[currentUnit][currentLesson][currentScreenNum].prevalue = JSON.stringify(spread.toJSON());
			  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
			}
			if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
			{
				if(parent.contentFrame.document.getElementById("answer")){
					selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
					}
				if(parent.contentFrame.document.getElementById("answer1")){
					var inputs = parent.contentFrame.document.getElementsByTagName("input")
					selectedOptionID = ""
					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="text")
						{
							selectedOptionID += "##T##" + parent.contentFrame.document.getElementsByTagName("input")[i].value;
							if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
				}

			}
			if(answerTypeCD == "MATCHING")
			{
				var isSelected = false
				selectedOptionID = "";
				for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++)
				{
					selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
					if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
				}
				if(!isSelected)selectedOptionID = "";
			}

			if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
			{
				var isChecked = false
				selectedOptionID = "";
				var inputs = parent.contentFrame.document.getElementsByTagName("input")
				for(var i=0;i<inputs.length;i++)
				{
					if(inputs[i].type=="checkbox")
					{
						if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
						{
						selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
						}
					if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
					}
				}
				if(!isChecked)selectedOptionID = "";
			}

			if(currentScreenFlag != "AAT")
			{
				if(questionRendered){
				  if(lessonType == "exam"){
				    SendInteractionInfo(currentScreenNum, selectedOptionID, currentScreenObj,currentLesson,flagclick);
				  }
				  learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
				}
			}
			if(allowsuspend == "Y")
			{
				NavExitLesson();
			}
			else
			{
				SetExamData();
			}
		}
		else
		{
			NavExitLesson();
		}
	}
	else
	{
		SetSessionTime();
		learnerData.SetCourseCompletion(GetCourseCompletion());
		learnerData.Set();
		objAICC.CommitData();
	}
	objAICC.Exit("time-out");
	objAICC.Finish();
	if(scocloseonexit)
	{
		parent.window.location.replace(scotimeoutpage);
	}
	else
	{
		parent.window.location.replace(scoexitpage);
	}
}


function ProcessExamTimeOut()
{
	examTime = examtimeoutduration;
	examTimedOut = true;
	ExamTimeOut();
}
function ProcessExamTimefivemnts()
{
	parent.contentFrame.document.getElementById("Endtest_popup_fivemnts").style.left = parent.document.documentElement.clientWidth/2 - 196
	parent.contentFrame.document.getElementById("Endtest_popup_fivemnts").style.top = parent.document.documentElement.clientHeight/2 - 105
	parent.contentFrame.document.getElementById("Endtest_popup_fivemnts").style.display = "block";
}

function ExamTimeOut()
{
	if (parent.contentFrame.document.getElementById("Endtest_popup_fivemnts").style.display == "block"){
		parent.contentFrame.document.getElementById("Endtest_popup_fivemnts").style.display = "none"
	}
	parent.contentFrame.document.getElementById("Endtest_popup").style.left = parent.document.documentElement.clientWidth/2 - 196
	parent.contentFrame.document.getElementById("Endtest_popup").style.top = parent.document.documentElement.clientHeight/2 - 105
	parent.contentFrame.document.getElementById("Endtest_popup").style.display = "block";
}
function Ok_Endtest_popup()
{
    if (lessonType == "exam"){
		EndTest();
	}
	else{
		parent.contentFrame.document.getElementById("Endtest_popup").style.display = "none";
		parent.contentFrame.document.getElementById("pagetimer").innerHTML = "Time Remaining 00:00:00";
	}
}

function Ok_fivemnts_popup()
{
	parent.contentFrame.document.getElementById("Endtest_popup_fivemnts").style.display = "none";
	return
}

function hideFibPopup()
{
	parent.contentFrame.document.getElementById("FibValidationPopup").style.display = "none";
	return
}

function EndExam()
{
	if(scocloseonexit)
	{
		if(top.window.opener == null)
		{
			if(isIE)
			{
				top.window.opener = top;
				top.window.close();
			}
			else
			{
				parent.window.location.replace(scostaticexitpage);
			}
		}
		else
		{
			top.window.close();
		}
	}
	else
	{
		parent.window.location.replace(scoexitpage);
	}
}

function CatchImproperExit()
{
	if(!aiccFinishCalled)
	{
		if(currentScreenType == "instruction")
		{
			NavExitLesson();
		}
		else if(currentScreenType == "question")
		{
			if(lessonType == "exam" || lessonType == "test" || lessonType=="customtest")
			{
				if((answerTypeCD == "ESSAY") && currentScreenFlag != "AAT")
				{
				  selectedOptionID = TrimStr(parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData());
					taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
				  taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
				  taskData[currentUnit][currentLesson][currentScreenNum].prevalue = parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
				  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
				}
				if((answerTypeCD == "SPREADSHEET") && currentScreenFlag != "AAT"){
					var rows = spread.getSheet(0).getDirtyRows();
					if (rows.length > 0) {
						selectedOptionID = TrimStr(GetHTMFromSheet());
						taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID = selectedOptionID;
					}else{
						selectedOptionID = taskData[currentUnit][currentLesson][currentScreenNum].selectedOptionID;
					}
					taskData[currentUnit][currentLesson][currentScreenNum].id = currentScreenNum;
  				taskData[currentUnit][currentLesson][currentScreenNum].prevalue = JSON.stringify(spread.toJSON());
				  taskData[currentUnit][currentLesson][currentScreenNum].qstem = parent.contentFrame.document.getElementById("qstem").innerHTML;
				}
				if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
				{
					if(parent.contentFrame.document.getElementById("answer")){
						selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
						}
					if(parent.contentFrame.document.getElementById("answer1")){
					var inputs = parent.contentFrame.document.getElementsByTagName("input")
					selectedOptionID = ""
					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="text")
						{
							selectedOptionID += "##T##" + parent.contentFrame.document.getElementsByTagName("input")[i].value;
							if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
					}
				}
				if(answerTypeCD == "MATCHING")
				{
					var isSelected = false
					selectedOptionID = "";
					for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++)
					{
						selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
						if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
					}
					if(!isSelected)selectedOptionID = "";
				}

				if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
				{
					var isChecked = false
					selectedOptionID = "";
					var inputs = parent.contentFrame.document.getElementsByTagName("input")
					for(var i=0;i<inputs.length;i++)
					{
						if(inputs[i].type=="checkbox")
						{
							if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
							{
							selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
							}
						if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
						}
					}
					if(!isChecked)selectedOptionID = "";
				}

				if(currentScreenFlag != "AAT")
				{
					if(questionRendered){
					  if(lessonType == "exam"){
					    SendInteractionInfo(currentScreenNum, selectedOptionID, currentScreenObj,currentLesson,flagclick);
					  }
					  learnerData.SetResponse(currentQuestionNum,selectedOptionID,IsResponseCorrect(),"",currentUnit,currentLesson,flagclick);
					}
				}
				if(allowsuspend == "Y")
				{
					if(timed == "R")
					{
						clearInterval(timeRemainingTimer);
						examTime = examtimeoutduration - examTimeRemaining;
					}
					NavExitLesson();
				}
				else
				{
					endTest = true;
					SetExamData();
				}
			}
			else
			{
				NavExitLesson();
			}
		}
		else
		{
			SetSessionTime();
			learnerData.SetCourseCompletion(GetCourseCompletion());
			learnerData.Set();
			objAICC.CommitData();
		}
		objAICC.Exit("normal");
		objAICC.Finish();
	}
}
function CalculateScore()
{
	if(lessonType == "test") var examMode = "review mode";
	if(lessonType == "exam") var examMode = "exam mode";
	if(lessonType=="customtest") var examMode = "custom mode";
	var numCorrect = 0;
	var nonLongnumCorrect = 0;
	var numAttempted = 0;

	var qid="";
	var qanswered="";
	var qnotattempted="";
    var qmarked =""

	var temptotalQuestions = 0
	var aatQuesIsCorrect = 1
	var aatQuesIsAttempted = 0


	var tempQuesSet = "";
	var firstAat = 0;
	var flagNewQset = false;

	for(var i=0;i<totalQuestionsToInclude;i++)
	{
		var learnerResponse = learnerData.GetResponse(testQuestionSequence[i],currentUnit, currentLesson);
		temp2currentScreenObj = GetNode(currentLessonObj, "screen", i);

		if(temp2currentScreenObj.getAttribute("flag") == "AAT"){
		    if (firstAat == 0){
				firstAat = 1;
			}
			if (i+1<totalQuestions){
				screenobj = GetNode(currentLessonObj, "screen", i);
				temp3currentScreenObj = GetNode(currentLessonObj, "screen", i+1);
				temp2QuesSet = screenobj.getAttribute("questionset")
				temp3QuesSet = temp3currentScreenObj.getAttribute("questionset")
				if(temp2QuesSet != temp3QuesSet){
					totalaatQCount++;
					flagNewQset = true;
					if(temp3QuesSet)aatQuesIsCorrect=1;
				}
				else{
					flagNewQset = false;
				}
			}
		}
		else{
			aatQuesIsCorrect=1;
		}
		if(lessonType == "exam") qid = GetNode(currentLessonObj, "screen", testQuestionSequence[i]).getAttribute("id");
		if(learnerResponse != null)
		{

			if(eval(learnerResponse[2]) > 0 || eval(learnerResponse[2]) == 9999)
			{
				var aatSet = 1;
				numCorrect++;
				aatQuesIsAttempted = 1

				if(temp2currentScreenObj.getAttribute("flag") == "AAT"){
					 if (firstAat == 0){
						firstAat = 1;
						totalaatQCount++;
					 }
					for (var j=0; aatSet == 1; j++){
						screenobj = GetNode(currentLessonObj, "screen", i+j);
						if (!taskData[currentUnit][currentLesson][i+j].iscorrect){
							aatQuesIsCorrect = 0;
						}
						tempQuesSet = screenobj.getAttribute("questionset")
						screenobj = GetNode(currentLessonObj, "screen", i+j);
						if (GetNode(currentLessonObj, "screen", i+j+1))
						{
							screenObjNext = GetNode(currentLessonObj, "screen", i+j+1)
							tempQuesSetNext = screenObjNext.getAttribute("questionset")
							if (tempQuesSet == tempQuesSetNext){
								aatSet = 1;
							}
							else{
								aatSet = 0;
								totalaatQCount++;
							}
						}
						else{
							aatSet = 0
						}
					}
					i = i+(j-1)
					if(aatQuesIsCorrect){
						totalAatCorrect++;

					}
						aatQuesIsCorrect=1;
				}
				else
				{
				nonLongnumCorrect++;
				}
			}
			else if (temp2currentScreenObj.getAttribute("flag") == "AAT"){
				if(!flagNewQset)aatQuesIsCorrect=0;
			}
			if(learnerResponse[1] != "")
			{
				numAttempted++;
				if(lessonType == "exam")
				{
					qanswered += qid+",";
				}
			}
			else
			{

				if(lessonType == "exam")
				{
					qnotattempted += qid+",";
				}
			}
			if(learnerResponse[4] != "")
			{
				if(lessonType == "exam")
				{
					if(eval(learnerResponse[4]) == true)
					{
					qmarked += qid+",";
					}
				}
			}
		}
	}
	totalnonLongnumCorrect = nonLongnumCorrect
	if(lessonType == "exam")
	{
		learnerData.answered = qanswered.substr(0,qanswered.length-1);
		learnerData.notAttempted = qnotattempted.substr(0,qnotattempted.length-1);
		learnerData.markedForReview = qmarked.substr(0,qmarked.length-1);
	}

	percentCorrectLongQPart = (totalAatCorrect/totalaatQCount)*100;

	if(totalQuestions - aatQuestionJump != 0)
	{
		percentCorrectNonLongQPart = (totalnonLongnumCorrect/(totalQuestionsForDisplay-totalaatQCount))*100
	}
	var percentCorrect =  (((totalnonLongnumCorrect + totalAatCorrect)/totalQuestionsForDisplay) * 100).toFixed(2);

	if(timed == "R")
	{
		clearInterval(timeRemainingTimer);
		examTime = examtimeoutduration - examTimeRemaining;
	}
	else
	{
		examTime = "";
	}
	temptotalQuestions = totalQuestionsForDisplay

	learnerData.SetScore(examMode,passpercent,numCorrect,numAttempted,temptotalQuestions,percentCorrect,examTime,GetCurrentDate("long"),currentUnit,currentLesson);

	var lessonStatus = learnerData.GetProgress(currentUnit,currentLesson);

	///////////////////////////////////  /completion Status ///////////////////////////////////

	if(lessonStatus[0] == "completed")
	{
		var completion = "completed";
		var completionDate = lessonStatus[4];
	}
	else if(lessonComplete)
	{
		var completion = "completed";
		var completionDate = GetCurrentDate("long");
	}
	else
	{
		var completion = "not completed";
		var completionDate = "";
	}

	if(percentCorrect >= passpercent)
	{
		var examresult = "passed";
	}
	else
	{
		var examresult = "not passed";
	}
	var where = totalScreens + " of " + totalScreens;

	currentExamStatus = new Array();
	currentExamStatus[0] = completion;
	currentExamStatus[1] = examresult;

	learnerData.SetProgress(completion,examresult,where,examTime,completionDate,currentUnit,currentLesson);

	lessonComplete = false;
}


function SelectAnswer(resp)
{
	var inputObjs = parent.contentFrame.document.getElementsByTagName("input");
	selectedOptionID = "";
	for(var i=0;i<inputObjs.length;i++)
	{
		if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
		{
			resp = (resp.split("##T##")).join("~");
			resp = (resp.split("##B##")).join("]");
			resp = (resp.split("##S##")).join(";");
			resp = (resp.split("##C##")).join(",");
			resp = (resp.split("##O##")).join(":");
			if(inputObjs[i].id == "answer"){
				inputObjs[i].value = resp;
				break;
			}
			if(inputObjs[i].id == "answer1"){
				inputObjs[i].value = resp.split("~")[1];
			}
			if(inputObjs[i].id == "answer2"){
				if(resp.split("~")[2]){
					inputObjs[i].value = resp.split("~")[2];
				}
			}
			if(inputObjs[i].id == "answer3"){
				if(resp.split("~")[3]){
					inputObjs[i].value = resp.split("~")[3];
				}
			}
			if(inputObjs[i].id == "answer4"){
				if(resp.split("~")[4]){
					inputObjs[i].value = resp.split("~")[4];
				}
			}
		}
		if(inputObjs[i].id == "answer" && inputObjs[i].value == resp)
		{
			inputObjs[i].checked = true;
			selectedOptionID = inputObjs[i].value;
			break;
		}
	}
	if(answerTypeCD == "MATCHING")
	{
		var selectObjs = parent.contentFrame.document.getElementsByTagName("select");
		var ansary = resp.split(" ");
		var selectObjName, selectans;
		var tmpselect;
		for(var i=0;i<selectObjs.length;i++)
		{
			selectObjName = selectObjs[i].id;
			for(var n=0;n<ansary.length;n++)
			{
				if(selectObjName == ansary[n])
				{
					selectans = ansary[n+1];
					break;
				}
			}
			tmpselect = parent.contentFrame.document.getElementById(selectObjName);

			for(var j=0;j<tmpselect.options.length;j++)
			{
					if(tmpselect.options[j].value == selectans)
					{
							tmpselect.selectedIndex = j;
					}
			}
		}
	}

	if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
	{
		var the_char  = resp.charAt(0);
		var respdata  = resp.replace(the_char,"");
		var ansaryd   = respdata.split(" ");
		var checkObjName, checkans;
		var tmpcheck;

		var checkObjs = parent.contentFrame.document.getElementsByTagName("input")
		for(var i=0;i<checkObjs.length;i++)
		{
			if(checkObjs[i].type=="checkbox")
			{
					checkObjName = checkObjs[i].id;
					for(var m=0; m<ansaryd.length; m++)
					{
						if(checkObjName == ansaryd[m])
						{
							checkans = ansaryd[m];
							parent.contentFrame.document.getElementById(checkans).checked = true;
							break;
						}
					}
			 }
		}
	}
}

function PrepareReviewPage()
{
	var icon;
	var learnerResponse;
	var learnerResponseTemp;
	var qnum;
	var unitobj;
	var lessonobj;
	var screenobj;
	var tempqnumR = 0;

	var flagLongQ_Attempted = false;
	var html = '<table width="100%" cellspacing="3" cellpadding="0" border="0"><tr><td colspan="2" class="table_head" valign="bottom">Question</td><td nowrap="nowrap" class="table_head" valign="bottom" align="center">Answer</td><td class="table_head" valign="bottom">Category</td><td class="table_head" valign="bottom" align="center"></td></tr><tr><td height="1" class="table_head_line" colspan="7"><img border="0" height="1" width="1" src="../images/clr_gif.gif"/></td></tr>'
	for(var i=0;i<testQuestionSequence.length;i++)
	{
		qnum = testQuestionSequence[i];
		learnerResponse = learnerData.GetResponse(qnum,currentUnit,currentLesson);
		unitobj   = GetNode(configObj, "unit", currentUnit);
		lessonobj = GetNode(unitobj, "lesson", currentLesson);
		screenobj = GetNode(lessonobj, "screen", qnum);
		if(screenobj.getAttribute("flag") == "AAT")
		{
			/*if(dynamicScore >0)
			{
				if(dynamicScore == maxScoreOfLong)
				{
				icon = "icon_correct";
				}
				else
				{
				icon = "icon_partially_correct";
				}
			}
			else
			{
				for(var ii=0;ii<aatQuestionJump;ii++)
				{
					learnerResponseTemp = learnerData.GetResponse(ii,currentUnit,currentLesson);
					if(learnerResponseTemp[1] != "" && learnerResponseTemp[1] != null)
					{
						flagLongQ_Attempted = true
					}
				}
				if (flagLongQ_Attempted)
				{
					icon = "icon_incorrect";
				}
				else
				{
					icon = "icon_no_answer";
				}
			}*/



			/*if(totalAatCorrect == 1){
				icon = "icon_correct";
			}*/
			if(getCorrectStatusAAT(i) == 1){
				icon = "icon_correct";
			}
			else{
				if (getAtemptedStatusAAT(screenobj.getAttribute("questionset")) == 1){
					icon = "icon_incorrect";
				}
				else{
					icon = "icon_no_answer";
				}
			}

		}
		else{
			if(learnerResponse[1] == "" || learnerResponse[1] == null)
			{
				icon = "icon_no_answer";
			}
			else if(eval(learnerResponse[2]))
			{
				icon = "icon_correct";
			}
			else
			{
				icon = "icon_incorrect";
			}
		}
		html = html + '<tr><td class="table_text"/><td nowrap="nowrap" height="13" class="table_text" valign="middle"><a href="javascript:parent.codeFrame.NavReviewQuestion(' + i + ')"><span class="bold">'+ Pad(tempqnumR+1,2,"0",true) +'</span></a></td><td nowrap="nowrap" height="13" class="table_text" valign="middle" align="center"><img align="baseline" border="0" height="13" width="13" src="../images/' + icon + '.gif"/></td><td class="table_text" valign="top" align="left">' + GetCategoryDescription(screenobj.getAttribute("categoryID").toLowerCase()) + '</td><td nowrap="nowrap" height="13" align="center" class="table_text" valign="middle"></td></tr>';

		if(i+1 < testQuestionSequence.length)
		{
			html = html + '<tr><td height="1" class="table_line" colspan="7"><img border="0" height="1" width="1" src="../images/clr_gif.gif"/></td></tr>';
		}
		if(screenobj.getAttribute("flag") == "AAT")
		{
			i = i+(tempaatQuestionJump - 1)

		}
		tempqnumR++
	}
	html = html + '<tr><td height="1" class="table_head_line" colspan="7"><img border="0" height="1" width="10" src="../images/clr_gif.gif"/></td></tr><tr><td style="padding-left:15px"/><td nowrap="nowrap" width="40"/><td width="60"/><td style="padding-left:100px" width="100%"/><td style="padding-left:80px"/></tr><tr><td colspan="7"><img border="0" height="25" width="1" src="../images/clr_gif.gif"/></td></tr></table>';
	return html;
}

//------------------Add Feedback functon()---------------------//
/*
function PreparefeedbackPage()
{
	var icon;
	var learnerResponse;
	var qnum;
	var unitobj;
	var lessonobj;
	var screenobj;
	var screenobjtemp;
	var tabcheck;
	IncompleteArray = new Array();

	var numberofquestions = testQuestionSequence.length;

	var i=0;
	var tempqnum = 0;
	var aatq = false;
	var columnlimit = 8;
	var tempcolumntaken = 0
	var tempQuesSet = "";

	var html = '<table width="100%" border="0" style="border:1px #999 solid;border-collapse:collapse;" cellpadding="0" cellspacing="0" align="center"><tr>';

	while(i<numberofquestions)
	{

	html+='<td width="328" valign="top"><table width="328" border="0" cellpadding="0" cellspacing="0"style="border:0px #fff solid;border-collapse:collapse;"><tr><td><table width="328" border="1" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">'


	for(;(tempcolumntaken<columnlimit && i<numberofquestions);i++)
	{

		qnum = testQuestionSequence[i];
		learnerResponse = learnerData.GetResponse(qnum,currentUnit,currentLesson);
		unitobj   = GetNode(configObj, "unit", currentUnit);
		lessonobj = GetNode(unitobj, "lesson", currentLesson);
		screenobj = GetNode(lessonobj, "screen", qnum);

		if(screenobj.getAttribute("flag") != "AAT")
		{

			tempqnum ++;
			tempcolumntaken ++;

			aatq = false;

			if(questionStatus[i][1] == 1)
			{
				tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><input type="button" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Selected_Out" onclick="parent.codeFrame.SetUnChecked('+qnum+','+i+')" /></td></tr></table>'

			}
			else if(questionStatus[i][1] == 0)
			{


				tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><input type="button" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Incomplete_Out" onclick="parent.codeFrame.SetChecked('+qnum+','+i+')" onmouseover="parent.codeFrame.Flag_Incomplete_Over(id)" onmouseout="parent.codeFrame.Flag_Incomplete_Out(id)" /></td></tr></table>'
			}
			else
			{
				tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><input type="button" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Incomplete_Out" onclick="parent.codeFrame.SetChecked('+qnum+','+i+')" onmouseover="parent.codeFrame.Flag_Incomplete_Over(id)" onmouseout="parent.codeFrame.Flag_Incomplete_Out(id)" /></td></tr></table>'
			}

			if(learnerResponse[1] == "" || learnerResponse[1] == null)
			{
			icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#C00;padding-left:15px;'>Incomplete</td></tr></table>";

			questionStatus[i][0]=1
			}
			else if(eval(learnerResponse[2]))
			{
			icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#000;padding-left:15px;'>Complete</td></tr></table>";
			questionStatus[i][0] = 0;
			}
			else
			{
			icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#000;padding-left:15px;'>Complete</td></tr></table>";
			questionStatus[i][0] = 0;
			}

        	html = html + '<tr><td ><table width="328" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;"><tr><td width="15" height="30"></td><td width="27" class="table_text">'+ tabcheck +'</td><td width="141"><a href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ')">Question '+ Pad(tempqnum,2,"0",true) +'</a></td><td width="80" class="table_text" align="center" valign="middle">'+icon+'</td></tr></table></td></tr>';

	}else{
		if(tempQuesSet != screenobj.getAttribute("questionset") || !aatq){
			 tempqnum ++;
			 aatq = true;
			 tempQuesSet = screenobj.getAttribute("questionset")
			if(isAATQFlagged(i))
			{
				tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><input type="button" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Selected_Out" onclick="parent.codeFrame.SetUnChecked('+qnum+','+i+')" /></td></tr></table>'

			}
			else if(!isAATQFlagged(i))
			{
				tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><input type="button" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Incomplete_Out" onclick="parent.codeFrame.SetChecked('+qnum+','+i+')" onmouseover="parent.codeFrame.Flag_Incomplete_Over(id)" onmouseout="parent.codeFrame.Flag_Incomplete_Out(id)" /></td></tr></table>'
			}
			else
			{
				tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><input type="button" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Incomplete_Out" onclick="parent.codeFrame.SetChecked('+qnum+','+i+')" onmouseover="parent.codeFrame.Flag_Incomplete_Over(id)" onmouseout="parent.codeFrame.Flag_Incomplete_Out(id)" /></td></tr></table>'
			}

			if(learnerResponse[1] == "" || learnerResponse[1] == null)
			{
				icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#C00;padding-left:15px;'>Incomplete</td></tr></table>";
			}

			screenobjtemp = GetNode(lessonobj, "screen", i+1);
			temp2QuesSet = screenobjtemp.getAttribute("questionset")

			var tempAatquesisComplete = 1
			for(var j =i; tempQuesSet == temp2QuesSet && j+1 < numberofquestions; j++)
			{

				learnerResponse = learnerData.GetResponse(j,currentUnit,currentLesson);
				if(!taskData[currentUnit][currentLesson][j].attempted)
				{
					tempAatquesisComplete = 0
				}

				screenobjtemp = GetNode(lessonobj, "screen", j+1);
				temp2QuesSet = screenobjtemp.getAttribute("questionset")
			}

			if(tempAatquesisComplete)
			{
				icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#000;padding-left:15px;'>Complete</td></tr></table>";
				questionStatus[i][0]=0
			}
			else
			{
				icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#C00;padding-left:15px;'>Incomplete</td></tr></table>";
				questionStatus[i][0]=1;
			}

        	html = html + '<tr><td ><table width="328" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;"><tr><td width="15" height="30"></td><td width="27" class="table_text">'+ tabcheck +'</td><td width="141"><a href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ')">Question '+ Pad(tempqnum,2,"0",true) +'</a></td><td width="80" class="table_text" align="center" valign="middle">'+icon+'</td></tr></table></td></tr>';

			tempcolumntaken = tempcolumntaken+1;

		}
	}
		}

html = html + '</table></td></tr></table></td>';
	columnlimit+=8;

	}
html = html + '<td width="*"></td>';
html += '</tr></table>';

// ***************** For mode type issue (sumit)********** /
if (selectedLessType == "exam") {

	parent.contentFrame.document.getElementById("End_Review_id").className = "NavEndTest_Out";
	parent.contentFrame.document.getElementById("End_Review_id").id = "EndTest_id";


}

return html;
}
*/

function PreparefeedbackPage()
{
	var icon;
	var learnerResponse;
	var qnum;
	var unitobj;
	var lessonobj;
	var screenobj;
	var tabcheck;

	var numberofquestions = testQuestionSequence.length;
	var i=0;
	var tempqnum = 0;
	var aatq = false;
	var columnlimit = 5000;
	var tempcolumntaken = 0
	var tempQuesSet = "";
	var aatQCompletionStatus;

	var html = '';

	while(i<numberofquestions)
	{

	html+='<table width="100%" cellpadding="0" cellspacing="0">'
	for(;(tempcolumntaken<columnlimit && i<numberofquestions);i++)
	{
		qnum = testQuestionSequence[i];
		learnerResponse = learnerData.GetResponse(qnum,currentUnit,currentLesson);
		unitobj   = GetNode(configObj, "unit", currentUnit);
		lessonobj = GetNode(unitobj, "lesson", currentLesson);
		screenobj = GetNode(lessonobj, "screen", qnum);

		if(screenobj.getAttribute("flag") != "AAT")
		{
			tempqnum ++;
			tempcolumntaken ++;
			aatq = false;
			if(learnerResponse[4] == "true")
			{
				tabcheck = '<div id="SetCheckedval_id'+i+'" class="Flag_Withclick_Out"></div>'

			}
			else if(learnerResponse[4] == "false")
			{
				tabcheck = '<div id="SetCheckedval_id'+i+'" class="Flag_Withoutclick_Out"></div>'
			}
			else
			{
				tabcheck = '<div id="SetCheckedval_id'+i+'" class="Flag_Withoutclick_Out"></div>'
			}

			if(eval(learnerResponse[2]))
			{
				if(screenobj.getAttribute('answerTypeCD') == 'SPREADSHEET' || screenobj.getAttribute('answerTypeCD') == 'ESSAY'){
					icon = '';
				}else{
					icon = '<span style="padding-left:15px;">Complete</span>';
					questionStatus[i][0]=0
				}
			}else if(learnerResponse[4] == "" || learnerResponse[4] == null)
			{
				icon = '<span style="color:#C00;padding-left:15px;">Incomplete</span>';
				//questionStatus[i][0]=1
			}else if(learnerResponse[1] == "" || learnerResponse[1] == null)
			{
				/*if(screenobj.getAttribute('answerTypeCD') == 'SPREADSHEET' || screenobj.getAttribute('answerTypeCD') == 'ESSAY'){
					icon = '';
				}else{*/
					icon = '<span style="color:#C00;padding-left:15px;">Incomplete</span>';
					questionStatus[i][0]=1
				//}
			}else
			{
				if(screenobj.getAttribute('answerTypeCD') == 'SPREADSHEET' || screenobj.getAttribute('answerTypeCD') == 'ESSAY'){
					icon = '';
				}else{
					icon = '<span style="padding-left:15px;">Complete</span>';
					questionStatus[i][0]=0
				}
			}
				if(screenobj.getAttribute("sectionstart") && screenobj.getAttribute("sectionstart") != "" ){
					html = html + '<tr class="oddrow" height="23"><td width="42" class="feedback_row"></td><td width="358" class="feedback_headtext feedback_row" align="left"><a style="text-decoration:none;color:#595959;" href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ', false)">'+ screenobj.getAttribute("sectionname") +'</a></td><td width="*" class="feedback_row"></td></tr>'
				}
				html = html + '<tr class="oddrow" height="23"><td width="42" align="center" class="feedback_row">'+tabcheck+'</td><td width="358" class="feedback_headtext feedback_row" align="left"><a style="text-decoration:none;color:#595959;" href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ', true)">Question '+ Pad(tempqnum,2,"0",true) +'</a></td><td width="*" class="feedback_row">'+icon+'</td></tr>'
			}
		}

		html = html + '</table>';
		columnlimit+=8;
	}
	return html;
}

function PreparefeedbackPageforNavigator()
{
	var icon;
	var learnerResponse;
	var qnum;
	var unitobj;
	var lessonobj;
	var screenobj;
	var tabcheck;

	var numberofquestions = testQuestionSequence.length;
	var i=0;
	var tempqnum = 0;
	var aatq = false;
	var columnlimit = 5000;
	var tempcolumntaken = 0
	var tempQuesSet = "";
	var aatQCompletionStatus;

	var html = '';

	while(i<numberofquestions)
	{

	html+='<table width="100%" cellpadding="0" cellspacing="0">'
	rowcount = 0;
	for(;(tempcolumntaken<columnlimit && i<numberofquestions);i++)
	{
		qnum = testQuestionSequence[i];
		learnerResponse = learnerData.GetResponse(qnum,currentUnit,currentLesson);
		unitobj   = GetNode(configObj, "unit", currentUnit);
		lessonobj = GetNode(unitobj, "lesson", currentLesson);
		screenobj = GetNode(lessonobj, "screen", qnum);

		if(screenobj.getAttribute("flag") != "AAT")
		{
			tempqnum ++;
			tempcolumntaken ++;
			aatq = false;
			if(learnerResponse[4] == "true")
			{
				tabcheck = '<div id="SetCheckedval_id'+i+'" class="Flag_Withclick_Out"></div>'

			}
			else if(learnerResponse[4] == "false")
			{
				tabcheck = ''; //'<div id="SetCheckedval_id'+i+'" class="Flag_Withoutclick_Out"></div>'
			}
			else
			{
				tabcheck = ''; //'<div id="SetCheckedval_id'+i+'" class="Flag_Withoutclick_Out"></div>'
			}

			if(eval(learnerResponse[2]))
			{
			icon = '<span style="padding-left:15px;">Completed</span>';
			questionStatus[i][0]=0
			}else if(learnerResponse[4] == "" || learnerResponse[4] == null)
			{
			icon = '<span style="color:#C00;padding-left:15px;">Unseen</span>';
			//questionStatus[i][0]=1
			}else if(learnerResponse[1] == "" || learnerResponse[1] == null)
			{
			icon = '<span style="color:#C00;padding-left:15px;">Incomplete</span>';
			questionStatus[i][0]=1
			}else
			{
			icon = '<span style="padding-left:15px;">Completed</span>';
			questionStatus[i][0]=0
			}
				if(screenobj.getAttribute("sectionstart") && screenobj.getAttribute("sectionstart") != "" ){
					rowcount++;
					html = html + '<tr onmouseover="$(this).addClass(\'rowhower\')" onmouseout="$(this).removeClass(\'rowhower\')" class="'+GetRowClass(qnum, rowcount, 0)+'" height="35"><td width="60%" class="feedback_headtext" align="left" style="border: 1px #DCDDDD solid; padding: 2px 15px 2px 15px;"><a style="text-decoration:none;color:#595959;" href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ', false)">'+ screenobj.getAttribute("sectionname") +'</a></td><td width="20%" style="border: 1px #DCDDDD solid; padding: 2px;"></td><td width="20%" style="border: 1px #DCDDDD solid; padding: 2px;"></td></tr>'
				}
				rowcount++;
				html = html + '<tr onmouseover="$(this).addClass(\'rowhower\')" onmouseout="$(this).removeClass(\'rowhower\')" class="'+GetRowClass(qnum, rowcount, 1)+'" height="35"><td width="60%" class="feedback_headtext" align="left" style="border: 1px #DCDDDD solid; padding: 2px 15px 2px 15px;"><a style="text-decoration:none;color:#595959;" href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ', true)">Question '+ Pad(tempqnum,2,"0",true) +'</a></td><td width="20%" style="border: 1px #DCDDDD solid; padding: 2px;">'+icon+'</td><td width="20%" align="center" style="border: 1px #DCDDDD solid; padding: 2px;">'+tabcheck+'</td></tr>'
	}else{
		if(tempQuesSet != screenobj.getAttribute("questionset") || !aatq){
			 tempqnum ++;
			 aatq = true;
			 tempQuesSet = screenobj.getAttribute("questionset")
			 aatQCompletionStatus = getCompletionStatusAAT(tempQuesSet)
			if(isAATQFlagged(i))
			{
				tabcheck = '<table width="33%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><img src="../images/flag01.jpg" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Selected_Out_Navigator"/></td></tr></table>'

			}
			else if(!isAATQFlagged(i))
			{
				tabcheck = '<table width="33%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><img src="../images/flag03.jpg" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Incomplete_Out_Navigator" /></td></tr></table>';
			}
			else
			{
				tabcheck = '<table width="33%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><img src="../images/flag03.jpg" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Incomplete_Out_Navigator" /></td></tr></table>';
			}
			if(!aatQCompletionStatus){
				icon = "<table width='33%' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#C00;padding-left:15px;'>Incomplete</td></tr></table>";
			}
			else{
				icon = "<table width='33%' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#000;padding-left:15px;'>Complete</td></tr></table>";
			}

			html = html + '<tr><td ><table width="60%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;"><tr><td height="30" style="padding-left:4px;"><a href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ')">Question '+ Pad(tempqnum,2,"0",true) +'</a></td></tr></table></td><td width="20%" align="left">'+icon+'</td><td width="20%" align="center">'+tabcheck+'</td></tr>';
		}
	}
		}

html = html + '</table>';
	columnlimit+=8;
	}
	//parent.contentFrame.document.getElementById("navigatorSortIndicator").src = "../images/up.png"


return html;
}
function GetRowClass(qnum, rowcount, questionrow){
	var classtoreturn = "";
	if(rowcount%2){
		classtoreturn = 'oddrow'
	}else{
		classtoreturn = 'evenrow'
	}
	if(qnum == currentScreenNum){
		if(questionRendered && questionrow || instructionRendered && !questionrow){
				classtoreturn = 'selectedrow'
		}
	}
	return classtoreturn;
}
function PreparefeedbackPageforNavigatorDesc()
{
	var icon;
	var learnerResponse;
	var qnum;
	var unitobj;
	var lessonobj;
	var screenobj;
	var tabcheck;
	var tempQnumForDisplay = totalQuestionsForDisplay;

	var numberofquestions = testQuestionSequence.length;
	var i=numberofquestions - 1;
	var tempqnum = 0;
	var aatq = false;
	var columnlimit = 5000;
	var tempcolumntaken = 0
	var tempQuesSet = "";
	var aatQCompletionStatus;

	var html = '<table width="100%" border="0" style="border:1px #999 solid;border-collapse:collapse;" cellpadding="0" cellspacing="0" align="center"><tr>';

	while(i>0)
	{

	html+='<td width="100%" valign="top"><table border="0" cellpadding="0" cellspacing="0"style="border:0px #fff solid;border-collapse:collapse; width:100%;"><tr><td><table width="100%" border="1" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">'

		for(;(tempcolumntaken<columnlimit && i>=0);i--)
		{
			qnum = testQuestionSequence[i];
			learnerResponse = learnerData.GetResponse(qnum,currentUnit,currentLesson);
			unitobj   = GetNode(configObj, "unit", currentUnit);
			lessonobj = GetNode(unitobj, "lesson", currentLesson);
			screenobj = GetNode(lessonobj, "screen", qnum);
			if(screenobj.getAttribute("flag") != "AAT")
			{
				tempqnum ++;
				tempcolumntaken ++;
				aatq = false;
				if(learnerResponse[4] == "true")
				{
					tabcheck = '<table width="33%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><img src="../images/flag01.jpg" id="checkRootID'+tempQnumForDisplay+'" name="checkRootID'+tempQnumForDisplay+'" class="Flag_Selected_Out_Navigator"/></td></tr></table>'
				}
				else if(learnerResponse[4] == "false")
				{
					tabcheck = '<table width="33%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><img src="../images/flag03.jpg" id="checkRootID'+tempQnumForDisplay+'" name="checkRootID'+tempQnumForDisplay+'" class="Flag_Incomplete_Out_Navigator" /></td></tr></table>';
				}
				else
				{
					tabcheck = '<table width="33%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><img src="../images/flag03.jpg" id="checkRootID'+tempQnumForDisplay+'" name="checkRootID'+tempQnumForDisplay+'" class="Flag_Incomplete_Out_Navigator" /></td></tr></table>';
				}

				if(learnerResponse[1] == "" || learnerResponse[1] == null)
				{
					icon = "<table width='33%' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#C00;padding-left:15px;'>Incomplete</td></tr></table>";
					questionStatus[i][0]=1
				}
				else if(eval(learnerResponse[2]))
				{
					icon = "<table width='33%' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#000;padding-left:15px;'>Complete</td></tr></table>";
					questionStatus[i][0]=0
				}
				else
				{
					icon = "<table  width='33%' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#000;padding-left:15px;'>Complete</td></tr></table>";
					questionStatus[i][0]=0
				}

				if (aatQuestionJump > 0)
				{
        			html = html + '<tr><td ><table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;"><tr><td height="30" style="padding-left:4px;"><a href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ')">Question '+ Pad(tempQnumForDisplay,2,"0",true) +'</a></td></tr></table></td><td width="33%" align="left">'+icon+'</td><td width="33%" align="center">'+tabcheck+'</td></tr>';
				}
				else
				{
					html = html + '<tr><td ><table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;"><tr><td height="30" style="padding-left:4px;"><a href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ')">Question '+ Pad(tempQnumForDisplay,2,"0",true) +'</a></td></tr></table></td><td width="33%" align="left">'+icon+'</td><td width="33%" align="center">'+tabcheck+'</td></tr>';
				}
				tempQnumForDisplay--;
			}else{
					if(tempQuesSet != screenobj.getAttribute("questionset") || !aatq){
					  tempqnum ++;
					  aatq = true;
					  tempQuesSet = screenobj.getAttribute("questionset")
					  aatQCompletionStatus = getCompletionStatusAAT(tempQuesSet)
					  if(isAATQFlagged(i))
						{
							tabcheck = '<table width="33%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><img src="../images/flag01.jpg" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Selected_Out_Navigator"/></td></tr></table>'

						}
						else if(!isAATQFlagged(i))
						{
							tabcheck = '<table width="33%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><img src="../images/flag03.jpg" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Incomplete_Out_Navigator" /></td></tr></table>';
						}
						else
						{
							tabcheck = '<table width="33%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+i+'"><img src="../images/flag03.jpg" id="checkRootID'+i+'" name="checkRootID'+i+'" class="Flag_Incomplete_Out_Navigator" /></td></tr></table>';
						}
					  if(!aatQCompletionStatus){
						  icon = "<table width='33%' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#C00;padding-left:15px;'>Incomplete</td></tr></table>";

					  }
					  else{
						  icon = "<table  width='33%' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#000;padding-left:15px;'>Complete</td></tr></table>";
					  }
					  if (aatQuestionJump > 0)
						{
							html = html + '<tr><td ><table width="33%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;"><tr><td height="30" style="padding-left:4px;"><a href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ')">Question '+ Pad(tempQnumForDisplay,2,"0",true) +'</a></td></tr></table></td><td width="33%" align="left">'+icon+'</td><td width="290" align="center">'+tabcheck+'</td></tr>';
						}
						else
						{
							html = html + '<tr><td ><table width="33%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;"><tr><td height="30" style="padding-left:4px;"><a href="javascript:parent.codeFrame.NavNavigatorQuestion(' + i + ')">Question '+ Pad(tempQnumForDisplay,2,"0",true) +'</a></td></tr></table></td><td width="33%" align="left">'+icon+'</td><td width="290" align="center">'+tabcheck+'</td></tr>';
						}

				tempQnumForDisplay--;
		 		}

		}
	}

html = html + '</table></td></tr></table></td>';
	columnlimit+=8;
	}
html = html;
html += '</tr></table>';

parent.contentFrame.document.getElementById("navigatorSortIndicator").src = "../images/DOWN.png"

return html;
}

function getCompletionStatusAAT(tempQuesSet){
	var tmpscreenobj;
	var nextTmpscreenobj;
	var tQset;
	var nextTQset;
	var aatQCompleted = 1;

	for(var i=0; i<testQuestionSequence.length; i++)	{
		tmpscreenobj = GetNode(currentLessonObj, "screen", i);
		tQset = tmpscreenobj.getAttribute("questionset");

		if(i+1<testQuestionSequence.length){
				nextTmpscreenobj = GetNode(currentLessonObj, "screen", i);
				nextTQset = nextTmpscreenobj.getAttribute("questionset");
		}

		if(tQset == tempQuesSet){
			while(tQset == nextTQset && i<testQuestionSequence.length){
				if (!taskData[currentUnit][currentLesson][i].attempted){
					aatQCompleted = 0
					return aatQCompleted;
				}
				if(i+1<testQuestionSequence.length){
					nextTmpscreenobj = GetNode(currentLessonObj, "screen", i+1);
					nextTQset = nextTmpscreenobj.getAttribute("questionset");
					if(tQset != nextTQset){
						return aatQCompleted;
					}
				}
				i++;
			}
		}
	}
}

function getAtemptedStatusAAT(tempQuesSet){
	var tmpscreenobj;
	var nextTmpscreenobj;
	var tQset;
	var nextTQset;
	var aatQAttempted = 0;

	for(var i=0; i<testQuestionSequence.length; i++)	{
		tmpscreenobj = GetNode(currentLessonObj, "screen", i);
		tQset = tmpscreenobj.getAttribute("questionset");

		if(i+1<testQuestionSequence.length){
				nextTmpscreenobj = GetNode(currentLessonObj, "screen", i);
				nextTQset = nextTmpscreenobj.getAttribute("questionset");
		}

		if(tQset == tempQuesSet){
			while(tQset == nextTQset && i<testQuestionSequence.length){
				if (taskData[currentUnit][currentLesson][i].attempted){
					aatQAttempted = 1
					return aatQAttempted;
				}
				if(i+1<testQuestionSequence.length){
					nextTmpscreenobj = GetNode(currentLessonObj, "screen", i+1);
					nextTQset = nextTmpscreenobj.getAttribute("questionset");
					if(tQset != nextTQset){
						return aatQAttempted;
					}
				}
				i++;
			}
		}
	}
}

function getCorrectStatusAAT(scrnum){

	var lObj = currentLessonObj.getElementsByTagName("screen");
	var thisAATCorrect = true;

	tempaatQuestionJump = 0;

		for(var jj=scrnum; jj>=0; jj--){
			if(lObj[Number(scrnum)].getAttribute("questionset") == lObj[Number(scrnum-1)].getAttribute("questionset")){
				scrnum--;
			}
			else{
				break;
			}
		}

		for(var ii=scrnum; ii<testQuestionSequence.length; ii++){
			if(taskData[currentUnit][currentLesson][ii].answerParameters != taskData[currentUnit][currentLesson][ii].selectedOptionID)thisAATCorrect=false
			tempaatQuestionJump++;
			if(lObj[Number(ii)].getAttribute("questionset") != lObj[Number(ii+1)].getAttribute("questionset")){
				break;
			}
		}

		if(thisAATCorrect){
			return 1
		}else{
			return 0
		}
}

//LongQ
function LPreparefeedbackPage()
{
	var icon;
	var learnerResponse;
	var qnum;
	var unitobj;
	var lessonobj;
	var screenobj;
	var tabcheck;
	var numberofquestions = testQuestionSequence.length;
	var i=0;
	var flagAllFlaggedInLong = true;
	var aatQuestionStart = 0
	var aatStartflag = false;

	var html = '<table width="95%" border="0" style="border:1px #999 solid;border-collapse:collapse;" cellpadding="0" cellspacing="0" align="center"><tr>';

	flagAllCompleteInLong = true;

	while(i<numberofquestions)
	{
	html+='<td width="328" valign="top"><table width="328" border="0" cellpadding="0" cellspacing="0"style="border:0px #fff solid;border-collapse:collapse;"><tr><td><table width="328" border="1" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">'

	for(;i<numberofquestions;i++)
	{
		qnum = testQuestionSequence[i];
		learnerResponse = learnerData.GetResponse(qnum,currentUnit,currentLesson);
		unitobj   = GetNode(configObj, "unit", currentUnit);
		lessonobj = GetNode(unitobj, "lesson", currentLesson);
		screenobj = GetNode(lessonobj, "screen", qnum);
		if(screenobj.getAttribute("flag") == "AAT" && i<=aatQuestionJump)
		{

			if (aatStartflag == false)
			{
			aatQuestionStart = i
			aatStartflag = true
			}
			if(learnerResponse[4] == "true")
			{

			}
			else if(learnerResponse[4] == "false" && i==aatQuestionStart)
			{
				flagAllFlaggedInLong = false;
			}
			else{
				if (i==aatQuestionStart)flagAllFlaggedInLong = false;
			}

			if(learnerResponse[1] == "" || learnerResponse[1] == null)
			{
				questionStatus[i][0]=1
				flagAllCompleteInLong = false;
			}
		}
		else
		{
			if(learnerResponse[1] == "" || learnerResponse[1] == null)
				questionStatus[i][0]=1
		}
	}
 }

 	if(flagAllFlaggedInLong)
	{
		tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+aatQuestionStart+'"><input type="button" id="checkRootID'+aatQuestionStart+'" name="checkRootID'+aatQuestionStart+'" class="Flag_Selected_Out" onclick="parent.codeFrame.SetUnChecked('+aatQuestionStart+','+aatQuestionStart+')" /></td></tr></table>'
	}
	else
	{
		tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+aatQuestionStart+'"><input type="button" id="checkRootID'+aatQuestionStart+'" name="checkRootID'+aatQuestionStart+'" class="Flag_Incomplete_Out" onclick="parent.codeFrame.SetChecked('+aatQuestionStart+','+aatQuestionStart+')" onmouseover="parent.codeFrame.Flag_Incomplete_Over(id)" onmouseout="parent.codeFrame.Flag_Incomplete_Out(id)" /></td></tr></table>'
	}

	if(flagAllCompleteInLong)
	{
		icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#000;padding-left:15px;'>Complete</td></tr></table>"
	}
	else
	{
		icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#C00;padding-left:15px;'>Incomplete</td></tr></table>"
	}

	html = html + '</table></td></tr></table></td>';
	html = html + '<td width="*"></td>';
	html += '</tr></table>';


return html;
}



function LPreparefeedbackPageforNavigator()
{
	var icon;
	var learnerResponse;
	var qnum;
	var unitobj;
	var lessonobj;
	var screenobj;
	var tabcheck;
	var numberofquestions = testQuestionSequence.length;
	var i=0;
	var flagAllFlaggedInLong = true;
	var aatQuestionStart = 0
	var aatStartflag = false;

	var html = '<table width="100%" border="1" style="border:1px #999 solid;border-collapse:collapse;" cellpadding="0" cellspacing="0" align="center"><tr>';

	flagAllCompleteInLong = true;

	while(i<numberofquestions)
	{
	html+='<td width="290" valign="top"><table width="290" border="0" cellpadding="0" cellspacing="0"style="border:0px #fff solid;border-collapse:collapse;"><tr><td><table width="290" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">'

	for(;i<numberofquestions;i++)
	{
		qnum = testQuestionSequence[i];
		learnerResponse = learnerData.GetResponse(qnum,currentUnit,currentLesson);
		unitobj   = GetNode(configObj, "unit", currentUnit);
		lessonobj = GetNode(unitobj, "lesson", currentLesson);
		screenobj = GetNode(lessonobj, "screen", qnum);
		if(screenobj.getAttribute("flag") == "AAT" && i<=aatQuestionJump)
		{

			if (aatStartflag == false)
			{
			aatQuestionStart = i
			aatStartflag = true
			}
			if(learnerResponse[4] == "true" && i==aatQuestionStart)
			{
				flagAllFlaggedInLong = true;
			}
			else if(learnerResponse[4] == "false" && i==aatQuestionStart)
			{
				flagAllFlaggedInLong = false;
			}

			if(learnerResponse[1] == "" || learnerResponse[1] == null)
			{
				questionStatus[i][0]=1
				flagAllCompleteInLong = false;
			}
		}
		else
		{
			if(learnerResponse[1] == "" || learnerResponse[1] == null)
				questionStatus[i][0]=1
		}
	}
 }

 	if(flagAllFlaggedInLong)
	{
		tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+aatQuestionStart+'"><img src="../images/flag01.jpg" id="checkRootID'+aatQuestionStart+'" name="checkRootID'+aatQuestionStart+'" class="Flag_Selected_Out_Navigator" /></td></tr></table>'
	}
	else
	{
		tabcheck = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td id="SetCheckedval_id'+aatQuestionStart+'"><img src="../images/flag03.jpg" id="checkRootID'+aatQuestionStart+'" name="checkRootID'+aatQuestionStart+'" class="Flag_Incomplete_Out_Navigator" /></td></tr></table>'
	}

	if(flagAllCompleteInLong)
	{
		icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#000;padding-left:15px;'>Complete</td></tr></table>"
	}
	else
	{
		icon = "<table width='90' border='0' cellpadding='0' cellspacing='0'><tr><td height=15 style='font : 14px Verdana, Geneva, sans-serif;color:#C00;padding-left:15px;'>Incomplete</td></tr></table>"
	}

	html = html + '</table></td></tr></table></td>';
	html = html + '<td width="33%">'+icon+'</td><td width="33%" align="center">'+tabcheck+'</td>';
	html += '</tr></table>';


return html;
}

//LongQ
function GetCategoryDescription(thiscategory)
{
	var categories = categoryObj.getElementsByTagName("category");
	for(var j=0;j<categories.length;j++)
	{
		if(thiscategory == categories[j].getAttribute("categoryID").toLowerCase())
		{
			var desc = GetNodeValue(categories[j], "categoryNameDescription", 0);
			if(desc == null)
			{
				return "";
			}
			else
			{
				return desc;
			}
		}
	}
	return "";
}

function GetCategoryDescriptionForNode(node, n)
{
	var cat = GetNode(node, "category", n);
	if(cat)
	{
		var desc = GetNodeValue(cat, "categoryNameDescription", 0);
		if(desc == null)
		{
			return "";
		}
		else
		{
			return desc;
		}
	}
	else
	{
		return "";
	}
}
var pdfsummaryhtm = "";
function PrepareCategoryBreakup(pscore)
{
	var fillsize = 48;
	var swidth = Math.round((Number(pscore[5])/100)*fillsize);
	var fwidth = fillsize - swidth;
	var tmpHTML = "";
	pdfsummaryhtm += '<table><tr><td>Total</td><td>Total Questions</td><td>Attempted</td><td>Score</td><td>Max Score</td><td>Scaled Score</td></tr>';
	var htmStr = '<table border="0" cellpadding="0" cellspacing="3" width="100%">'
	htmStr = htmStr + '<tr><td colspan="13"><img src="../images/clr_gif.gif" width="1" height="18" border="0"/></td></tr><tr><td colspan="13" valign="bottom" nowrap="nowrap" class="table_head"><img src="../images/clr_gif.gif" width="15" height="1" border="0"/>';

	htmStr = htmStr + GetCategoryDescriptionForNode(categoryObj, 0);
	htmStr = htmStr + '</td></tr><tr><td colspan="3"/><td align="right" valign="bottom" height="13" class="table_head" nowrap="nowrap">Total Questions</td><td></td><td align="right" valign="bottom" height="13" nowrap="nowrap" class="table_head">Attempted</td><td></td><td align="right" valign="bottom" height="13" nowrap="nowrap" class="table_head">Score</td><td></td><td align="right" valign="bottom" height="13" nowrap="nowrap" class="table_head">Max Score&#160&#160&#160&#160&#160</td><td align="left" valign="bottom" height="13" class="table_head" nowrap="nowrap" colspan="2">Scaled Score</td></tr><tr><td colspan="13" class="table_head_line" height="1"><img src="../images/clr_gif.gif" width="1" height="1" border="0"/></td></tr>';
	htmStr = htmStr + '<tr><td></td><td colspan="1" valign="middle" align="left" class="table_total"><b>Total</b></td><td></td><td align="left" valign="middle" class="table_total" height="13" nowrap="nowrap">';
	tmpHTML = totalQuestionsForDisplay;
	pdfsummaryhtm += '<tr><td><b>Total</b></td><td>'+tmpHTML+'</td>';
	htmStr = htmStr + tmpHTML
	htmStr = htmStr + '</td><td></td><td align="left" valign="middle" class="table_total" height="13" nowrap="nowrap">';
	tmpHTML = getTotalAttempted();
	pdfsummaryhtm += '<td>'+tmpHTML+'</td>';
	htmStr = htmStr + tmpHTML;
	htmStr = htmStr + '</td><td></td><td align="left" valign="middle" class="table_total" height="13" nowrap="nowrap">';
	tmpHTML = Number(totalAatCorrect + totalnonLongnumCorrect)*2;
	pdfsummaryhtm += '<td>'+tmpHTML+'</td>';
	htmStr = htmStr + tmpHTML;
	tmpHTML = Number(totalQuestionsForDisplay)*2;
	pdfsummaryhtm += '<td>'+tmpHTML+'</td>';
	htmStr = htmStr + '</td><td></td><td class="table_total">'+Number(totalQuestionsForDisplay)*2+'</td><td align="right" valign="middle" class="table_total" height="13" nowrap="nowrap">';
	if(swidth == 0)
	{
		htmStr = htmStr + '<img src="../images/bar_side.gif" border="0" height="9" width="1"/>';
	}
	else
	{
		htmStr = htmStr + '<img src="../images/bar_side.gif" border="0" height="9" width="' + swidth + '"/>';
	}
	if(swidth < fillsize)
	{
		htmStr = htmStr + '<img src="../images/bar_mid.gif" border="0" height="9" width="' + fwidth + '"/>';
	}
	else
	{
		htmStr = htmStr + '<img src="../images/bar_side.gif" border="0" height="9" width="1"/>';
	}
	htmStr = htmStr + '<img src="../images/bar_side.gif" border="0" height="9" width="1"/>';
	htmStr = htmStr + '</td><td></td><td align="left" valign="middle" class="table_total" height="13" nowrap="nowrap">';
	tmpHTML = pscore[5];
	pdfsummaryhtm += '<td>'+tmpHTML;
	htmStr = htmStr + tmpHTML;
	tmpHTML = '%</td></tr>';
	pdfsummaryhtm += tmpHTML;
	htmStr = htmStr + tmpHTML;
	htmStr = htmStr + '<tr><td colspan="13" class="table_head_line" height="1"><img src="../images/clr_gif.gif" width="1" height="1" border="0"/></td></tr>';
	var catbreakuparray = GetCategoryBreakup();
	tmpHTML = "";
	for(var i=0; i<catbreakuparray.length; i++)
	{
		tmpHTML = tmpHTML + GetCategoryHTM(catbreakuparray[i]);
	}
	htmStr = htmStr + tmpHTML;
	pdfsummaryhtm += "</table>";
	htmStr = htmStr + '<tr><td colspan="13" class="table_head_line" height="1"><img src="../images/clr_gif.gif" width="1" height="1" border="0"/></td></tr><tr><td width="15"><img src="../images/clr_gif.gif" width="15" height="1" border="0"/></td><td width="100%" colspan="7"><img src="../images/clr_gif.gif" width="1" height="1" border="0"/></td></tr><tr><td colspan="8" height="25"><img src="../images/clr_gif.gif" width="1" height="30" border="0"/></td></tr></table>';
	return htmStr;

}

function getTotalAttempted()
{
	var screenobj;
	var totalNotAttemptedL = 0;
	var totalNotAttempted = 0;
	var longAttempted = 0;
	var tempQuesSet = "";
	var tempQuesSetNext = "";
	var aatqAttempted = 0;
	var totalAatqAttempted = 0;
	var aatQCount = 0;

	totalAttempted = 0

	if (IncompleteArray == null)
	{
		totalAttempted =0;
		return totalAttempted;
	}
	else
	{
	for(var i=0; i<totalQuestionsToInclude; i++)
	{
		screenobj = GetNode(currentLessonObj, "screen", i);
		var learnerResponse = learnerData.GetResponse(testQuestionSequence[i],currentUnit, currentLesson);

		if((screenobj.getAttribute("flag") == "AAT"))
		{
			var screenObjNext;
			var aatSet = 1;

			tempQuesSet = screenobj.getAttribute("questionset")

			for (var j=0; aatSet == 1; j++)
			{
				if (taskData[currentUnit][currentLesson][i+j].attempted){
						aatqAttempted = 1;
				}
				tempQuesSet = screenobj.getAttribute("questionset")
				screenobj = GetNode(currentLessonObj, "screen", i+j);
				if (GetNode(currentLessonObj, "screen", i+j+1))
				{
					screenObjNext = GetNode(currentLessonObj, "screen", i+j+1)
					tempQuesSetNext = screenObjNext.getAttribute("questionset")
					if (tempQuesSet == tempQuesSetNext){
						aatSet = 1
					}
					else{
						aatSet = 0
					}
				}
				else{
					aatSet = 0
				}
			}
			i=i+j-1

			if (aatqAttempted == 1)
			{
				totalAatqAttempted++
			}
			aatqAttempted = 0
			tempQuesSet = ""
			aatQCount++
		}
		else
		{
			if (learnerResponse[1] == ""){
				totalNotAttempted++
			}
		}
	}
	totalAttempted = (totalQuestionsForDisplay - aatQCount - totalNotAttempted) + totalAatqAttempted
	totalaatQCount = aatQCount;
	globaltotalaatQAttempted = totalAatqAttempted;
	return totalAttempted;
	}
}


function GetCategoryBreakup()
{
	var learnerResponse;
	var breakuparray =  new Array();
	var qnum;
	var unitobj;
	var lessonobj;
	var screenobj;
	var reviewobj;
	for(var i=0; i<totalQuestionsToInclude;i++)
	{
		qnum = testQuestionSequence[i];
		learnerResponse = learnerData.GetResponse(qnum,currentUnit,currentLesson);
		unitobj   = GetNode(configObj, "unit", currentUnit);
		lessonobj = GetNode(unitobj, "lesson", currentLesson);
		screenobj = GetNode(lessonobj, "screen", qnum);
		if(screenobj.getAttribute("flag") == "AAT")
		{
			flagIsAAT = true
		}
		else
		{
			flagIsAAT = false
		}

		if(learnerResponse != null)
		{
			breakuparray = AddToBreakup(breakuparray, learnerResponse, screenobj.getAttribute("categoryID").toLowerCase());
		}
	}
	return breakuparray;
}


function AddToBreakup(breakuparray, learnerResponse, cid)
{
	var found = false;
	for(var j=0;j<breakuparray.length;j++)
	{
		if(breakuparray[j][1] == cid)
		{
			found = true;
			if(flagIsAAT)
			{
				if(eval(learnerResponse[2])){
				}
				else
				{
					flagAllCorrectAATForReview = false;
				}
				if(flagAllCorrectAATForReview == false)
				{
					breakuparray[j][2] = totalAatCorrect;
				}
				else
				{
					breakuparray[j][2] = totalAatCorrect;
				}

				if(learnerResponse[1] != "" && learnerResponse[1] != null){
				breakuparray[j][3]=globaltotalaatQAttempted
				}
				breakuparray[j][4]=totalaatQCount;
				breakuparray[j][5] = ((totalAatCorrect/totalaatQCount)*100).toFixed(2);
				breakuparray[j][6] = totalaatQCount;
			}
			else
			{
				if(eval(learnerResponse[2])){
					breakuparray[j][2]++;
				}
				if(learnerResponse[1] != "" && learnerResponse[1] != null){
				breakuparray[j][3]++;

				}
				breakuparray[j][4]++;
				breakuparray[j][5] = percentCorrectNonLongQPart.toFixed(2);
				breakuparray[j][6] = totalQuestionsForDisplay - totalaatQCount;
				break;
			}
		}
	}
	if(!found)
	{
		breakuparray[j] = new Array(6);
		breakuparray[j][0] = 0;
		breakuparray[j][1] = cid;
		if(eval(learnerResponse[2]))
		{
			breakuparray[j][2] = 1;
		}
		else
		{
			breakuparray[j][2] = 0;
			if(flagIsAAT)
			{
			flagAllCorrectAATForReview = false;
			}
		}
		if(learnerResponse[1] != "" && learnerResponse[1] != null){
			breakuparray[j][3] = 1;
		}
		else
		{
			breakuparray[j][3] = 0;
		}
		breakuparray[j][4] = 1;
		if(flagIsAAT)
		{
			breakuparray[j][5] = percentCorrectLongQPart.toFixed(2);
		}
		else
		{
			breakuparray[j][5] = percentCorrectNonLongQPart.toFixed(2);
		}
		breakuparray[j][6] = totalQuestionsForDisplay - totalaatQCount;
	}
	return breakuparray;
}
function GetCategoryHTM(cat)
{
	var tmpHTML = "";
	var htmStr = '<tr><td></td><td valign="middle" align="left"><table border="0" cellpadding="0" cellspacing="0"><tr><td><img src="../images/clr_gif.gif" width="'+eval(cat[0]*8)+'" height="1" border="0"/></td><td align="left" class="table_total">';
	tmpHTML += GetCategoryDescription(cat[1]);
	pdfsummaryhtm += '<tr><td>'+tmpHTML+'</td>';
	htmStr = htmStr + tmpHTML
	htmStr = htmStr + '</td></tr></table></td><td></td><td align="right" valign="middle" class="table_text">';
	tmpHTML = cat[4];
	pdfsummaryhtm += '<td>'+tmpHTML+'</td>';
	htmStr = htmStr + tmpHTML
	htmStr = htmStr + '</td><td></td><td align="left" valign="middle" class="table_text">';
	tmpHTML = cat[3];
	pdfsummaryhtm += '<td>'+tmpHTML+'</td>';
	htmStr = htmStr + tmpHTML
	htmStr = htmStr + '</td><td></td><td align="left" valign="middle" class="table_text">';
	tmpHTML = Number(cat[2])*2;
	pdfsummaryhtm += '<td>'+tmpHTML+'</td>';
	htmStr = htmStr + tmpHTML
	tmpHTML = Number(cat[4])*2;
	pdfsummaryhtm += '<td>'+tmpHTML+'</td>'
	htmStr = htmStr + '</td><td></td><td class="table_text">'+ tmpHTML+'</td><td align="left" valign="middle" class="table_text">';
	var fillsize = 48;
	var swidth = ((cat[2]/cat[4])*fillsize).toFixed(0); //Math.round((Number(cat[5])/100)*fillsize);
	var fwidth = fillsize - swidth;
	if(swidth == 0)
	{
		htmStr = htmStr + '<img src="../images/bar_side.gif" border="0" height="9" width="1"/>';
	}
	else
	{
		htmStr = htmStr + '<img src="../images/bar_side.gif" border="0" height="9" width="' + swidth + '"/>';
	}
	if(swidth < fillsize)
	{
		htmStr = htmStr + '<img src="../images/bar_mid.gif" border="0" height="9" width="' + fwidth + '"/>';
	}
	else
	{
		htmStr = htmStr + '<img src="../images/bar_side.gif" border="0" height="9" width="1"/>';
	}
	htmStr = htmStr + '<img src="../images/bar_side.gif" border="0" height="9" width="1"/>';
	htmStr = htmStr + '</td><td></td><td valign="middle" class="table_text">';
	tmpHTML = ((cat[2]/cat[4])*100).toFixed(2);
	pdfsummaryhtm += '<td>'+tmpHTML+'%</td></tr>';
	htmStr = htmStr + tmpHTML
	htmStr = htmStr + '%</td></tr>';
	return htmStr;
}
function CheckReferenceWindowReady()
{
	if(!(thisWin == null || thisWin == "" || thisWin.closed))
	{
		if(thisWin.document.getElementById("contentDiv"))
		{
			clearTimeout(checktimer);
			referenceWindowReady = true;
			TransformReference();
		}
		else
		{
			checktimer = setTimeout("CheckReferenceWindowReady();", 200);
		}
	}
}

function LoadReference()
{
	if(parent.contentFrame.document.getElementById("referenceXMLPath"))
	{
		loadXMLDoc(contentPath+parent.contentFrame.document.getElementById("referenceXMLPath").value, TransformReference);
	}
	else
	{
		switch(currentScreenType)
		{
		case "question":
			parent.contentFrame.document.getElementById("Exhibit_button").style.display = "none"
		break;
		case "questionreview":
			parent.contentFrame.document.getElementById("Exhibit_button").style.display = "none"
		break;
		}
	}
}

function TransformReference()
{
	xmlObj = req;
	if(isIE)
	{
		var temphtmobj = xmlObj.transformNode(stylesheets.obj["reference"][1]);
		parent.contentFrame.document.getElementById("refContentP").innerHTML  = temphtmobj;
		switch(currentScreenType)
		{
		case "question":
			parent.contentFrame.document.getElementById("Exhibit_button").disabled = false;
		break;
		case "questionreview":
			parent.contentFrame.document.getElementById("Exhibit_button_review").disabled = false;
		break;
		}
	}
	else
	{
		processor = new XSLTProcessor();
		processor.importStylesheet(stylesheets.obj["reference"][1]);
		var newFragment = processor.transformToFragment(xmlObj, parent.contentFrame.document);
		parent.contentFrame.document.getElementById("refContentP").innerHTML = "";
		parent.contentFrame.document.getElementById("refContentP").appendChild(newFragment);

		switch(currentScreenType)
		{
		case "question":
			parent.contentFrame.document.getElementById("Exhibit_button").disabled = false;
		break;
		case "questionreview":
			parent.contentFrame.document.getElementById("Exhibit_button_review").disabled = false;
		break;
		}
	}
}

function CheckMediaWindowReady()
{
	if(!(thisWin == null || thisWin == "" || thisWin.closed))
	{
		if(thisWin.document.getElementById("contentDiv"))
		{
			clearTimeout(checktimer);
			mediaWindowReady = true;
			LoadMedia();
		}
		else
		{
			checktimer = setTimeout("CheckMediaWindowReady();", 200);
		}
	}
}

function LoadMedia()
{
	if(!mediaWindowReady)
	{
		checktimer = setTimeout("CheckMediaWindowReady();", 200);
		return;
	}
	mediaWindowReady = false;
	var mediadata = mediaPopupData.split(",");
	if(mediadata[0] == "FLASH")
	{
		var htmStr = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="'+mediadata[2]+'" height="'+mediadata[3]+'">';
		htmStr = htmStr + '<param name="movie" value="'+contentPath+mediadata[1]+'" />';
		htmStr = htmStr + '<param name="quality" value="high" /><param name="menu" value="false" /><param name="allowFullScreen" value="true" />';
		htmStr = htmStr + '<embed src="'+contentPath+mediadata[1]+'" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="'+mediadata[2]+'" height="'+mediadata[3]+'" allowFullScreen="true"></embed></object>';
	}
	else if(mediadata[0] == "IMAGE" || mediadata[0] == "EQUATION")
	{
		var htmStr = '<img src="'+contentPath+mediadata[1]+'" align="center" border="0"/>';
	}
	thisWin.document.getElementById("contentDiv").innerHTML = htmStr;
}

function GetNode(nodeRoot, nodeName, n)
{
	return nodeRoot.getElementsByTagName(nodeName)[n];
}

function GetNodeValue(nodeRoot, nodeName, n)
{
	var nodeRoot = GetNode(nodeRoot, nodeName, n);
	if(nodeRoot == null)
	{
		return null;
	}
	else
	{
		return nodeRoot.firstChild.nodeValue;
	}
}

function GetNodeInnerHTML(nodeRoot, nodeName,n)
{
	var nodeRoot = GetNode(nodeRoot, nodeName,n);
	if(nodeRoot == null)
	{
		return null;
	}
	else
	{
		return nodeRoot.innerHTML;
	}
}

function GetFileName(nodeRoot, nodeName, n)
{
	var nodesArray = nodeRoot.getElementsByTagName(nodeName);
	return nodesArray.item(n).getElementsByTagName("filename")[0].firstChild.nodeValue;
}

function GetCategoryRootNode(nodeRoot, categoryRootID)
{
	var nodesArray = nodeRoot.getElementsByTagName("category");
	for(var i=0;i<nodesArray.length;i++)
	{
		if(nodesArray.item(i).getAttribute("categoryID") == categoryRootID)
		{
			return nodesArray.item(i);
		}
	}
	return nodeRoot;
}

function GenerateCategoryTree()
{
	maxselectedquestions = 0;
	if(categoryRootID == null)
	{
		categoryRootID = categoryObj.getElementsByTagName("category")[0].getAttribute("categoryID");
	}
	categoryRoot = GetCategoryRootNode(categoryObj, categoryRootID);
	questionsArray = GetQuestionsForCategory(currentLessonObj.getElementsByTagName("itemset").item(0), categoryRootID);
	if(questionsArray!=null&&questionsArray.length>0)
	{
		categoryDistribution[categoryRootID] = questionsArray;
		var nullnode = true;
	}
	var nodesArray = categoryRoot.getElementsByTagName("category");
	var subNodesArray, k, questionsArray;
	var tmpHTML = '<div class="body" id="rootdiv"><table cellspacing="0" cellpadding="0" border="0"><tr align="left" valign="top"><td height="25"><input type="checkbox" value="'+questionsArray.length+'" name="'+categoryRootID+'" id="'+categoryRootID+'" onclick="if(this.checked){parent.codeFrame.CheckNode(this.id, true)}else{parent.codeFrame.CheckNode(this.id, false)}"/><img border="0" height="1" width="2" src="../images/clr_gif.gif"/></td><td>'+categoryRoot.getElementsByTagName("categoryNameDescription")[0].firstChild.nodeValue+'</td></tr></table></div>';
	for(var i=0;i<nodesArray.length;i++)
	{
		nullnode = false;
		questionsArray = GetQuestionsForCategory(currentLessonObj.getElementsByTagName("itemset").item(0), nodesArray.item(i).getAttribute("categoryID"));
		if(questionsArray!=null&&questionsArray.length>0)
		{
			categoryDistribution[nodesArray.item(i).getAttribute("categoryID")] = questionsArray;
			nullnode = true;
		}
		subNodesArray = null;
		subNodesArray = nodesArray.item(i).getElementsByTagName("category");
		tmpHTML += '<div class="body" id="div_'+i+'_0"><table cellspacing="0" cellpadding="0" border="0"><tr align="left" valign="top"><td height="25"><img border="0" height="1" width="20" src="../images/clr_gif.gif"/>';
		if(subNodesArray != null&&subNodesArray.length > 0){
			tmpHTML += '<input name="plusminus_'+i+'" id="plusminus_'+i+'" type="image" onclick="javascript:parent.codeFrame.ExpandNode('+i+', '+subNodesArray.length+')" src="../images/check_plus.gif" expanded="0" />';
		}else{
			tmpHTML += '<image border="0" height="13" width="13" src="../images/check_minus.gif" />';
		}
		tmpHTML += '<img border="0" height="1" width="2" src="../images/clr_gif.gif"/><input type="checkbox" value="'+questionsArray.length+'" name="'+nodesArray.item(i).getAttribute("categoryID")+'" id="'+nodesArray.item(i).getAttribute("categoryID")+'" onclick="if(this.checked){parent.codeFrame.CheckNode(this.id, true)}else{parent.codeFrame.CheckNode(this.id, false)}"/><img border="0" height="1" width="2" src="../images/clr_gif.gif"/></td><td>'+nodesArray.item(i).getElementsByTagName("categoryNameDescription")[0].firstChild.nodeValue+'</td></tr></table></div>';
		if(subNodesArray != null&&subNodesArray.length > 0){
			k = i;
			for(var j=0;j<subNodesArray.length;j++,i++){
				nullnode = false;
				questionsArray = GetQuestionsForCategory(currentLessonObj.getElementsByTagName("itemset").item(0), subNodesArray.item(j).getAttribute("categoryID"));
				if(questionsArray!=null&&questionsArray.length>0){
					categoryDistribution[subNodesArray.item(j).getAttribute("categoryID")] = questionsArray;
					nullnode = true;
				}
				tmpHTML += '<div class="body" id="subdiv_'+k+'_'+j+'" style="display:none"><table cellspacing="0" cellpadding="0" border="0"><tr align="left" valign="top"><td height="25"><img border="0" height="1" width="39" src="../images/clr_gif.gif"/><img border="0" height="13" width="13" src="../images/check_minus.gif"/><img border="0" height="1" width="2" src="../images/clr_gif.gif"/><input type="checkbox" value="'+questionsArray.length+'" name="'+subNodesArray.item(j).getAttribute("categoryID")+'" id="'+subNodesArray.item(j).getAttribute("categoryID")+'" onclick="if(this.checked){parent.codeFrame.CheckNode(this.id, true)}else{parent.codeFrame.CheckNode(this.id, false)}"/><img border="0" height="1" width="2" src="../images/clr_gif.gif"/></td><td>'+subNodesArray.item(j).getElementsByTagName("categoryNameDescription")[0].firstChild.nodeValue+'</td></tr></table></div>';
			}

		}
	}
	return tmpHTML;
}
function CheckCategoryInSelection(cat){
	for(var i=0;i<selectedCategories.length;i++){
		if(selectedCategories[i][0] == cat){
			return i;
		}
	}
	return -1;
}
function RemoveFromSelection(indx)
{
	var newarr = new Array();
	for(var i=0;i<selectedCategories.length;i++)
	{
		if(i != indx) newarr.push(selectedCategories[i]);
	}
	selectedCategories = newarr;
}
function CheckCategory(checkboxObj, yes){
	var indx = CheckCategoryInSelection(checkboxObj.id);
	if(yes){
		if(indx == -1){
			if(!isNaN(Number(checkboxObj.value)) && categoryDistribution[checkboxObj.id]){
				maxselectedquestions += Number(checkboxObj.value);
				var arr = new Array();
				arr[0] = checkboxObj.id;
				arr[1] = categoryDistribution[checkboxObj.id];
				selectedCategories.push(arr);
			}
		}
	}else{
		if(indx != -1){
			if(!isNaN(Number(checkboxObj.value))){
				maxselectedquestions -= Number(checkboxObj.value);
				RemoveFromSelection(indx);
			}
		}
	}
	parent.contentFrame.document.getElementById("maxquestions1").innerHTML = maxselectedquestions;
	if(maxselectedquestions<maxtestsize){
		parent.contentFrame.document.getElementById("maxquestions2").innerHTML = maxselectedquestions;
	}else{
		parent.contentFrame.document.getElementById("maxquestions2").innerHTML = maxtestsize;
	}
}
function GetQuestionsForCategory(node, categoryID){
	var returnArray = new Array();
	var m=0;
	var examScreens = node.getElementsByTagName("id");
	if(examScreens != null){
		for(var n=0;n<examScreens.length;n++){
			if(examScreens.item(n).getAttribute("categoryID") == categoryID){
				returnArray[m] = Number(examScreens.item(n).getAttribute("sequence"));
				m++;
			}
		}
	}
	return returnArray;
}
function ExpandNode(which, howmany){
	if(parent.contentFrame.document.getElementById("plusminus_"+which).expanded == "0"){
		var expand = true;
		parent.contentFrame.document.getElementById("plusminus_"+which).expanded = "1";
		parent.contentFrame.document.getElementById("plusminus_"+which).src = "../images/check_minus.gif";
	}else{
		var expand = false;
		parent.contentFrame.document.getElementById("plusminus_"+which).expanded = "0";
		parent.contentFrame.document.getElementById("plusminus_"+which).src = "../images/check_plus.gif";
	}
	for(var n=0;n<howmany;n++){
		if(expand){
			parent.contentFrame.document.getElementById("subdiv_"+which+"_"+n).style.display = "block";

		}else{
			parent.contentFrame.document.getElementById("subdiv_"+which+"_"+n).style.display = "none";
		}
	}
}
function CheckNode(nodeID, yes){
	var node = GetCategoryRootNode(categoryObj, nodeID);
	var nodesArray = node.getElementsByTagName("category");
	var subNodesArray;
	if(yes){
		var chkboxobj = parent.contentFrame.document.getElementById(node.getAttribute("categoryID"));
		chkboxobj.checked = true;
		CheckCategory(chkboxobj, true);

	}else{
		var chkboxobj = parent.contentFrame.document.getElementById(node.getAttribute("categoryID"));
		chkboxobj.checked = false;
		CheckCategory(chkboxobj, false);
		if(node.parentNode.nodeName == "category"){
			chkboxobj = parent.contentFrame.document.getElementById(node.parentNode.getAttribute("categoryID"));
			if(chkboxobj!=null&&chkboxobj!=undefined){
				if(chkboxobj.checked){
					chkboxobj.checked = false;
					CheckCategory(chkboxobj, false);
				}
			}
		}
		if(node.parentNode.parentNode){
			if(node.parentNode.parentNode.nodeName == "category"){
				chkboxobj = parent.contentFrame.document.getElementById(node.parentNode.parentNode.getAttribute("categoryID"));
				if(chkboxobj!=null&&chkboxobj!=undefined){
					if(chkboxobj.checked){
						chkboxobj.checked = false;
						CheckCategory(chkboxobj, false);
					}
				}
			}
		}
	}
	for(var i=0;i<nodesArray.length;i++){
		if(yes){
			chkboxobj = parent.contentFrame.document.getElementById(nodesArray.item(i).getAttribute("categoryID"));
			chkboxobj.checked = true;
			CheckCategory(chkboxobj, true);
		}else{
			chkboxobj = parent.contentFrame.document.getElementById(nodesArray.item(i).getAttribute("categoryID"));
			chkboxobj.checked = false;
			CheckCategory(chkboxobj, false);
		}
		subNodesArray = null;
		subNodesArray = nodesArray.item(i).getElementsByTagName("category");
		if(subNodesArray != null&&subNodesArray.length > 0){
			for(var j=0;j<subNodesArray.length;j++,i++){
				if(yes){
					chkboxobj = parent.contentFrame.document.getElementById(subNodesArray.item(j).getAttribute("categoryID"));
					chkboxobj.checked = true;
					CheckCategory(chkboxobj, true);
				}else{
					chkboxobj = parent.contentFrame.document.getElementById(subNodesArray.item(j).getAttribute("categoryID"));
					chkboxobj.checked = false;
					CheckCategory(chkboxobj, false);
				}
			}

		}
	}
}
function CheckAll(){
	CheckNode(categoryRootID, true);
}
function UncheckAll(){
	CheckNode(categoryRootID, false);
}
function BuildTest()
{
	if(selectedCategories.length<=0)
	{
		alert("Please choose one or more categories to include.");
		return;
	}
	totalBuildQuestions = TrimStrLeadinTrailing(parent.contentFrame.document.getElementById("testSize").value);
	if(totalBuildQuestions=="" || totalBuildQuestions == null)
	{
		alert("Please enter the number of questions you would like for this test.");
		parent.contentFrame.document.getElementById("testSize").focus();
		return;
	}
	if(isNaN(totalBuildQuestions))
	{
		alert("Please enter a valid number of questions you would like for this test.");
		parent.contentFrame.document.getElementById("testSize").focus();
		return;
	}
	if(totalBuildQuestions<=0)
	{
		alert("Please enter a number greater than 0 for the questions you would like for this test.");
		parent.contentFrame.document.getElementById("testSize").focus();
		return;
	}
	var tmpmaxsize = (maxselectedquestions<maxtestsize)?maxselectedquestions:maxtestsize;
	if(totalBuildQuestions>tmpmaxsize)
	{
		alert("Please enter the number "+tmpmaxsize+" or less for the questions you would like for this test.");
		parent.contentFrame.document.getElementById("testSize").focus();
		return;
	}
	customTestTimed = parent.contentFrame.document.getElementById("timed").checked;
	if(customTestTimed)
	{
		customTestDuration = TrimStrLeadinTrailing(parent.contentFrame.document.getElementById("duration").value);
		if(customTestDuration=="" || customTestDuration == null)
		{
			alert("Please enter a duration for this test.");
			parent.contentFrame.document.getElementById("duration").focus();
			return;
		}
		if(isNaN(customTestDuration))
		{
			alert("Please enter a valid duration for this test.");
			parent.contentFrame.document.getElementById("duration").focus();
			return;
		}
		if(customTestDuration <=0)
		{
			alert("Please enter a duration greater than 0 for this test.");
			parent.contentFrame.document.getElementById("duration").focus();
			return;
		}
		timed = "R";
		examtimeoutduration = customTestDuration = customTestDuration*60*1000;
		learnerData.timeLimit = ConvertToTimeFormat(eval(examtimeoutduration/1000));
	}
	BuildWeightedSequence(selectedCategories,totalBuildQuestions);
	totalScreens = totalQuestions = totalBuildQuestions;
	lastScreen = totalQuestions - 1;
	currentScreenType = "teststart";
	xmlFileName = xmlPath + "IN_dummy.xml";
	loadXMLDoc(xmlFileName, processReqChangeForData);
}
function BuildWeightedSequence(catarray,testsize)
{
	parent.contentFrame.document.getElementById("preloader").style.visibility = "visible";
	var tmpCustomTestSequence = new Array();
	var num=0, m=0, tmpTotalNum=0, tmprandomarry, tmpslicedarry;
	for(var n=0;n<catarray.length;n++){
		if(catarray[n][1].length>0){
			num = Math.ceil((catarray[n][1].length/maxselectedquestions)*testsize);
			tmpTotalNum += num;
			if(shuffle == "Y"){
				tmprandomarry = RandomizeArray(catarray[n][1]);
				tmpslicedarry = tmprandomarry.slice(0, num);

			}else{
				tmpslicedarry = (catarray[n][1]).slice(0, num);
			}
			tmpCustomTestSequence[m] = tmpslicedarry;
			m++;
		}
	}
	if(tmpTotalNum>testsize){
		tmpCustomTestSequence = RemoveQuestions(tmpCustomTestSequence.reverse(), tmpTotalNum-testsize);
	}
	customTestSequence = new Array();
	var j=0;
	for(var m=tmpCustomTestSequence.length-1;m>=0;m--){
		for(var n=tmpCustomTestSequence[m].length-1;n>=0;n--){
			customTestSequence[j] = tmpCustomTestSequence[m][n];
			j++;
		}
	}
	if(shuffle == "Y"){
		customTestSequence = RandomizeArray(customTestSequence);
	}
}
function RemoveQuestions(tmpCustomTestSequence, howmany){
	for(var j=0;j<tmpCustomTestSequence.length;j++){
		if(tmpCustomTestSequence[j].length>1){
			tmpCustomTestSequence[j].pop();
			howmany--;
			if(howmany<=0){
				break;
			}else{
				if(j==tmpCustomTestSequence.length-1){
					j=0;
				}
			}
		}
	}
	if(howmany>0){
		for(var j=0;j<tmpCustomTestSequence.length;j++){
			if(tmpCustomTestSequence[j].length>0){
				tmpCustomTestSequence[j].pop();
				howmany--;
				if(howmany<=0){
					break;
				}else{
					if(j==tmpCustomTestSequence.length-1){
						j=0;
					}
				}
			}
		}
	}
	return tmpCustomTestSequence;
}
function ParseCategoryWeightedSelectionParameters(lconfig, isShuffle)
{
	var itemselectionstrategy = GetNode(lconfig, "itemselectionstrategy", 0);
	var catWeightedItemSelectionParameters = GetNode(itemselectionstrategy, "catWeightedItemSelectionParameters", 0);
	totalNumDeliverables = Number(GetNodeValue(lconfig, "totalNumDeliverables", 0));
	categoryItemCount = catWeightedItemSelectionParameters.getElementsByTagName("categoryItemCount");
	var tmpWeightedTestSequence = new Array();
	var tmparry, k=0, tmprandomarry, tmpslicedarry;
	for(var i=0;i<categoryItemCount.length;i++){
		tmparry = GetQuestionsForCategory(lconfig, categoryItemCount.item(i).getAttribute("categoryID"));
		if(isShuffle == "Y"){
			tmprandomarry = RandomizeArray(tmparry);
			tmpslicedarry = tmprandomarry.slice(0, categoryItemCount.item(i).firstChild.nodeValue);

		}else{
			tmpslicedarry = tmparry.slice(0, categoryItemCount.item(i).firstChild.nodeValue);
		}
		tmpWeightedTestSequence[k] = tmpslicedarry;
		k++;
	}
	weightedTestSequence = new Array();
	var j=0;
	for(var k=0;k<tmpWeightedTestSequence.length;k++)
	{
		for(var l=0;l<tmpWeightedTestSequence[k].length;l++)
		{
			weightedTestSequence[j] = tmpWeightedTestSequence[k][l];
			j++;
		}
	}
	if(isShuffle == "Y")
	{
		weightedTestSequence = RandomizeArray(weightedTestSequence);
	}
	return weightedTestSequence;
}
function DisableAnswers(resp)
{
	if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
	{
		var uresp = resp[1];
		uresp = (uresp.split("##T##")).join("~");
		uresp = (uresp.split("##B##")).join("]");
		uresp = (uresp.split("##S##")).join(";");
		uresp = (uresp.split("##C##")).join(",");
		uresp = (uresp.split("##O##")).join(":");
		parent.contentFrame.document.getElementById("answer").innerHTML = "<b>Your answer:</b> " + uresp.replace("~","&#160;").replace(/~/g,", ");
		parent.contentFrame.document.getElementById("correct").innerHTML = "<b>Correct answer:</b> " + answerParameters.correctAnswer.replace("~","&#160;").replace(/~/g,", ").replace(/@/g," or ");
	}

	if(answerTypeCD == "MATCHING")
	{
		var selectObjs = parent.contentFrame.document.getElementsByTagName("select");
		var ansary = resp[1].split(" ");
		var selectObjName, selectans;
		var tmpselect;
		for(var i=0;i<selectObjs.length;i++)
		{
			selectObjName = selectObjs[i].id;
			if(selectObjName.indexOf("selected_") != -1)
			{
				for(var n=0;n<ansary.length;n++)
				{
					if(selectObjName.substr(selectObjName.indexOf("selected_")+9,selectObjName.length) == ansary[n])
					{
						selectans = ansary[n+1];
						break;
					}
				}
				tmpselect = parent.contentFrame.document.getElementById(selectObjName);
				for(var j=0;j<tmpselect.options.length;j++)
				{
						if(tmpselect.options[j].value == selectans)
						{
								tmpselect.selectedIndex = j;
						}
				}
			}
			else if(selectObjName.indexOf("correct_") != -1)
			{
				selectans = answerParameters[selectObjName.substr(selectObjName.indexOf("correct_")+8,selectObjName.length)];
				tmpselect = parent.contentFrame.document.getElementById(selectObjName);
				for(var j=0;j<tmpselect.options.length;j++)
				{
						if(tmpselect.options[j].value == selectans)
						{
								tmpselect.selectedIndex = j;
						}
				}
			}
		}
	}
	if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
	{
		var the_char  = resp[1].charAt(0);
		var respdata  = resp[1].replace(the_char,"");
		var ansaryd   = respdata.split(" ");
		var checkObjName, checkans;
		var tmpcheck;

		var checkObjs = parent.contentFrame.document.getElementsByTagName("input")
		for(var i=0;i<checkObjs.length;i++)
		{
			if(checkObjs[i].type=="checkbox")
			{
					checkObjs[i].disabled = true;
					for(var m=0; m<ansaryd.length; m++)
					{
						if(checkObjs[i].id == ansaryd[m])
						{
							checkans = ansaryd[m];
							parent.contentFrame.document.getElementById(checkans).checked = true;
							break;
						}
					}
					for(var l=0;l<answerParameters.length;l++)
					{
						if(checkObjs[i].id == "check_"+answerParameters[l])
						{
						 checkObjs[i].parentNode.parentNode.parentNode.style.backgroundColor = "#F0F0E9";
						}
					}

			 }
		}
	}
	var inputObjs = parent.contentFrame.document.getElementsByTagName("input");
	var correctid = currentScreenObj.getAttribute("correct");
	if(correctid == null || correctid == "")
	{
		correctid = answerParameters;
	}
	for(var i=0;i<inputObjs.length;i++)
	{
		if(inputObjs[i].id == "answer")
		{
			inputObjs[i].disabled = true;
			if(resp[1] == inputObjs[i].value)
			{
				inputObjs[i].checked = true;
			}
			if(correctid == inputObjs[i].value)
			{
				inputObjs[i].parentNode.parentNode.parentNode.style.backgroundColor = "#F0F0E9";
			}
		}
	}
}

function IsResponseCorrect()
{
	if(answerTypeCD == "SPREADSHEET" || answerTypeCD == "ESSAY") return "";
	if(answerTypeCD == "FILLIN_SINGLE_ANSWER")
	{
		return EvaluateFillin(selectedOptionID);
	}
	if(answerTypeCD == "MATCHING")
	{
		return EvaluateMatching(selectedOptionID);
	}
	if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
	{
		return EvaluateMultipleChoice(selectedOptionID);
	}
	if(selectedOptionID == null || selectedOptionID == "")
	{
		return 0;
	}
	if(currentScreenFlag != "AAT")
	{
		var correctid = currentScreenObj.getAttribute("correct");
		if(correctid == null || correctid == "")
		{
			correctid = answerParameters;
		}
	}
	else
	{
		correctid = answerParameters;
	}
	if(correctid == selectedOptionID)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

function CheckAnswer()
{
	if(answerTypeCD == "FILLIN_SINGLE_ANSWER" && currentScreenFlag != "AAT")
	{
		if(parent.contentFrame.document.getElementById("answer")){
			selectedOptionID = TrimStr(parent.contentFrame.document.getElementById("answer").value);
			}
		if(parent.contentFrame.document.getElementById("answer1")){
			var inputs = parent.contentFrame.document.getElementsByTagName("input")
			selectedOptionID = ""
			for(var i=0;i<inputs.length;i++)
			{
				if(inputs[i].type=="text")
				{
					selectedOptionID += "##T##" + TrimStr(parent.contentFrame.document.getElementsByTagName("input")[i].value);
					if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
				}
			}
			if(!isChecked)selectedOptionID = "";
		}
	}
	if(answerTypeCD == "MATCHING")
	{
		var isSelected = false
		selectedOptionID = "";
		for(var i=0;i<parent.contentFrame.document.getElementsByTagName("select").length;i++)
		{
			selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("select")[i].id+" "+parent.contentFrame.document.getElementsByTagName("select")[i].value;
			if(parent.contentFrame.document.getElementsByTagName("select")[i].value != "") isSelected = true;
		}
		if(!isSelected)selectedOptionID = "";
	}
	if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
	{
		var isChecked = false
		selectedOptionID = "";
		var inputs = parent.contentFrame.document.getElementsByTagName("input")
		for(var i=0;i<inputs.length;i++)
		{
			if(inputs[i].type=="checkbox")
			{
				if (eval(parent.contentFrame.document.getElementsByTagName("input")[i].checked) == true)
				{
				selectedOptionID += ((i==0?"":" ")) + parent.contentFrame.document.getElementsByTagName("input")[i].id;
				}
			}
			if(parent.contentFrame.document.getElementsByTagName("input")[i].value != "") isChecked = true;
		}
		if(!isChecked)selectedOptionID = "";
	}
	if(selectedOptionID == "" && !(currentScreenObj.getAttribute("flag") == "AAT"))
	{
		alert("You must first select an answer");
		return;
	}
	if(currentScreenObj.getAttribute("flag") == "AAT")
	{
		reviewmode = true;
		checkanswer = true;
		currentScreenFlag = "AAT";
		RenderAATQuestionSet(currentScreenObj.getAttribute("questionset"));
	}
	else
	{
		GetExplanation(IsResponseCorrect());
		parent.contentFrame.document.getElementById("rationale").style.display = "block";
	}
}
function ShowRationale(correct)
{
	if(eval(correct))
	{
		parent.contentFrame.document.getElementById("rationaleline1").innerHTML = "That's <span class=\"bold\">correct</span>.";
	}
	else
	{
		parent.contentFrame.document.getElementById("rationaleline1").innerHTML = "That's <span class=\"bold\">incorrect</span>.";
	}
	parent.contentFrame.document.getElementById("rationale").style.display = "block";
}
function GetExplanation(correct)
{
	var explainnode = GetNode(xmlObj, "explanationXML", 0);
	var contentnode = GetNode(explainnode, "content", 0);
	LoadStyleSheetObj("explanation");
	if(isIE)
	{
		if(correct)
		{
			parent.contentFrame.document.getElementById("rationalecontent").innerHTML = "<div>That's <span class=\"bold\">correct</span>.</div><div style=\"font : 1.2em Verdana, Arial;\">" + contentnode.transformNode(xslObj) + "</div><div>Click <span class=\"bold\">Next</span> to continue.</div>";
		}
		else
		{
			parent.contentFrame.document.getElementById("rationalecontent").innerHTML = "<div>That's <span class=\"bold\">incorrect</span>.</div><div style=\"font : 1.2em Verdana, Arial;\">" + contentnode.transformNode(xslObj) + "</div><div>Please try again.</div>";
		}
	}
	else
	{
		processor = new XSLTProcessor();
		processor.importStylesheet(xslObj);
		var newFragment = processor.transformToFragment(xmlObj, parent.contentFrame.document);
		parent.contentFrame.document.getElementById("rationalecontent").innerHTML = "";
		parent.contentFrame.document.getElementById("rationalecontent").appendChild(newFragment);
		if(correct)
		{
			parent.contentFrame.document.getElementById("rationalecontent").innerHTML = "<div>That's <span class=\"bold\">correct</span>.</div><div style=\"font : 1.2em Verdana, Arial;\">" + parent.contentFrame.document.getElementById("rationalecontent").innerHTML + "</div><div>Click <span class=\"bold\">Next</span> to continue.</div>";
		}
		else
		{
			parent.contentFrame.document.getElementById("rationalecontent").innerHTML = "<div>That's <span class=\"bold\">incorrect</span>.</div><div style=\"font : 1.2em Verdana, Arial;\">" + parent.contentFrame.document.getElementById("rationalecontent").innerHTML + "</div><div>Please try again.</div>";
		}
	}
}
function GetNewQuestionSequence(totalQuestions)
{
	var questionSequence = new Array();
	for (var i=0;i<questionBank;i++)
	{
		questionSequence.push(i);
	}
	if(categoryweighted == "Y")
	{
		var randomizedsequence = RandomizeArray(questionSequence);
		var weightedset = randomizedsequence.slice(0,totalQuestions);
		return weightedset;
	}
	else
	{
		if(shuffle == "Y")
		{
			return RandomizeArray(questionSequence);
		}
		else
		{
			return questionSequence;
		}
	}
}
function SetSessionTime()
{
	sessionEndTime = new Date();
	var seconds = Math.round((sessionEndTime - sessionStartTime)/1000);
	learnerData.Time = ConvertToTimeFormat(seconds);
}
function GetCourseCompletion()
{
	if(justLaunched){
		return;
	}
	var andcompleted = true;
	var andids = completionstrategy.and;
	var orids = completionstrategy.or;
	if(andids)
	{
		for(var i=0;i<andids.length;i++)
		{
			if(CheckComponentCompletion(andids[i].firstChild.nodeValue) != "completed")
			{
				andcompleted = false;
				break;
			}
		}
	}
	var orcompleted = false;
	if(orids)
	{
		for(var i=0;i<orids.length;i++)
		{
			if(CheckComponentCompletion(orids[i].firstChild.nodeValue) == "completed")
			{
				orcompleted = true;
				break;
			}
		}
	}
	else
	{
		orcompleted = true;
	}
	if((andcompleted && orcompleted) || (lessonType=="exam"&&endTest))
	{
		if(andcompleted && orcompleted)
		{
			learnerData.completionStatus = "completed";
		}
		else
		{
			if(learnerData.completionStatus != "completed")
				learnerData.completionStatus = "incomplete";
		}
		if(true/*courseforcredit*/)
		{
			if(finalpassrate == 0)
			{
				learnerData.successStatus = "passed";
				return "completed";
			}
			else if(learnerData.GetFinalScore() >= finalpassrate)
			{
				learnerData.successStatus = "passed";
				return "passed";
			}
			else
			{
				learnerData.successStatus = "failed";
				return "failed";
			}
		}
		else
		{
			return "completed";
		}
	}
	else
	{
		learnerData.completionStatus = "incomplete";
		return "incomplete";
	}
}
function CheckComponentCompletion(id)
{
	var node = GetNodeForID(id)
	if(node)
	{
		if(node.nodeName == "unit")
		{
			return CheckUnitCompletion(Number(node.getAttribute("sequence")));
		}
		else if(node.nodeName == "lesson")
		{
			var unitnum = Number(node.parentNode.getAttribute("sequence"))
			return CheckLessonCompletion(unitnum, Number(node.getAttribute("sequence")));
		}
	}
	else
	{
		return "completed";
	}
}
function CheckUnitCompletion(u)
{
		var tunits = configObj.getElementsByTagName("unit");
		var tlessons = tunits.item(u).getElementsByTagName("lesson");
		var completed = true
		for(var j=0;j<tlessons.length;j++)
		{
			var lessonProgress = learnerData.GetProgress(u,j)
			if(lessonProgress[0] != "completed")
			{
				completed = false;
				break;
			}
		}
		if(completed)
		{
			return "completed";
		}
		else
		{
			return "incomplete";
		}
}
function CheckLessonCompletion(u, l)
{
	var lessonProgress = learnerData.GetProgress(u,l);
	if(lessonProgress[0] == "completed")
	{
		return "completed";
	}
	else
	{
		return "incomplete";
	}
}
function GetNodeForID(id)
{
	var ids = configObj.getElementsByTagName("id");
	for(var i=0;i<ids.length;i++)
	{
		if(ids[i].firstChild.nodeValue == id && (ids[i].parentNode.nodeName == "unit" || ids[i].parentNode.nodeName == "lesson"))
		{
			return ids[i].parentNode;
		}
	}
}
function GetNodeWithAttributeValue(nodeRoot, nodeName, attributeName, val)
{
	var nodes = nodeRoot.getElementsByTagName(nodeName);
	for(var i=0;i<nodes.length;i++)
	{
		if(nodes[i].getAttribute(attributeName))
		{
			if(nodes[i].getAttribute(attributeName) == val)
				return nodes[i];
		}
	}
}
function SetPercentBar(percent)
{
	var stretchbar = parent.contentFrame.document.getElementById("stretchbar");
	var fillbar = parent.contentFrame.document.getElementById("fillbar");
	var fillsize = 48;
	var swidth = Math.round((percent/100)*fillsize);
	var fwidth = fillsize - swidth;
	fillbar.width = fwidth;
	stretchbar.width = swidth + 1;
}
function GetPercent(numA, numB)
{
	if(numA == 0 && numB == 0) return 0;
	var percent = (numA/numB)*100;
	return (Math.round(percent*100))/100;
}

function SendInteractionInfo(qNum, sid, qObj, resp)
{
	var n = qNum;
	var id = qObj.getAttribute("id");
	if(IsResponseCorrect()==""){
		result = "neutral";
	}else	if(IsResponseCorrect())
	{
		var result = "correct";
	}
	else
	{
		var result = "incorrect";
	}
	var desc = GetCategoryDescription(qObj.getAttribute("categoryID").toLowerCase());
	var type = GetInteractionType(qObj.getAttribute("answerTypeCD"))
	objAICC.SendInteraction(n,id,result,desc,type,sid);
}
function GetInteractionType(qtype){
	switch (qtype) {
		case "ESSAY": return "long-fill-in"; break;
		case "MCLID": return "choice"; break;
		case "MULTIPLE_CHOICE_MULTIPLE_ANSWER": return "choice"; break;
		case "MATCHING": return "matching";break;
		case "FILLIN_SINGLE_ANSWER": return "fill-in";break;
		case "SPREADSHEET": return "matching";break;
		default:

	}
}
function ConvertToSeconds(timestr)
{
	var time = timestr.split(":");
	return (Number(time[0]) * 3600) + (Number(time[1]) * 60) + Number(time[2]);
}
function ConvertToTimeFormat(seconds)
{
	if(seconds > 3600)
	{
		var hrs = parseInt(seconds/3600);
		var seconds = seconds - (hrs * 3600);
	}
	else
	{
		var hrs = "0";
	}
	if(seconds > 60)
	{
		var mins = parseInt(seconds/60);
		var seconds = seconds - (mins * 60);
	}
	else
	{
		var mins = "0";
	}
	var secs = seconds;
	if(objAICC.strMode == "API2")
	{
		return "PT"+hrs+"H"+mins+"M"+secs+"S";
	}
	else
	{
		return Pad(hrs,4,"0",true) +":"+ Pad(mins,2,"0",true) + ":" + Pad(secs,2,"0",true);
	}
}

function FormatTime(milliseconds)
{
	seconds = Math.round((milliseconds)/1000);
	if(seconds > 3600)
	{
		var hrs = parseInt(seconds/3600);
		var seconds = seconds - (hrs * 3600);
	}
	else
	{
		var hrs = "0";
	}
	if(seconds > 60)
	{
		var mins = parseInt(seconds/60);
		var seconds = seconds - (mins * 60);
	}
	else
	{
		var mins = "0";
	}
	var secs = seconds;
	return Pad(hrs,2,"0",true) +":"+ Pad(mins,2,"0",true) + ":" + Pad(secs,2,"0",true);
}

function Pad(no,n,chr,before)
{
	var topad = n - String(no).length;
	var pad = "";
	for(var i=0;i<topad;i++)
	{
		pad = pad + chr;
	}
	if(before)
	{
		return pad + no;
	}
	else
	{
		return no + pad;
	}
}
function RandomizeArray(questionSequence)
{
	//takes an array and returns an array with array items randomized
	//to randomize an array use: arrayToRandomize = RandomizeArray(arrayToRandomize)
	var arrylength = questionSequence.length;
	var now = null;
	var seed = null;
	var random_number = null;
	var range = null;
	var rounded_number = null;
	var randomizedSequence = new Array();
	for(var i=0;i<arrylength;i++){
		now = new Date();
		seed = now.getSeconds();
		random_number = Math.random(seed);
		range = random_number * questionSequence.length;
		rounded_number = Math.round(range);
		if (rounded_number == questionSequence.length){rounded_number = 0};
		randomizedSequence.push(questionSequence.splice(rounded_number,1));
	}
	return randomizedSequence;
}
function GetCurrentDate(datetype)
{
	// current date calculation
	if(datetype == "short"){
		var monthNames=new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
	}
	else
	{
		var monthNames=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
	}
	var dt = new Date();
	var y  = dt.getYear();
	// Y2K compliant
	if (y < 1000) y +=1900;
	return (dt.getDate() + " " + monthNames[dt.getMonth()] + " " + y);
}
function CorrectCase(str, date)
{
	if(str == null || str == "") return "";
	if(date)
	{
		var strarry = str.split(" ");
		switch(strarry[1])
		{
			case "jan":	strarry[1] = "Jan";	break;
			case "feb":	strarry[1] = "Feb";	break;
			case "mar": strarry[1] = "Mar";	break;
			case "apr": strarry[1] = "Apr"; break;
			case "may": strarry[1] = "May"; break;
			case "jun": strarry[1] = "Jun"; break;
			case "jul": strarry[1] = "Jul"; break;
			case "aug": strarry[1] = "Aug"; break;
			case "sep": strarry[1] = "Sep"; break;
			case "oct": strarry[1] = "Oct"; break;
			case "nov": strarry[1] = "Nov"; break;
			case "dec": strarry[1] = "Dec"; break;
			case "january": strarry[1] = "January"; break;
			case "february": strarry[1] = "February"; break;
			case "march": strarry[1] = "March"; break;
			case "april": strarry[1] = "April"; break;
			case "may": strarry[1] = "May"; break;
			case "june": strarry[1] = "June"; break;
			case "july": strarry[1] = "July"; break;
			case "august": strarry[1] = "August"; break;
			case "september": strarry[1] = "September"; break;
			case "october": strarry[1] = "October"; break;
			case "november": strarry[1] = "November"; break;
			case "december": strarry[1] = "December"; break;
		}
		return strarry.join(" ");
	}
	else
	{
		switch(str)
		{
			case "completed":
			return "Completed";
			break;
			case "not completed":
			return "Not Completed";
			break;
			case "active":
			return "Active";
			break;
			case "passed":
			return "Passed";
			break;
			case "not passed":
			return "Not Passed";
			break;
			case "failed":
			return "Failed";
			break;
			case "review mode":
			return "Review Mode";
			break;
			case "exam mode":
			return "Exam Mode";
			break;
			case "custom mode":
			return "Custom Mode";
			break;
			case "incompleted":
			return "Incompleted";
			default:
			return str;
		}
	}
}
function ResetSCO(tunits, level)
{
	switch(level)
	{
		case "exam":
			var fexam;
			var tlesson;
			var tunum;
			var tlnum;
			for(var i=0; i<tunits.length;i++)
			{
				for(var j=0;j<tunits[i].getElementsByTagName("lesson").length;j++)
				{
					tlesson = GetNode(tunit, "lesson", j);
					if(tlesson.getAttribute("type") == "exam")
					{
						fexam = tlesson;
						tunum = i;
						tlnum = j;
					}
				}
			}
			if(fexam)
			{
				var tquestions = fexam.getElementsByTagName("screen").length
				var lessonConfig = GetNode(fexam, "configuration", 0);
				learnerData.InitTestData(GetNewQuestionSequence(tquestions),tunum,tlnum);
				learnerData.SetScore("","","","","","","","",tunum,tlnum);
				learnerData.SetProgress("","","","","",tunum,tlnum);
				learnerData.finalScore = "";
				learnerData.lastVisited = "";
			}
			break;
		case "all":
			learnerData.InitLearnerData(tunits);
			currentLessonTitle = "Welcome "+ studentName +"!";
			break;
	}
}
function GetParamValue(param,paramarray,delim)
{
	var paramstr = param+delim;
	var retstr = "";
	for(i=0;i<paramarray.length;i++)
	{
		if(paramarray[i].indexOf(paramstr)!=-1)
		{
			retstr = paramarray[i].substr(paramarray[i].indexOf(delim)+1,paramarray[i].length);
			return retstr;
		}
	}
	return "";
}
function StartLoading()
{
	aiccEntry = objAICC.Entry();
	if(objAICC.Credit() == "credit")
	{
		courseforcredit = true;
	}
	else
	{
		courseforcredit = false;
	}
	learnerData.Get();
	studentName = learnerData.studentName;
	if(studentName == null || studentName == "")
	{
		appendLog("Student Name not returned by LMS.");
	}
	if(learnerData.launchData == null || learnerData.launchData == "")
	{
		appendLog("No launch data.");
		scocloseonexit = true;
	}
	else
	{
		if(learnerData.launchData.indexOf("&") != -1)
		{
			var paramarray = learnerData.launchData.split("&");
			scoexitpage = GetParamValue("scoexitpage",paramarray, "=");
			resetlevel = GetParamValue("resetlevel",paramarray, "=");
			debugmode = GetParamValue("debugmode",paramarray, "=");
		}
		else
		{
			var ldata = learnerData.launchData.split("=");
			switch(ldata[0])
			{
				case "scoexitpage": scoexitpage = ldata[1]; break;
				case "resetlevel": resetlevel = ldata[1]; break;
				case "debugmode": debugmode = ldata[1]; break;
			}
		}
		if(scoexitpage != null && scoexitpage !="")
		{
			scocloseonexit = false;
		}
		else
		{
			scocloseonexit = true;
		}
		if(debugmode == "true")
		{
			showDebugWin();
			setTimeout("wrtToDebugWin()",2000);
			showDebugLogWin();
			setTimeout("wrtToDebugLogWin()",2000);
		}
	}
	loadXMLDoc(contentPath + courseConfigFileName, processReqChangeForConfig);
}
//----------------new functions--------------//

//var correctanswerhtm = new Array();
function ProcessAnswerParameters(xmlnode)
{
	if(answerTypeCD == "MC_LID")
	{
		var paramstr     = GetNodeValue(xmlnode, "parameters", 0);
		var choiceidref  = paramstr.substring(paramstr.indexOf("<choiceIDRef>")+13, paramstr.indexOf("</choiceIDRef>"));
		answerParameters = choiceidref;
		//var correctoption = GetNodeWithAttributeValue(GetNode(xmlObj,"choiceList",0),"choice","choiceID",choiceidref);
		//correctanswerhtm[currentScreenNum] = '<p>Question '+(currentScreenNum+1)+':'
		//correctanswerhtm[currentScreenNum] += ' '+TrimOptionHTML(GetNodeInnerHTML(correctoption, "content",0))+'</p>'
	}

	if(answerTypeCD == "FILLIN_SINGLE_ANSWER")
	{
		answerParameters = new Object();
		var paramstr = GetNodeValue(xmlnode, "parameters", 0);
		answerParameters.ignoreCase = eval(paramstr.substring(paramstr.indexOf("<ignoreCase>")+12, paramstr.indexOf("</ignoreCase>")));
		answerParameters.ignoreInternalWhitespace = eval(paramstr.substring(paramstr.indexOf("<ignoreInternalWhitespace>")+26, paramstr.indexOf("</ignoreInternalWhitespace>")));
		answerParameters.ignoreNonAlphaNumeric = eval(paramstr.substring(paramstr.indexOf("<ignoreNonAlphaNumeric>")+23, paramstr.indexOf("</ignoreNonAlphaNumeric>")));
		answerParameters.correctAnswer = paramstr.substring(paramstr.indexOf("<stringValue>")+13, paramstr.indexOf("</stringValue>"));
		//correctanswerhtm[currentScreenNum] = '<p>Question '+(currentScreenNum+1)+':'
		//correctanswerhtm[currentScreenNum] += ' '+answerParameters.correctAnswer+'</p>'
	}

	if(answerTypeCD == "MATCHING")
	{
		var paramstr = GetNodeValue(xmlnode, "parameters", 0);
		var cardinality = eval(paramstr.substring(paramstr.indexOf("<cardinality>")+13, paramstr.indexOf("</cardinality>")));
		matches = new Array();
		var starti, sstarti, endi, eendi = 0;
		var tmpstr, tmpary;
		//var correctoption;
		//correctanswerhtm[currentScreenNum] = '<p>Question '+(currentScreenNum+1)+':'
		for(var i=0;i<cardinality;i++)
		{
			starti = paramstr.indexOf("<matching>")+10;
			endi = paramstr.indexOf("</matching>");
			tmpstr = paramstr.substring(starti, endi);
			tmpary = new Array();
			for(var j=0; j<2; j++)
			{
				sstarti = tmpstr.indexOf("<choiceIDRef>")+13;
				eendi = tmpstr.indexOf("</choiceIDRef>");
				tmpary[j] = tmpstr.substring(sstarti, eendi);
				tmpstr = tmpstr.slice(eendi+14, tmpstr.length);
			}
			matches[tmpary[0]] = tmpary[1];
			paramstr = paramstr.slice(endi+11, paramstr.length);

			//correctoption = GetNodeWithAttributeValue(GetNode(xmlObj,"choiceList",0),"choice","choiceID",tmpary[0]);
			//correctanswerhtm[currentScreenNum] += TrimOptionHTML(GetNodeInnerHTML(correctoption, "content",0))+'<==>'
			//correctoption = GetNodeWithAttributeValue(GetNode(xmlObj,"choiceList",0),"choice","choiceID",tmpary[1]);
			//correctanswerhtm[currentScreenNum] += TrimOptionHTML(GetNodeInnerHTML(correctoption, "content",0))+'<br/>'
		}
		//correctanswerhtm[currentScreenNum] += '</p>'
		answerParameters = matches;
	}

	if(answerTypeCD == "MULTIPLE_CHOICE_MULTIPLE_ANSWER")
	{
		var paramstr = GetNodeValue(xmlnode, "parameters", 0);
		var cardinalitymul = eval(paramstr.substring(paramstr.indexOf("<cardinality>")+13, paramstr.indexOf("</cardinality>")));
		multipleAns = new Array();
		var mulstarti, mulsstarti, mulendi, muleendi = 0;
		var multmpstr, multmpary;
		//var correctoption;
		//correctanswerhtm[currentScreenNum] = '<p>Question '+(currentScreenNum+1)+':'
		if(cardinalitymul<1){
			for(var i=0;i<cardinalitymul-1;i++)
			{
				mulstarti = paramstr.indexOf("<choiceResponseMatch>")+21;
				mulendi = paramstr.indexOf("</choiceResponseMatch>");
				multmpstr = paramstr.substring(mulstarti, mulendi);
				multmpary = new Array();
				for(var j=0; j<cardinalitymul; j++)
				{
					mulsstarti = multmpstr.indexOf("<choiceIDRef>")+13;
					muleendi = multmpstr.indexOf("</choiceIDRef>");
					multmpary[j] = multmpstr.substring(mulsstarti, muleendi);
					multmpstr = multmpstr.slice(muleendi+14, multmpstr.length);
				}
				multmpary.push(multmpstr[i])
			}
		}else{
			mulstarti = paramstr.indexOf("<choiceResponseMatch>")+21;
			mulendi = paramstr.indexOf("</choiceResponseMatch>");
			multmpstr = paramstr.substring(mulstarti, mulendi);
			multmpary = new Array();
			for(var j=0; j<cardinalitymul; j++)
			{
				mulsstarti = multmpstr.indexOf("<choiceIDRef>")+13;
				muleendi = multmpstr.indexOf("</choiceIDRef>");
				multmpary[j] = multmpstr.substring(mulsstarti, muleendi);
				multmpstr = multmpstr.slice(muleendi+14, multmpstr.length);

				//correctoption = GetNodeWithAttributeValue(GetNode(xmlObj,"choiceList",0),"choice","choiceID",multmpary[j]);
				//correctanswerhtm[currentScreenNum] += TrimOptionHTML(GetNodeInnerHTML(correctoption, "content",0))+'<br/>'
			}
		}
		answerParameters = multmpary;
		//correctanswerhtm[currentScreenNum] += '</p>'
	}
}

function EvaluateMatching(resp)
{
	if(resp == "" || resp == null) return 0;
	var ansary = new Array();
	var j = 0;
	var correct = true;
	var tmpary = resp.split(" ");
	for(var i=0;i<tmpary.length;i=i+2)
	{
		if(answerParameters[tmpary[i]] != tmpary[i+1])
		{
			correct = false;
			break;
		}
	}
	if(correct)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

function EvaluateMultipleChoice(resp)
{
	if(resp == "" || resp == null) return 0;
	var ansary = new Array();
	var j = 0;
	var correct = true;
	var the_char  = resp.charAt(0);
	if(the_char == " ")
	{
		var respdata  = resp.replace(the_char,"");
		var tmpary   = respdata.split(" ");
	}
	else
	{
		var tmpary = resp.split(" ");
	}
	if(tmpary.length != answerParameters.length) return 0;
	for(var i=0;i<tmpary.length;i++)
	{
		if("check_"+answerParameters[i] != tmpary[i])
		{
			correct = false;
			break;
		}
	}
	if(correct)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

///*Check if user slects more than required options in Multiple choice multiple correct type question
function mcmcorrectCheckAttempt(checkboxnum)
{
	totalcheckedinMCMCQ = 0
	if(parent.contentFrame.document.getElementById(checkboxnum).checked)
	{
		var tmpdivMain = parent.contentFrame.document.getElementById("ques_main");
		var tmpchkBoxes = tmpdivMain.getElementsByTagName("input");

			for(var j=0;j<tmpchkBoxes.length;j++)
			{
				if ((tmpchkBoxes[j].checked))
				{
					totalcheckedinMCMCQ++
				}
			}
	}
	ProcessAnswerParameters(GetNode(xmlObj,  "responseEvaluationStrategy",  0));
	if(totalcheckedinMCMCQ > answerParameters.length)
	{
		alert("You have selected more than the required options. Please check the question.")
		parent.contentFrame.document.getElementById(checkboxnum).checked = false;
	}
}
//Check if user slects more than required options in Multiple choice multiple correct type question*/


function EvaluateFillin(resp)
{
	if(resp == "" || resp == null) return 0;
	resp = (resp.split("##T##")).join("~");
	resp = (resp.split("##B##")).join("]");
	resp = (resp.split("##S##")).join(";");
	resp = (resp.split("##C##")).join(",");
	resp = (resp.split("##O##")).join(":");
	var userAnswer = resp;
	var tempcorrectAnswer = answerParameters.correctAnswer.toString();
	if(tempcorrectAnswer == "" || tempcorrectAnswer == null){
		alert("Error: Evaluation parameter not available, question cannot be evaluated!");
		return 0;
	}
	if (answerParameters.ignoreCase)
	{
		tempcorrectAnswer = tempcorrectAnswer.toLowerCase();
		userAnswer = userAnswer.toLowerCase();
	}
	if (answerParameters.ignoreInternalWhitespace)
	{
		while (userAnswer.indexOf(" ") != -1)
		{
			var tempAnswer = userAnswer.slice(0, userAnswer.indexOf(" "));
			tempAnswer = tempAnswer+userAnswer.slice(userAnswer.indexOf(" ")+1, userAnswer.length);
			userAnswer = tempAnswer;
		}
		while (tempcorrectAnswer.indexOf(" ") != -1)
		{
			var tempVar = tempcorrectAnswer.slice(0, tempcorrectAnswer.indexOf(" "));
			tempVar = tempVar+tempcorrectAnswer.slice(tempcorrectAnswer.indexOf(" ")+1, tempcorrectAnswer.length);
			tempcorrectAnswer = tempVar;
		}
	}
	if (answerParameters.ignoreNonAlphaNumeric)
	{
		var tempAnswer = "";
		var tempvar = "";
		for (var tt = 0; tt<userAnswer.length; tt++)
		{
			if (IsAlphaNumeric(userAnswer.charCodeAt(tt)) || userAnswer.charAt(tt) == "~" || userAnswer.charAt(tt) == "-" || userAnswer.charAt(tt) == "(" || userAnswer.charAt(tt) == ")")
			{
				if (tempAnswer == "")
				{
					tempAnswer = userAnswer.charAt(tt);
				}
				else
				{
					tempAnswer = tempAnswer+userAnswer.charAt(tt);
				}
			}
		}
		userAnswer = tempAnswer;
		for (var nn = 0; nn<tempcorrectAnswer.length; nn++)
		{
			if (IsAlphaNumeric(tempcorrectAnswer.charCodeAt(nn)) || tempcorrectAnswer.charAt(nn) == "~" || tempcorrectAnswer.charAt(nn) == "`" || tempcorrectAnswer.charAt(nn) == "(" || tempcorrectAnswer.charAt(nn) == ")" || tempcorrectAnswer.charAt(nn) == "-"  || tempcorrectAnswer.charAt(nn) == "@")
			{
				if (tempvar == "")
				{
					tempvar = tempcorrectAnswer.charAt(nn);
				}
				else
				{
					tempvar = tempvar+tempcorrectAnswer.charAt(nn);
				}
			}
		}
		tempcorrectAnswer = tempvar;
	}
	if(tempcorrectAnswer.indexOf('~') == -1){

		if (tempcorrectAnswer == userAnswer)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return (EvaluateFillinCustom(userAnswer,tempcorrectAnswer))
	}

}

function EvaluateFillinCustom(userAnswer,tempcorrectAnswer){
	temp1correctAnswer = tempcorrectAnswer.split("~")
	temp1userAnswer = userAnswer.split("~")
	flagFillinisCorrect = true;

	for (var i =0;i<temp1userAnswer.length;i++){
		if(temp1correctAnswer[i].indexOf('@') == -1){
			if(temp1userAnswer[i] != temp1correctAnswer[i]){
				flagFillinisCorrect = false
				break;
			}
		}
		else{
			flagFillinisCorrect = false
			temp2correctAnswer = temp1correctAnswer[i].split("@")
			for(var j=0;j<temp2correctAnswer.length;j++){
				if(temp1userAnswer[i] == temp2correctAnswer[j]){
					flagFillinisCorrect = true;
					}
			}
			if(!flagFillinisCorrect)break;
		}
	}

	if(temp1userAnswer.length < temp1correctAnswer.length) return 0

	if(flagFillinisCorrect){
		return 1
	}
	else{
		 return 0
	}
}

/*function EvaluateFillinLongQ(userAnswer, tempcorrectAnswer){
	temp1correctAnswer = tempcorrectAnswer.split("`")
	var flagCorrectAttemptinLong = false

	for (var i=0;i<temp1correctAnswer.length;i++)
	{
		if(userAnswer == temp1correctAnswer[i])
		{
			flagCorrectAttemptinLong = true
			if(temp1correctAnswer[i+1]/10 == 0)
			{
				return "9999";
			}
			else
			{
				return (temp1correctAnswer[i+1]/10)
			}
		}
		i++
	}
	if (!flagCorrectAttemptinLong)
	{
		return 0;
	}
}*/

function TrimStr(str)
{
	while(''+str.charAt(0)==' ')
	{
		str = str.substring(1,str.length);
	}
	while(''+str.charAt(str.length-1)==' ')
	{
		str = str.substring(0,str.length-1);
	}
	//-- encode chracters that will cause  --//
	//-- a problem in the SCO's SCORM code --//
	str = (str.split("~")).join("##T##");
	str = (str.split("]")).join("##B##");
	str = (str.split(";")).join("##S##");
	str = (str.split(",")).join("##C##");
	str = (str.split(":")).join("##O##");
	return str;
}
function TrimStrLeadinTrailing(str)
{
	if(!str)return '';
	while(''+str.charAt(0)==' ')
	{
		str = str.substring(1,str.length);
	}
	while(''+str.charAt(str.length-1)==' ')
	{
		str = str.substring(0,str.length-1);
	}
	return str;
}
function IsAlphaNumeric(chrcode)
{
	chrcode = Number(chrcode);
	if(chrcode>=48 && chrcode<=57)
	{
		return true;
	}
	else if(chrcode>=65 && chrcode<=90)
	{
		return true;
	}
	else if(chrcode>=97 && chrcode<=122)
	{
		return true;
	}
	else
	{
		return false;
	}
}

function ShowMenuDescription(u,l)
{
	parent.contentFrame.document.getElementById("menuitemdescription_"+u+"_"+l).style.visibility = "visible";
}
function HideMenuDescription(u,l)
{
	parent.contentFrame.document.getElementById("menuitemdescription_"+u+"_"+l).style.visibility = "hidden";
}
function ShowVendorId()
{
	parent.contentFrame.document.getElementById("vendorID").style.visibility = "visible";
}
function HideVendorId()
{
	parent.contentFrame.document.getElementById("vendorID").style.visibility = "hidden";
}


function ButtonExit()
{
	switch(currentScreenType)
	{
		case "instruction":
			NavExit();
			break;
		case "question":
			EndTest();
			break;
		default: LogOut();
	}
}
function ButtonMenu()
{
	switch(currentScreenType)
	{
		case "instruction":
			NavExit();
			break;
		case "question":
			EndTest();
			break;
		default: NavMainMenu();
	}
}
var gWinNote = null;
function LaunchNotes(){
	if(gWinNote==null || gWinNote=="" || gWinNote.closed)
	{
		gWinNote = window.open("../code/notes.htm","NotesWin","width=500,height=400,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0, top=0, left=0");
	}else{
		gWinNote.focus();
	}
}
var gWinCalc = null;

var gWinGlossary = null;
function LaunchGlossary()
{
	if(gWinGlossary==null || gWinGlossary=="" || gWinGlossary.closed)
	{
		gWinGlossary = window.open(contentPath+"glossary_index.html","GlossaryWin","width=524,height=500,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=1,resizable=1, top=0, left=0");
	}
	else
	{
		gWinGlossary.focus();
	}
}
//---------------new code for AAT questions----------------//
function StripHTML(htmlString)
{
	//This pattern Matches everything found inside html tags;
	//(.|\n) - > Look for any character or a new line
	// *?  -> 0 or more occurences, and make a non-greedy search meaning
	//That the match will stop at the first available '>' it sees, and not at the last one
	//(if it stopped at the last one we could have overlooked
	//nested HTML tags inside a bigger HTML tag..)
	// Thanks to Oisin and Hugh Brown for helping on this one...

	var pattern = /<(.|\n)*?>/;
	return  htmlString.replace(pattern,"");
}
function Strip(str)
{
	//Strip leading and trailling spaces
    return str.replace(/^\s+/, '').replace(/\s+$/, '');
}
function RemoveProblemChars(str)
{
	var tmpstr = str.replace(/[:,;\]~]/g, "");
	return tmpstr;
}
var aatqstartpos = 0;
function RenderAATQuestionSet(qsetid)
{
	if(reviewmode){
		if(parent.contentFrame.document.getElementById("review_but_table"))
			{
			parent.contentFrame.document.getElementById("review_but_table").style.display = "none";
			}
	}
	currentScreenFlag = "AAT";
	var qnode = null;
	qseton = true;
	var tmpdiv = null;
	var qdivarray = new Array();
	var tqarry = new Array();
	var makedragdata = new Array();
	var startpos = -1;
	for(var n=0;n<totalQuestions;n++)
	{
		qnode = GetNode(currentLessonObj, "screen", n);
		if(qnode.getAttribute("questionset") == qsetid)
		{
			if(startpos == -1) startpos = n;
			tqarry.push(qnode);
			currentScreenNum = n;
		}
	}
	/*if (Reviewtab > 0)
	{
		if(SelectcheckArray != null)
		{
			if(currentFlagScreenNum == -1)
			{
			currentFlagScreenNum = 0
			}
			currentFlagScreenNum += tqarry.length

		}

	}*/
	aatQuestionJump = tqarry.length;
	currentScreenType = "aatreadingpassage";
	questiondragitems = "";
	xmlFileName = contentPath + tqarry[0].getAttribute("readingpassage");
	loadXMLDoc(xmlFileName, processReqChangeForData);
	readingpassageid = GetNode(xmlObj, "instruction",0).getAttribute("instructionID");

	for(var i=0;i<tqarry.length;i++)
	{
		qnode = tqarry[i];
		if(clearresponse || (!reviewmode && !(lessonType == "exam" || lessonType == "test" || lessonType=="customtest")))
		{
			ResetAATQuestion(currentUnit,currentLesson,(startpos+i));
		}
		currentqid = qnode.getAttribute("id");
		questiondiv = readingpassageid+"_"+currentqid+":"+1;
		currentScreenType = "aatquestion";
		xmlFileName = contentPath + GetFileName(currentLessonObj, "screen", (startpos+i));
		loadXMLDoc(xmlFileName, processReqChangeForData);

		var qxml     = GetNode(xmlObj, "question", 0);
		var tstem    = GetNode(qxml, "questionStemXML",0);
		var tcontent = GetNode(tstem, "content",0);
		var tqtype   = GetNodeValue(tcontent, "para", 0);
		var tmpqid   = qxml.getAttribute("questionID");
		var tmpqdiv  = parent.contentFrame.document.getElementById("qdiv_"+questiondiv);
		qdivarray.push(tmpqdiv);

		if(tqtype == "TRUEFALSE" || tqtype == "MULTICHOICE")
		{
			var tmphiddeninps = tmpqdiv.getElementsByTagName("div")[0].getElementsByTagName("input");
			for(var j=0;j<tmphiddeninps.length;j++)
			{
				var tmpinpid = tmphiddeninps[j].id.substr(tmphiddeninps[j].id.lastIndexOf("_"),tmphiddeninps[j].id.length);
				var tmpstr = readingpassageid+tmpinpid;
				var tmpq = parent.contentFrame.document.getElementById("question_"+readingpassageid);
				var tmpinps = tmpq.getElementsByTagName("input");
				for(h=0;h<tmpinps.length;h++)
				{
					if(tmpinps[h].id == tmpstr)
					{
						tmpinps[h].value = tmphiddeninps[j].value;
						break;
					}
				}
				if(tmpinps[h].value == taskData[currentUnit][currentLesson][(startpos+i)].selectedOptionID)
				{
					if(reviewmode)
					{
						if(taskData[currentUnit][currentLesson][(startpos+i)].iscorrect)
						{
							parent.contentFrame.document.getElementById("qdiv_"+tmpstr).className = "radiobtn_correct";
						}
						else
						{
							parent.contentFrame.document.getElementById("qdiv_"+tmpstr).className = "radiobtn_incorrect";
						}
					}
					else
					{
						parent.contentFrame.document.getElementById("qdiv_"+tmpstr).className = "radiobtn_checked";
					}
				}
				if(reviewmode)
				{
					parent.contentFrame.document.getElementById("qdiv_"+tmpstr).onclick = null;
				}
			}

		}
		else if(tqtype == "DROPLIST")
		{
				var tmpselect = tmpqdiv.getElementsByTagName("select")[0];
				for(var k=0;k<tmpselect.length;k++)
				{
					if(tmpselect.options[k].value == taskData[currentUnit][currentLesson][(startpos+i)].selectedOptionID)
					{
						tmpselect.selectedIndex = k;
						if(reviewmode)
						{
							if(taskData[currentUnit][currentLesson][(startpos+i)].attempted){
								if(taskData[currentUnit][currentLesson][(startpos+i)].iscorrect){
									tmpselect.className = "correct";
								}
								else
								{
									tmpselect.className = "incorrect";
								}
							}
							else
							{
								tmpselect.className = "unattempted";
							}
							tmpselect.disabled = true;
						}
					}
				}
		}
		else if(tqtype == "DRAGDROP")
		{
		}
		else
		{
			var tmpselect = tmpqdiv.getElementsByTagName("input")[0];
			tmpselect.value = taskData[currentUnit][currentLesson][(startpos+i)].selectedOptionID;
			if(reviewmode)
			{
				if(taskData[currentUnit][currentLesson][(startpos+i)].attempted)
				{
						var tempCurrScore = (taskData[currentUnit][currentLesson][i].answerParameters.correctAnswer).split("`");
						if (tempCurrScore[1]==0)
						{
							tmpselect.className = "unattempted";
						}
						else if(taskData[currentUnit][currentLesson][(startpos+i)].iscorrect)
						{
							tmpselect.className = "correct";
						}
						else
						{
								tmpselect.className = "incorrect";
						}
				}
				else
				{
					tmpselect.className = "unattempted";
				}
				tmpselect.readonly = true;
				tmpselect.disabled = true;
			}
		}
		answerTypeCD = GetNodeValue(xmlObj, "answerTypeCD", 0);
		ProcessAnswerParameters(GetNode(xmlObj, "responseEvaluationStrategy", 0));
		taskData[currentUnit][currentLesson][(startpos+i)].referenceID = readingpassageid+"_"+currentqid;
		taskData[currentUnit][currentLesson][(startpos+i)].questionID = tmpqid;
		taskData[currentUnit][currentLesson][(startpos+i)].id = currentqid;
		taskData[currentUnit][currentLesson][(startpos+i)].answerParameters = answerParameters;
		taskData[currentUnit][currentLesson][(startpos+i)].answerTypeCD = answerTypeCD;
		taskData[currentUnit][currentLesson][(startpos+i)].questionType = tqtype;
	}
	if(tqtype == "DRAGDROP")
	{
		questiondragitems = questiondragitems.split("||");
		for(var i=0;i<questiondragitems.length-1;i++){
				questiondragitems[i] = questiondragitems[i].split("~~");
				questiondragitems[i][0] = Strip(questiondragitems[i][0]);
		}
		var ditems = new Array();

		for(var i=0;i<questiondragitems.length-1;i++){
			var found = false;
			for(var j=0;j<ditems.length;j++){
				if(questiondragitems[i][1] == ditems[j][1]){
					ditems[j][2].push(questiondragitems[i][0]);
					found = true;
				}
			}
			if(!found){
				var tmparry = new Array();
				tmparry[0] = "dragitem_"+readingpassageid+"_"+i;
				tmparry[1] = questiondragitems[i][1];
				tmparry[2] = new Array();
				tmparry[2].push(questiondragitems[i][0]);
				ditems.push(tmparry);
			}
		}
		var ddata = new Array();
		for(var j=0;j<ditems.length;j++)
		{
			if(reviewmode)
			{
				parent.contentFrame.document.getElementById("dragitems_"+readingpassageid).innerHTML += "<div id='"+ditems[j][0]+"' class='dragitem unattempteddd'>"+ditems[j][1] + "</div>";
			}
			else
			{
				parent.contentFrame.document.getElementById("dragitems_"+readingpassageid).innerHTML += "<div id='"+ditems[j][0]+"' class='dragitem'>"+ditems[j][1] + "</div>";
			}
			ddata[ditems[j][0]] = ditems[j][2].toString();
		}

		var tarry = new Array();
		tarry[0] = ddata;
		tarry[1] = "#question_"+readingpassageid;
		tarry[2] = taskData[currentUnit][currentLesson];
		tarry[3] = "dragitems_"+readingpassageid;
		makedragdata.push(tarry);
		if(reviewmode){
			var qdata = taskData[currentUnit][currentLesson];
			for(var k=0;k<qdata.length;k++)
			{
				var tmpid = "qdiv_"+qdata[k].referenceID+":1";
				var dropspan = parent.contentFrame.document.getElementById(tmpid);
				if(dropspan == null) continue;
				if(qdata[k].prevalue != "")
				{
					dropspan.firstChild.innerHTML = qdata[k].prevalue;
					if(qdata[k].iscorrect)
					{
						dropspan.firstChild.className = dropspan.firstChild.className+" correct";
					}
					else
					{
						dropspan.firstChild.className = dropspan.firstChild.className+"  incorrect";
					}
				}
				else if(qdata[k].questionType == "DRAGDROP")
				{
					dropspan.firstChild.className = dropspan.firstChild.className+"  unattempteddd";
				}
			}
		}
		else
		{
			parent.contentFrame.MakeDraggable(makedragdata);
		}
	}
	taskData[currentUnit][currentLesson].initted = true;
	if(checkanswer){
		checkanswer = false;
		reviewmode = false;
		parent.contentFrame.document.getElementById("reviewlegend").style.visibility = "visible";
	}
	clearresponse = false;
	parent.contentFrame.document.getElementById("pagenumbering").innerHTML = GetCurrentQuestionNumForDisplay(eval(startpos+1),testQuestionSequence) + " of " + totalQuestionsForDisplay;

	if (Reviewtab > 0)
	{
		if(parent.contentFrame.document.getElementById("review_but_table"))
					parent.contentFrame.document.getElementById("review_but_table").style.display = "block";
	 if(IncompleteArray != null){
		if(currentScreenNum == IncompleteArray.length-1 &&  currentQuestionType == "Review Incomplete")  			{
			parent.contentFrame.document.getElementById("next_but_table").style.display="none"
		}
		if(currentScreenNum == lastScreen){
			parent.contentFrame.document.getElementById("next_but_table").style.display="none"
			parent.contentFrame.document.getElementById("NavNext_id").style.display="none"
		}
	 }

	}
	if(highlightArray[currentScreenNum]){
		setTimeout("parent.contentFrame.restoreHighlights(highlightArray[currentScreenNum])",500);

	}
	aatqstartpos = startpos;
	var resp = learnerData.GetResponse(startpos,currentUnit,currentLesson);
	if(eval(resp[4])){
		flagclick = true;
	}else{
		flagclick = false;
	}
	Flag_Withoutclick_Out();
	SetNavButtons();
	parent.contentFrame.document.getElementById("preloader").style.visibility = "hidden";
	parent.contentFrame.document.getElementById("loading_shadow").style.display = "none";
	if(reviewmode)
	{
		currentScreenType = "questionreview";
	}
}

function InitTaskDataObj()
{
	taskData = new Array();
	var tunits = configObj.getElementsByTagName("unit");
	var n = 0;
	for(var i=0;i<tunits.length;i++)
	{
		taskData[i] = new Array();
		var tlessons = tunits.item(i).getElementsByTagName("lesson");
		for(var j=0;j<tlessons.length;j++)
		{
			taskData[i][j] = new Array();
			var scrs = tlessons.item(j).getElementsByTagName("screen");
			for(var k=0; k<scrs.length;k++)
			{
				var tmpObj = new Object();
				tmpObj.referenceID = "none";
				tmpObj.questionID = "none";
				tmpObj.id = "";
				tmpObj.answerParameters = null;
				tmpObj.answerTypeCD = "";
				tmpObj.questionType = "";
				tmpObj.correct = "";

				//--Need to be stored/retrieved from the LMS--//
				tmpObj.selectedOptionID = "";
				tmpObj.attempted = false;
				tmpObj.prevalue = "";
				tmpObj.iscorrect = false;
				tmpObj.viewed = false;

				taskData[i][j].push(tmpObj);

				if(tlessons.item(j).getAttribute("type") == "exam" && scrs[k].getAttribute("type") == "question")
				{
					objAICC.SendInteraction(n, scrs[k].getAttribute("id"),"incorrect","","id");
					n++;
				}
			}
			taskData[i][j].initted = false;
		}
	}
}
function ResetAATQuestion(u,l,s)
{
	taskData[u][l][s].referenceID = "none";
	taskData[u][l][s].questionID = "none";
	taskData[u][l][s].id = "";
	taskData[u][l][s].answerParameters = null;
	taskData[u][l][s].answerTypeCD = "";
	taskData[u][l][s].questionType = "";
	taskData[u][l][s].selectedOptionID = "";
	taskData[u][l][s].attempted = false;
	taskData[u][l][s].prevalue = "";
	taskData[u][l][s].iscorrect = false;
	taskData[u][l][s].correct = "";
}
function SetTaskResponses(u,l)
{
	var lessonTaskResponses = learnerData.GetTestResponses(u,l);
	var responses = null;
	for(var i=0;i<lessonTaskResponses.length;i++)
	{
		responses = lessonTaskResponses[i].split(":");
		taskData[u][l][i].selectedOptionID = responses[1];
		taskData[u][l][i].attempted = (responses[1]=="")?false:true;
		if(responses[3] != null || responses[3] != undefined)
		{
			taskData[u][l][i].prevalue = responses[3];

		}
		taskData[u][l][i].iscorrect = eval(responses[2]);
	}
}

function SetTaskResponse(which, selectedinp, currentval)
{
	for(var i=0; i<taskData[currentUnit][currentLesson].length;i++)
	{
		if(which.id != undefined && which.id != null && which.id != "")
		{
			if(which.id.indexOf(taskData[currentUnit][currentLesson][i].referenceID+":") != -1)
			{
				taskData[currentUnit][currentLesson][i].selectedOptionID = selectedOptionID = selectedinp.value;
				taskData[currentUnit][currentLesson][i].attempted = true;
				currentqSetIndex = i;
				answerParameters = taskData[currentUnit][currentLesson][i].answerParameters;
				answerTypeCD = taskData[currentUnit][currentLesson][i].answerTypeCD;
				break;
			}
		}
		else
		{
			if(which.indexOf(taskData[currentUnit][currentLesson][i].questionID) != -1)
			{
				answerParameters = taskData[currentUnit][currentLesson][i].answerParameters;
				if(typeof(selectedinp)=="object")
				{
					var ifound = false;
					for(var j=0;j<selectedinp.length;j++)
					{
						if(selectedinp[j] == answerParameters)
						{
							ifound = true;
							taskData[currentUnit][currentLesson][i].selectedOptionID = selectedOptionID = selectedinp[j];
							break;
						}
					}
					if(!ifound) taskData[currentUnit][currentLesson][i].selectedOptionID = selectedOptionID = selectedinp[0];
					taskData[currentUnit][currentLesson][i].prevalue = RemoveProblemChars(currentval);
				}
				else
				{
					taskData[currentUnit][currentLesson][i].selectedOptionID = selectedOptionID = selectedinp;
				}
				taskData[currentUnit][currentLesson][i].attempted = true;
				currentqSetIndex = i;

				answerTypeCD = taskData[currentUnit][currentLesson][i].answerTypeCD;
				break;
			}
		}
	}
	taskData[currentUnit][currentLesson][currentqSetIndex].iscorrect = IsResponseCorrect();
	if(lessonType == "exam" || lessonType == "test" || lessonType=="customtest")
	{
		learnerData.SetResponse(currentqSetIndex,selectedOptionID,taskData[currentUnit][currentLesson][currentqSetIndex].iscorrect,taskData[currentUnit][currentLesson][currentqSetIndex].prevalue,currentUnit,currentLesson,flagclick);
		if(lessonType == "exam") SendInteractionInfo(currentqSetIndex, selectedOptionID, GetNode(currentLessonObj, "screen", currentqSetIndex));
	}
}
function RadioClick(which)
{
	if(which.className == "radiobtn_unchecked")
	{
		which.className = "radiobtn_checked";
	}
	var selectedinp = which.getElementsByTagName('input')[0];
	SwitchBtnGroup(selectedinp);
	SetTaskResponse(which, selectedinp, "");
}
function SwitchBtnGroup(selectedinp)
{
	var grp  = selectedinp.id.substr(0,selectedinp.id.indexOf(":"))
	var inps = parent.contentFrame.document.getElementsByTagName('input');
	for(var i=0;i<inps.length;i++)
	{
		if(inps[i].id.indexOf(grp) != -1)
		{
				if(inps[i].id != selectedinp.id)
				{
					inps[i].parentNode.className = "radiobtn_unchecked";
				}
		}
	}
}

function FillinKeyup(which, e)
{
	var code;
	if (!e) var e = window.event;
	code = e.keyCode;
	var character = String.fromCharCode(code);
	if(!isNumber(character)){
		e.keyCode=null;
		return;
	}
}
function isNumber(parm)
{
	var valnum = '0123456789.-()';
	if (parm == "") return true;
		for (i=0; i<parm.length; i++)
		{
			if (valnum.indexOf(parm.charAt(i),0) == -1) return false;
		}
	return true;
}
function FillinOnChange(which)
{
	SetTaskResponse(which.id, which.value, "");
}
function AddToSum(which, namestr)
{
	var questiongroupid = which.parentNode.id.substring(5,which.parentNode.id.lastIndexOf("_"));
	var questiongroup = parent.contentFrame.document.getElementById("question_"+questiongroupid);
	var tinps = questiongroup.getElementsByTagName("input");
	var idstosum = namestr.substr(4).split("_");
	for(var j=0;j<idstosum.length;j++)
	{
		idstosum[j] = "_"+idstosum[j]+":1";
	}
	var suminp = null;
	var inptosum = new Array();
	for(var i=0;i<tinps.length;i++)
	{
		if(suminp == null){
			if(tinps[i].id.indexOf(namestr) != -1)
			{
				suminp = tinps[i];
			}
		}
		for(var j=0;j<idstosum.length;j++)
		{
			if(tinps[i].id.indexOf(idstosum[j]) != -1)
			{
				inptosum.push(tinps[i]);
				break;
			}
		}
	}
	var thissum = 0;
	for(var i=0;i<inptosum.length;i++)
	{
		if(!isNaN(eval(inptosum[i].value))) thissum += eval(inptosum[i].value);
	}
	suminp.value = thissum;
	SetTaskResponse(suminp.id, suminp.value, "");
}
function SelectOnChange(which)
{
	SetTaskResponse(which.id, which[which.selectedIndex].value, "");
}
function DropOnTarget(droparea,dragitemids, currentval)
{
	SetTaskResponse(droparea.id, dragitemids.split(","), currentval);
}
//---------------//
//----------tile window code-------------//

function StepEndTest_open()
{
  parent.contentFrame.document.getElementById("EndExam_popup").style.left = parent.document.documentElement.clientWidth/2 - 196
  parent.contentFrame.document.getElementById("EndExam_popup").style.top = parent.document.documentElement.clientHeight/2 - 105
  parent.contentFrame.document.getElementById("EndExam_popup").style.display = "block";
}
function StepEndTest_close()
{
  parent.contentFrame.document.getElementById("EndExam_popup").style.display = "none";
}
function StepEndTest2_open()
{
  parent.contentFrame.document.getElementById("EndExam_popup2").style.left = parent.document.documentElement.clientWidth/2 - 196
  parent.contentFrame.document.getElementById("EndExam_popup2").style.top = parent.document.documentElement.clientHeight/2 - 105
  parent.contentFrame.document.getElementById("EndExam_popup2").style.display = "block";
}
function StepEndTest2_close()
{
  parent.contentFrame.document.getElementById("EndExam_popup2").style.display = "none";
}

function navigatorPopupClose()
{
  parent.contentFrame.document.getElementById("navigator_popup").style.display = "none";
}

function styledPopupClose()
{
  parent.contentFrame.document.getElementById("styled_popup").style.display = "none";
}

function styledPopup_port()
{
  parent.contentFrame.document.getElementById("styled_popup").style.display= "block";
}

function QusRewiewPopupClose()
{
  parent.contentFrame.document.getElementById("questionRewiew_scroll").style.height = "465px";
  parent.contentFrame.document.getElementById("QusRewiew_popup").style.display = "none";
}

function QusRewiewPopupClose1()
{
  parent.contentFrame.document.getElementById("questionRewiew_scroll").style.height = "465px";
  parent.contentFrame.document.getElementById("QusRewiew_popup1").style.display = "none";
}

function QusRewiewPopup_port()
{
  parent.contentFrame.document.getElementById("questionRewiew_scroll").style.height = "465px";
  parent.contentFrame.document.getElementById("QusRewiew_popup").style.display= "block";
  parent.contentFrame.document.getElementById("QusRewiew_popup1").style.display= "none";
}

function QusRewiewPopup_land()
{
  parent.contentFrame.document.getElementById("questionRewiew_scroll").style.height = "260px";
  parent.contentFrame.document.getElementById("QusRewiew_popup").style.display= "none";
  parent.contentFrame.document.getElementById("QusRewiew_popup1").style.display= "block";
}

function PageNum_Over(id){
	parent.contentFrame.document.getElementById("PageNum_id").className = "PageNum_Over"
	if(id=="PageNum_id" && currentScreenType == "question"){
		parent.contentFrame.document.getElementById("pagenumbering").style.color = "#C80000"
	}
	if(id=="PageNum_id" && currentScreenType == "testfeedback"){
		parent.contentFrame.document.getElementById("totalquestionsfeebback").style.color = "#C80000"
	}
	if(id=="PageNum_id1"){
		parent.contentFrame.document.getElementById("PageNum_id1").className = "PageNum_Over"
	}
}

function PageNum_Out(id){
	parent.contentFrame.document.getElementById("PageNum_id").className = "PageNum_Out"
	if(id=="PageNum_id" && currentScreenType == "question"){
		parent.contentFrame.document.getElementById("pagenumbering").style.color = "#000000"
	}
	if(id=="PageNum_id" && currentScreenType == "testfeedback"){
		parent.contentFrame.document.getElementById("totalquestionsfeebback").style.color = "#000000"
	}
	if(id=="PageNum_id1"){
		parent.contentFrame.document.getElementById("PageNum_id1").className = "PageNum_Out"
	}
}

////////////////////////////////////////////     Clock      ////////////////////////////////////////////

function Clock_Over(id){
	if(id=="Clock_id"){
		parent.contentFrame.document.getElementById("Clock_id").className = "Clock_Over"
		parent.contentFrame.document.getElementById("pagetimer").style.color = "#C80000"
	}
	if(id=="Clock_id1"){
		parent.contentFrame.document.getElementById("Clock_id1").className = "Clock_Over"
	}
}

function Clock_Out(id){
	if(id=="Clock_id"){
		parent.contentFrame.document.getElementById("Clock_id").className = "Clock_Out"
		parent.contentFrame.document.getElementById("pagetimer").style.color = "#000000"
	}
	if(id=="Clock_id1"){
		parent.contentFrame.document.getElementById("Clock_id1").className = "Clock_Out"
	}
}


function clockwith_timer_fun(){
	if(clocktimer){
		parent.contentFrame.document.getElementById("clockwith_timer").style.display= "none";
		parent.contentFrame.document.getElementById("clockwithout_timer").style.display= "table";

	}else{
		parent.contentFrame.document.getElementById("clockwithout_timer").style.display= "none";
		parent.contentFrame.document.getElementById("clockwith_timer").style.display= "table";
	}


}

function pagewith_num_fun(){
	if(pagenum){
		parent.contentFrame.document.getElementById("pagewith_number").style.display= "none";
		parent.contentFrame.document.getElementById("pagewithout_number").style.display= "table";
	}else{
		parent.contentFrame.document.getElementById("pagewith_number").style.display= "table";
		parent.contentFrame.document.getElementById("pagewithout_number").style.display= "none";
	}
}

////////////////////////////////////////////     /Clock      ////////////////////////////////////////////

function SetChecked(qid,seq){
	parent.contentFrame.document.getElementById("SetCheckedval_id"+seq).innerHTML = '<input type="button" id="checkRootID'+seq+'" name="checkRootID'+seq+'" class="Flag_Selected_Out" onclick="parent.codeFrame.SetUnChecked('+qid+','+seq+')" />'
	var tab = true
	var resp = learnerData.GetResponse(qid,currentUnit,currentLesson);
	learnerData.SetResponse(qid,resp[1],resp[2],"",currentUnit,currentLesson,tab);

	var tempqnum = 0;
	var aatq = false;
	var lObj = currentLessonObj.getElementsByTagName("screen");
	var tempQuesSet = "";
	var tempscreenobj = GetNode(currentLessonObj, "screen", qid);


	if(tempscreenobj.getAttribute("questionset")){
		tempQuesSet = tempscreenobj.getAttribute("questionset")

		for(var i=qid;i<lObj.length;i++) {
			var screenobj = GetNode(currentLessonObj, "screen", i);

			if(lObj[i].getAttribute("flag") == "AAT"){
				if(tempQuesSet == screenobj.getAttribute("questionset")){
					 tempQuesSet = screenobj.getAttribute("questionset");
				}
				else{
					qid=i-1;
					break;
				}
			}else{
				qid=i-1;
				break;
			}
		}

	}

	questionStatus[qid][1]=1
}



function SetUnChecked(qid,seq){
	parent.contentFrame.document.getElementById("SetCheckedval_id"+seq).innerHTML = '<input type="button" id="checkRootID'+seq+'" name="checkRootID'+seq+'" class="Flag_Incomplete_Out" onclick="parent.codeFrame.SetChecked('+qid+','+seq+')" onmouseover="parent.codeFrame.Flag_Incomplete_Over(id)" onmouseout="parent.codeFrame.Flag_Incomplete_Out(id)" />'

	var tab = false
	var resp = learnerData.GetResponse(qid,currentUnit,currentLesson);
	learnerData.SetResponse(qid,resp[1],resp[2],"",currentUnit,currentLesson,tab);


	var tempqnum = 0;
	var aatq = false;
	var lObj = currentLessonObj.getElementsByTagName("screen");
	var tempQuesSet = "";
	var tempscreenobj = GetNode(currentLessonObj, "screen", qid);


	if(tempscreenobj.getAttribute("questionset")){
		tempQuesSet = tempscreenobj.getAttribute("questionset")

		for(var i=qid;i<lObj.length;i++) {
			var screenobj = GetNode(currentLessonObj, "screen", i);

			if(lObj[i].getAttribute("flag") == "AAT"){
				if(tempQuesSet == screenobj.getAttribute("questionset")){
					 tempQuesSet = screenobj.getAttribute("questionset");
				}
				else{
					qid=i-1;
					break;
				}
			}else{
				qid=i-1;
				break;
			}
		}

	}

	questionStatus[qid][1]=0
}


//---------------------------------------- Stiop Mouse Wheel ----------------------------------------//

function stop()
{
return false;
}
parent.contentFrame.document.onmousewheel=stop;

////////////////////////////////////////////////-------Key Capture---------------//////////////////////////////////////////////

  function KeyCapture(e)
  {

	  parent.contentFrame.document.onkeydown = function(e) {
    e = e || parent.contentFrame.window.event;
   switch (e.keyCode)
{   case 68:
		//ScratchpadPopup('../code/Scratchpad.htm','Scratchpad');
	   	break;
	case 84:
		//strikeselectedText('putstrike');
		break;
	case 74:
		//selectedtexthighlight('yellow');
		break;
	case 67:
		//LaunchCalculator('../calculator/fcal.htm','calculator');
		break;
	case 88:
		//ExhibitPopup('../images/Management_Information_exhibit.pdf');
		break;
	default:
    }
};

  }

////////////////////////////////////////////////////////// Navigation Roll Over //////////////////////////////////////////////////////////


/*--------------------------------- New Ui roolover js ---------------------------------*/

function NavStartTest_Over(){
	parent.contentFrame.document.getElementById("StartTest_id").className = "NavStartTest_Over"
	parent.contentFrame.document.getElementById("starttestbtntext").className = "toolbartextover"
}
function NavStartTest_Out(){
	parent.contentFrame.document.getElementById("StartTest_id").className = "NavStartTest_Out"
	parent.contentFrame.document.getElementById("starttestbtntext").className = "toolbartext"
}


function NavEndTest_Over(){
	parent.contentFrame.document.getElementById("EndTest_id").className = "NavEndTest_Over"
}
function NavEndTest_Out(){
	parent.contentFrame.document.getElementById("EndTest_id").className = "NavEndTest_Out"
}


function NavNext_Over(){
	parent.contentFrame.document.getElementById("NavNext_id").className = "NavNext_Over"
	parent.contentFrame.document.getElementById("nextbtntext").className = "toolbartextover"
}
function NavNext_Out(){
	if(!parent.contentFrame.document.getElementById("NavNext_id"))return;
	parent.contentFrame.document.getElementById("NavNext_id").className = "NavNext_Out"
	parent.contentFrame.document.getElementById("nextbtntext").className = "toolbartext"
}

function NavPrevious_Over(){
	parent.contentFrame.document.getElementById("NavPrevious_id").className = "NavPrevious_Over"
	parent.contentFrame.document.getElementById("previousbtntext").className = "toolbartextover"
}
function NavPrevious_Out(){
	parent.contentFrame.document.getElementById("NavPrevious_id").className = "NavPrevious_Out"
	parent.contentFrame.document.getElementById("previousbtntext").className = "toolbartext"
}

function Navigator_Screen_Over(){
	parent.contentFrame.document.getElementById("Navigator_Screen_id").className = "Navigator_Screen_Over"
	parent.contentFrame.document.getElementById("navigatorbtntext").className = "toolbartextover"
}
function Navigator_Screen_Out(){
	parent.contentFrame.document.getElementById("Navigator_Screen_id").className = "Navigator_Screen_Out"
	parent.contentFrame.document.getElementById("navigatorbtntext").className = "toolbartext"
}

function Review_Screen_Over(){
	if(!parent.contentFrame.document.getElementById("Review_Screen_id")) return;
	parent.contentFrame.document.getElementById("Review_Screen_id").className = "Review_Screen_Over"
	parent.contentFrame.document.getElementById("reviewscreenbtntext").className = "toolbartextover"
}
function Review_Screen_Out(){
	if(!parent.contentFrame.document.getElementById("Review_Screen_id")) return;
	parent.contentFrame.document.getElementById("Review_Screen_id").className = "Review_Screen_Out"
	parent.contentFrame.document.getElementById("reviewscreenbtntext").className = "toolbartext"
}

function NavSymbol_Over(){
	parent.contentFrame.document.getElementById("Symbol_id").className = "Symbol_Over"
	parent.contentFrame.document.getElementById("symbolbtntext").className = "toolbartextover"
}
function NavSymbol_Out(){
	parent.contentFrame.document.getElementById("Symbol_id").className = "Symbol_Out"
	parent.contentFrame.document.getElementById("symbolbtntext").className = "toolbartext"
}

function NavCalculator_Over(){
	parent.contentFrame.document.getElementById("Calculator_id").className = "Calculator_Over"
	parent.contentFrame.document.getElementById("calculatorbtntext").className = "toolbartextover"
}
function NavCalculator_Out(){
	parent.contentFrame.document.getElementById("Calculator_id").className = "Calculator_Out"
	parent.contentFrame.document.getElementById("calculatorbtntext").className = "toolbartext"
}

function NavScratchpad_Over(){
	parent.contentFrame.document.getElementById("Scratchpad_id").className = "Scratchpad_Over"
	parent.contentFrame.document.getElementById("scratchpadbtntext").className = "toolbartextover"
}
function NavScratchpad_Out(){
	parent.contentFrame.document.getElementById("Scratchpad_id").className = "Scratchpad_Out"
	parent.contentFrame.document.getElementById("scratchpadbtntext").className = "toolbartext"
}

function NavStrikethrough_Over(){
	parent.contentFrame.document.getElementById("Strikethrough_id").className = "Strikethrough_Over"
}
function NavStrikethrough_Out(){
	parent.contentFrame.document.getElementById("Strikethrough_id").className = "Strikethrough_Out"
}

function NavHighlight_Over(){
	parent.contentFrame.document.getElementById("Highlight_id").className = "Highlight_Over"
}
function NavHighlight_Out(){
	parent.contentFrame.document.getElementById("Highlight_id").className = "Highlight_Out"
}

function Exhibit_Over(){
	parent.contentFrame.document.getElementById("Exhibit_button_id").className = "Exhibit_Over"
}
function Exhibit_Out(){
	parent.contentFrame.document.getElementById("Exhibit_button_id").className = "Exhibit_Out"
}

function Exhibitfixed_Over(){
	parent.contentFrame.document.getElementById("Exhibitfixed_button_id").className = "Exhibitfixed_Over"
}
function Exhibitfixed_Out(){
	parent.contentFrame.document.getElementById("Exhibitfixed_button_id").className = "Exhibitfixed_Out"
}

function TablesAndFormulae_Over(){
	parent.contentFrame.document.getElementById("TablesAndFormulae_id").className = "TablesAndFormulae_Over"
	parent.contentFrame.document.getElementById("helpandformulaebtntext").className = "toolbartextover"
}
function TablesAndFormulae_Out(){
	parent.contentFrame.document.getElementById("TablesAndFormulae_id").className = "TablesAndFormulae_Out"
	parent.contentFrame.document.getElementById("helpandformulaebtntext").className = "toolbartext"
}

//////////////////////////////////////for Scratchpad /////////////////////////////////////////
function ScratchpadCut_Over(){
	document.getElementById("Scratchpad_Cut").className = "Scratchpad_CutOver"
}
function ScratchpadCut_Out(){
	document.getElementById("Scratchpad_Cut").className = "Scratchpad_CutOut"
}

function ScratchpadCopy_Over(){
	document.getElementById("Scratchpad_Copy").className = "Scratchpad_CopyOver"
}
function ScratchpadCopy_Out(){
	document.getElementById("Scratchpad_Copy").className = "Scratchpad_CopyOut"
}

function ScratchpadPaste_Over(){
	document.getElementById("Scratchpad_Paste").className = "Scratchpad_PasteOver"
}
function ScratchpadPaste_Out(){
	document.getElementById("Scratchpad_Paste").className = "Scratchpad_PasteOut"
}

function ScratchpadUndo_Over(){
	document.getElementById("Scratchpad_Undo").className = "Scratchpad_UndoOver"
}
function ScratchpadUndo_Out(){
	document.getElementById("Scratchpad_Undo").className = "Scratchpad_UndoOut"
}

function ScratchpadRedo_Over(){
	document.getElementById("Scratchpad_Redo").className = "Scratchpad_RedoOver"
}
function ScratchpadRedo_Out(){
	document.getElementById("Scratchpad_Redo").className = "Scratchpad_RedoOut"
}

var CutTxt,CopiedTxt,PastedText;
var seltxtScratchpad ="";

function NavScratchpad_Cuttxt(myField)
{
	NavScratchpad_Copytxt();
	Cuttxt(myField);
}

function Cuttxt(myField){

	textAreaScrollPosition = myField.scrollTop;
	if (document.selection) {myField.focus();
		sel = document.selection.createRange();
		sel.text = "";
	}else if (myField.selectionStart || myField.selectionStart == '0'){
		myField.focus();
		var startPos = myField.selectionStart;
		var endPos = myField.selectionEnd;
		myField.value = myField.value.substring(0, startPos) + "" + myField.value.substring(endPos, myField.value.length);
		myField.setSelectionRange(endPos+"", endPos+"");
	}
	else{myField.value += "";
	}
	myField.scrollTop = textAreaScrollPosition;
}

function NavScratchpad_Copytxt()
{
  var textComponent = document.getElementById('Scratchpadnote');
  var selectedText;
  // IE version
  if (document.selection != undefined)
  {
    textComponent.focus();
    var sel = document.selection.createRange();
    selectedText = sel.text;
  }
  // Mozilla version
  else if (textComponent.selectionStart != undefined)
  {
    var startPos = textComponent.selectionStart;
    var endPos = textComponent.selectionEnd;
    selectedText = textComponent.value.substring(startPos, endPos)
  }

  // issue number 10
  if(selectedText.length !=0) {
	seltxtScratchpad = selectedText;
  }

}

function NavScratchpad_Pastetxt(myField){
textAreaScrollPosition = myField.scrollTop;

	if (document.selection) {
		myField.focus();
		 sel = document.selection.createRange();
		sel.text = seltxtScratchpad;
	}
	else if (myField.selectionStart || myField.selectionStart == '0'){

		myField.focus();
		var startPos = myField.selectionStart;
		var endPos = myField.selectionEnd;
		myField.value = myField.value.substring(0, startPos) + seltxtScratchpad + myField.value.substring(endPos, myField.value.length);
		myField.setSelectionRange(endPos+seltxtScratchpad.length, endPos+seltxtScratchpad.length);

	}
	else{
		myField.value += seltxtScratchpad;

	}
	myField.scrollTop = textAreaScrollPosition;


}

var myObject=new iiObject();
myObject.ii=0;
var myObject2=new iiObject();
myObject2.ii=0;
var store_text=new Array();
store_text[0]="";

function iiObject() {
  this.ii;
  return this;}

function countclik(tag,event) {
  myObject.ii++;
  var y=myObject.ii;
  var x=tag.value;
  store_text[y]=x;
 	if(event.which || event.keyCode){
		var valid =
        (event.keyCode > 47 && event.keyCode < 58)   || // number keys
        event.keyCode == 32 || event.keyCode == 13   || // spacebar & return key(s) (if you want to allow carriage returns)
        (event.keyCode > 64 && event.keyCode < 91)   || // letter keys
        (event.keyCode > 95 && event.keyCode < 112)  || // numpad keys
        (event.keyCode > 185 && event.keyCode < 193) || // ;=,-./` (in order)
        (event.keyCode > 218 && event.keyCode < 223);   // [\]' (in order)

			if(valid){
			  parent.codeFrame.Savenotedata(gWinScratchpad.document.getElementById("Scratchpadnote").value+String.fromCharCode(event.keyCode))
			  }
	}
	else{
		  parent.codeFrame.Savenotedata(gWinScratchpad.document.getElementById("Scratchpadnote").value)
	}

}

/*code updated for black undo*/
function NavScratchpad_Undotxt(tag) {

  if ((myObject2.ii)<=(myObject.ii)) {
    myObject2.ii++;
  } else {

    return;
  }
   var z=store_text.length;
  z=z-myObject2.ii;
  if (store_text[z]) {
  	tag.value=store_text[z];
  	gWinScratchpad.document.getElementById("Scratchpad_Redo").className = "Scratchpad_RedoOut"
  		gWinScratchpad.document.getElementById("Scratchpad_Redo").disabled = false;
  } else {
  	tag.value=store_text[0];
  	gWinScratchpad.document.getElementById("Scratchpad_Redo").className = "Scratchpad_RedoOut"
  		gWinScratchpad.document.getElementById("Scratchpad_Redo").disabled = false;
  }

if(tag.value.length==0) {
gWinScratchpad.document.getElementById("Scratchpad_Undo").disabled = true;
gWinScratchpad.document.getElementById("Scratchpad_Undo").className = "Scratchpad_UndoNone";
}

}
/*code updated for black Redo*/
function NavScratchpad_Redotxt(tag) {

  if((myObject2.ii)>=1) {

    myObject2.ii--;

  } else {

  return;
  }

  var z=store_text.length;

  var l=store_text.length;
  z=z-myObject2.ii;

  if (store_text[z]) {

    tag.value=store_text[z];

	gWinScratchpad.document.getElementById("Scratchpad_Redo").disabled = false;
	gWinScratchpad.document.getElementById("Scratchpad_Redo").className = "Scratchpad_RedoOut";
	 gWinScratchpad.document.getElementById("Scratchpad_Undo").className = "Scratchpad_UndoOut";
	   gWinScratchpad.document.getElementById("Scratchpad_Undo").disabled = false;
  } else {
  tag.value=store_text[0];

  }
 if(tag.value==store_text[l-1]){
	gWinScratchpad.document.getElementById("Scratchpad_Redo").disabled = true;
	gWinScratchpad.document.getElementById("Scratchpad_Redo").className = "Scratchpad_RedoNone";
 }
 }

/*------------------------------------------  Select For Review  ------------------------------------------*/


function Flag_Incomplete_Over(id){
	parent.contentFrame.document.getElementById(id).className = "Flag_Incomplete_Over"
}
/*on mouseover function is changing the class value from Flag_Selected_Out back to Flag_Incomplete_Out,so we implemented the logic that if the button is already selected on need to change any class rather do for the other non selected ones  */
function Flag_Incomplete_Out(id){
 var temp= parent.contentFrame.document.getElementById(id).className;
 if(temp=='Flag_Selected_Out'){
	 return;
 }else{
	parent.contentFrame.document.getElementById(id).className = "Flag_Incomplete_Out"
 }
}


function Flag_Withoutclick_Over(){
	if(flagclick){
		parent.contentFrame.document.getElementById("check_review").className = "Flag_Withclick_Over"
	}else{
		parent.contentFrame.document.getElementById("check_review").className = "Flag_Withoutclick_Over"
	}
	parent.contentFrame.document.getElementById("flagbtntext").className = "toolbartextover"
}

function Flag_Withoutclick_Out(){
	if(flagclick){
		parent.contentFrame.document.getElementById("check_review").className = "Flag_Withclick_Out"
	}else{
		parent.contentFrame.document.getElementById("check_review").className = "Flag_Withoutclick_Out"
	}
	parent.contentFrame.document.getElementById("flagbtntext").className = "toolbartext"
}
var mousedupclass = "";
function Flag_Mousedown(){
	mousedupclass = parent.contentFrame.document.getElementById("check_review").className;
	parent.contentFrame.document.getElementById("check_review").className = "Flag_click_Out";
}
function Flag_Mouseup(){
	parent.contentFrame.document.getElementById("check_review").className = mousedupclass;
}
function SelectCheckReview(){
	if(flagclick){
		flagclick = false;
		questionStatus[currentScreenNum][1] = 0
	}else{
		flagclick = true;
		questionStatus[currentScreenNum][1] = 1
	}
	Flag_Withoutclick_Out();
}


/*------------------------------------------  /Select For Review  ------------------------------------------*/
/*------------------------------------------  Testfeedback  ------------------------------------------*/

function feedback_Instructiontext_Over(){
	if(InstructiontextCount == 1)
	{
		parent.contentFrame.document.getElementById("feed_Instructiontext_id").className = "feedbackInstructiontext1_Over"
		parent.contentFrame.document.getElementById("Instruction_text_id").className = "feedback_headtext_yellow"
	}else{
		parent.contentFrame.document.getElementById("feed_Instructiontext_id").className = "feedbackInstructiontext_Over"
		parent.contentFrame.document.getElementById("Instruction_text_id").className = "feedback_headtext_yellow"
	}
}
function feedback_Instructiontext_Out(){
	if(InstructiontextCount == 1)
	{
		parent.contentFrame.document.getElementById("feed_Instructiontext_id").className = "feedbackInstructiontext1_Out"
		parent.contentFrame.document.getElementById("Instruction_text_id").className = "feedback_headtext"
	}else{
		parent.contentFrame.document.getElementById("feed_Instructiontext_id").className = "feedbackInstructiontext_Out"
		parent.contentFrame.document.getElementById("Instruction_text_id").className = "feedback_headtext"
	}
}


function feedback_Instructiontext(){
	if (InstructiontextCount == 0)
	{
		InstructiontextCount = 1;
	}
	else
	{
		InstructiontextCount = 0;
	}
	if(InstructiontextCount==1){
		parent.contentFrame.document.getElementById("Instruction_text").style.display= "none";
		parent.contentFrame.document.getElementById("feed_Instructiontext_id").className = "feedbackInstructiontext1_Out";
		parent.contentFrame.document.getElementById("Instruction_text_id").className = "feedback_headtext"

	}else{
		parent.contentFrame.document.getElementById("Instruction_text").style.display= "block"
		parent.contentFrame.document.getElementById("feed_Instructiontext_id").className = "feedbackInstructiontext_Out";
		parent.contentFrame.document.getElementById("Instruction_text_id").className = "feedback_headtext"
	}
}


function Quesfeedback_resulttext_Over(){
	if(feedback_queslisttxttab == 1)
	{
		parent.contentFrame.document.getElementById("Quesfeedbacktext_id").className = "feedbackInstructiontext1_Over"
		parent.contentFrame.document.getElementById("feedback_result_text_id").className = "feedback_headtext_yellow";
	}else{
		parent.contentFrame.document.getElementById("Quesfeedbacktext_id").className = "feedbackInstructiontext_Over"
		parent.contentFrame.document.getElementById("feedback_result_text_id").className = "feedback_headtext_yellow";
	}
}
function Quesfeedback_resulttext_Out(){
	if(feedback_queslisttxttab == 1)
	{
		parent.contentFrame.document.getElementById("Quesfeedbacktext_id").className = "feedbackInstructiontext1_Out"
		parent.contentFrame.document.getElementById("feedback_result_text_id").className = "feedback_headtext";
	}else{
		parent.contentFrame.document.getElementById("Quesfeedbacktext_id").className = "feedbackInstructiontext_Out"
		parent.contentFrame.document.getElementById("feedback_result_text_id").className = "feedback_headtext";
	}
}

//LongQ
function LQuesfeedback_resulttext_Over(){
	if(Lfeedback_queslisttxttab == 1)
	{
		parent.contentFrame.document.getElementById("LQuesfeedbacktext_id").className = "feedbackInstructiontext1_Over"
		parent.contentFrame.document.getElementById("Lfeedback_result_text_id").className = "feedback_headtext_yellow";
	}else{
		parent.contentFrame.document.getElementById("LQuesfeedbacktext_id").className = "feedbackInstructiontext_Over"
		parent.contentFrame.document.getElementById("Lfeedback_result_text_id").className = "feedback_headtext_yellow";
	}
}
function LQuesfeedback_resulttext_Out(){
	if(Lfeedback_queslisttxttab == 1)
	{
		parent.contentFrame.document.getElementById("LQuesfeedbacktext_id").className = "feedbackInstructiontext1_Out"
		parent.contentFrame.document.getElementById("Lfeedback_result_text_id").className = "feedback_headtext";
	}else{
		parent.contentFrame.document.getElementById("LQuesfeedbacktext_id").className = "feedbackInstructiontext_Out"
		parent.contentFrame.document.getElementById("Lfeedback_result_text_id").className = "feedback_headtext";
	}
}

//LongQ
function feedback_queslisttxt(){
	if (feedback_queslisttxttab == 0)
	{
	feedback_queslisttxttab = 1;
	}
	else
	{
		feedback_queslisttxttab = 0;
	}
	if(parent.contentFrame.document.getElementById("s_ques_rev_screen"))
	{
		if(feedback_queslisttxttab==1){
			parent.contentFrame.document.getElementById("s_ques_rev_screen").style.display = "none";
			parent.contentFrame.document.getElementById("Quesfeedbacktext_id").className = "feedbackInstructiontext1_Out";
			parent.contentFrame.document.getElementById("feedback_result_text_id").className = "feedback_headtext";
		}else{
			parent.contentFrame.document.getElementById("s_ques_rev_screen").style.display = "table"
			parent.contentFrame.document.getElementById("Quesfeedbacktext_id").className = "feedbackInstructiontext_Out";
			parent.contentFrame.document.getElementById("feedback_result_text_id").className = "feedback_headtext";
		}
	}

	if(parent.contentFrame.document.getElementById("s_nav_window"))
	{
		if(feedback_queslisttxttab==1){
			parent.contentFrame.document.getElementById("s_nav_window").style.display = "none";
			parent.contentFrame.document.getElementById("Quesfeedbacktext_id").className = "feedbackInstructiontext1_Out";
			parent.contentFrame.document.getElementById("feedback_result_text_id").className = "feedback_headtext";
		}else{
			parent.contentFrame.document.getElementById("s_nav_window").style.display = "table"
			parent.contentFrame.document.getElementById("Quesfeedbacktext_id").className = "feedbackInstructiontext_Out";
			parent.contentFrame.document.getElementById("feedback_result_text_id").className = "feedback_headtext";
		}
	}
}

<!--LongQ-->
function Lfeedback_queslisttxt(){
	if (Lfeedback_queslisttxttab == 0)
	{
	Lfeedback_queslisttxttab = 1;
	}
	else
	{
		Lfeedback_queslisttxttab = 0;
	}
	if(Lfeedback_queslisttxttab==1){
		parent.contentFrame.document.getElementById("Lquesfeedback_text").style.display= "none";
		parent.contentFrame.document.getElementById("LQuesfeedbacktext_id").className = "feedbackInstructiontext1_Out";
		parent.contentFrame.document.getElementById("feedback_result_text_id").className = "feedback_headtext";
	}else{
		parent.contentFrame.document.getElementById("Lquesfeedback_text").style.display= "block"
		parent.contentFrame.document.getElementById("LQuesfeedbacktext_id").className = "feedbackInstructiontext_Out";
		parent.contentFrame.document.getElementById("Lfeedback_result_text_id").className = "feedback_headtext";
	}
}
<!--LongQ-->


/*------------------------------------------  /Testfeedback  ------------------------------------------*/
/*---------------------------------------------Scratchpad-------------------------------------------*/
var gWinScratchpad = null;
function openScratchpad()
{
	if (!reviewmode){
		if(navigator.vendor && navigator.vendor.indexOf('Apple') > -1 && navigator.userAgent && !navigator.userAgent.match('CriOS')){
			if(gWinScratchpad==null || gWinScratchpad=="" || gWinScratchpad.closed){
			gWinScratchpad = window.open("../code/Scratchpad.htm","Scratchpad","width=685,height=453,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0, top=200, left=200");
			}else{
			gWinScratchpad.focus();
			}
		}else{
			if(gWinScratchpad==null || gWinScratchpad=="" || gWinScratchpad.closed){
			gWinScratchpad = window.open("../code/Scratchpad.htm","Scratchpad","width=683,height=480,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0, top=200, left=200");
			}else{
			gWinScratchpad.focus();
			}
		}
	}
}

var gWinCalculator = null;
var gWinTablesAndFormulae = null;
var gWinAnswers = null;
var gWinResponses = null;
function openCalculator()
{
	if(navigator.vendor && navigator.vendor.indexOf('Apple') > -1 && navigator.userAgent && !navigator.userAgent.match('CriOS')){
		if(gWinCalculator==null || gWinCalculator=="" || gWinCalculator.closed){
			gWinCalculator = window.open("../calculator/fcal.htm","calculator","width=230,height=380,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0, top=200, left=200");
		}else{
			gWinCalculator.focus();
		}
	}else{
		if(gWinCalculator==null || gWinCalculator=="" || gWinCalculator.closed){
			gWinCalculator = window.open("../calculator/fcal.htm","calculator","width=273,height=340,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0, top=200, left=200");
		}else{
			gWinCalculator.focus();
		}
	}
}
function resetPopVars(){
	gWinCalculator = null;
	gWinTablesAndFormulae = null;
	gWinScratchpad = null;
	gWinAnswers = null;
	gWinResponses = null;
}
function openTablesAndFormulae()
{
	if(gWinTablesAndFormulae==null || gWinTablesAndFormulae=="" || gWinTablesAndFormulae.closed){
		gWinTablesAndFormulae = window.open("helpandformulae.htm","helpnF","width=1068,height=532,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0, resizable=1, top=5, left=150");
	}else{
		gWinTablesAndFormulae.focus();
	}
}
function openAnswers()
{
	if(gWinAnswers==null || gWinAnswers=="" || gWinAnswers.closed){
		gWinAnswers = window.open("answers.htm","ansr","width=1068,height=532,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0, resizable=1, top=5, left=150");
	}else{
		gWinAnswers.focus();
	}
}
function openResponses()
{
	if(gWinResponses){
		if(gWinResponses.close) gWinResponses.close();
		gWinResponses = null;
	}
	gWinResponses = window.open("responses.htm","respns","width=970,height=710,toolbar=0,location=0,status=0,menubar=0,personalbar=0,scrollbars=0, resizable=1, top=5, left=150");
}
var responsesFrameReady = false;
var responsesFrameCheckTimer = null;
function CheckResponsesFrameReady()
{
	if(gWinResponses)
	{
		if(gWinResponses.frames["responses_sheet"])
		{
			if(gWinResponses.frames["responses_sheet"].PDFJS)
			{
				clearTimeout(responsesFrameCheckTimer);
				responsesFrameReady = true;
				DownloadAllResponses(gWinResponses.frames["responses_sheet"].PDFViewerApplication);
			}else{responsesFrameCheckTimer = setTimeout("CheckResponsesFrameReady();", 100)}
		}else{responsesFrameCheckTimer = setTimeout("CheckResponsesFrameReady();", 100)}
	}else{responsesFrameCheckTimer = setTimeout("CheckResponsesFrameReady();", 100)}
}
function Savenotedata(Scratchpadnoteval)
{
	datasavebypagenoarr[0] = Scratchpadnoteval;
}


function loadpopupnotetext()
{
	if((datasavebypagenoarr[0]) == undefined){
		gWinScratchpad.document.getElementById("Scratchpadnote").value= "";
	}
	else{
		gWinScratchpad.document.getElementById("Scratchpadnote").value= datasavebypagenoarr[0];
	}
}
/*---------------------------------------------Scratchpad closed-------------------------------------------*/

/*------------------------------------------- for text highliter-------------------------------------------------------*/

heighlitedropdownList = function() {
	if (parent.contentFrame.document.all && parent.contentFrame.document.getElementById) {
		var navRoot = parent.contentFrame.document.getElementById("dropdownhighlite");

		for (var i=0; i<navRoot.childNodes.length; i++) {
		var	node = navRoot.childNodes[i];
			if (node.nodeName=="LI") {
				node.onmouseover=function() {
					this.className+=" over";
				}
				node.onmouseout=function() {
					this.className=this.className.replace(" over", "");
				}
			}
		}
	}
}

strikedropdownList = function() {
	if (parent.contentFrame.document.all && parent.contentFrame.document.getElementById) {
		var navRoot = parent.contentFrame.document.getElementById("dropdownstrike");

		for (var i=0; i<navRoot.childNodes.length; i++) {
		var	node = navRoot.childNodes[i];
			if (node.nodeName=="LI") {
				node.onmouseover=function() {
					this.className+=" over";
				}
				node.onmouseout=function() {
					this.className=this.className.replace(" over", "");
				}
			}
		}
	}
}




/*-------------------------------------color highliter & strikethrough  --------------------------------------------*/

function highlightSelectedTextYellow(){
parent.contentFrame.highlightSelectedTextYellow();
}

function highlightSelectedTextGreen(){
	parent.contentFrame.highlightSelectedTextGreen();
}

function highlightSelectedTextPink(){
	parent.contentFrame.highlightSelectedTextPink();
}

function highlightSelectedTextBlue(){
	parent.contentFrame.highlightSelectedTextBlue();
}

function highlightSelectedTextRed(){
	parent.contentFrame.highlightSelectedTextRed();
}

function removeHighlightFromSelectedText(){
	parent.contentFrame.removeHighlightFromSelectedText();
}

function putstrikeselectedText(){
	parent.contentFrame.putstrikeselectedText();
}

/*-----------------------------------------------------highliter & strikethrough  closed----------------------------------------- */



/*------------------------------------------  Testfeedback NavButton ------------------------------------------*/

function Review_All_Over(){
	parent.contentFrame.document.getElementById("Review_All_id").className = "Review_All_Over"
	parent.contentFrame.document.getElementById("reviewallbtntext").className = "toolbartextover"
}

function Review_All_Out(){
	if(!parent.contentFrame.document.getElementById("Review_All_id")) return;
	parent.contentFrame.document.getElementById("Review_All_id").className = "Review_All_Out"
	parent.contentFrame.document.getElementById("reviewallbtntext").className = "toolbartext"
}


function Review_Incomplete_Over(){
	parent.contentFrame.document.getElementById("Review_Incomplete_id").className = "Review_Incomplete_Over"
	parent.contentFrame.document.getElementById("reviewincompletebtntext").className = "toolbartextover"
}

function Review_Incomplete_Out(){
	if(!parent.contentFrame.document.getElementById("Review_Incomplete_id")) return;
	parent.contentFrame.document.getElementById("Review_Incomplete_id").className = "Review_Incomplete_Out"
	parent.contentFrame.document.getElementById("reviewincompletebtntext").className = "toolbartext"
}


function Review_Selected_Over(){
	parent.contentFrame.document.getElementById("Review_Selected_id").className = "Review_Selected_Over"
	parent.contentFrame.document.getElementById("reviewselectedbtntext").className = "toolbartextover"
}

function Review_Selected_Out(){
	parent.contentFrame.document.getElementById("Review_Selected_id").className = "Review_Selected_Out"
	parent.contentFrame.document.getElementById("reviewselectedbtntext").className = "toolbartext"
}

function End_Review_Over(){
	if(selectedLessType == "test")
		parent.contentFrame.document.getElementById("End_Review_id").className = "End_Review_Over"
		parent.contentFrame.document.getElementById("endreviewbtntext").className = "toolbartextover"
}

function End_Review_Out(){
	if(selectedLessType == "test")
		parent.contentFrame.document.getElementById("End_Review_id").className = "End_Review_Out"
		parent.contentFrame.document.getElementById("endreviewbtntext").className = "toolbartext"
}


function Test_Summary_Over(){
	parent.contentFrame.document.getElementById("Test_Summary_id").className = "Test_Summary_Over"
}

function Test_Summary_Out(){
	parent.contentFrame.document.getElementById("Test_Summary_id").className = "Test_Summary_Out"
}


function Test_Review_Over(){
	parent.contentFrame.document.getElementById("Test_Review_id").className = "Test_Review_Over"
}

function Test_Review_Out(){
	parent.contentFrame.document.getElementById("Test_Review_id").className = "Test_Review_Out"
}

/*------------------------------------------  /Testfeedback NavButton ------------------------------------------*/

function End_Review_popuptext_Over(id){
	parent.contentFrame.document.getElementById(id).className = "End_Review_popuptext_Over"
}
function End_Review_popuptext_Out(id){
	if(!parent.contentFrame.document.getElementById(id)) return;
	parent.contentFrame.document.getElementById(id).className = "End_Review_popuptext_Out"
}

/*--------------------------------- Question number adjustment for AAT questions ---------------------------------*/

function GetTotalQuestionsForDisplay(){
	var tempqnum = 0;
	var aatq = false;
	var lObj = currentLessonObj.getElementsByTagName("screen");
	var tempQuesSet = "";


	for(var i=0;i<totalQuestionsToInclude;i++) {
		var screenobj = GetNode(currentLessonObj, "screen", i);

		if(lObj[i].getAttribute("flag") == "AAT"){
			if(tempQuesSet != screenobj.getAttribute("questionset") || !aatq){
				 tempqnum ++;
				 aatq = true;
				 tempQuesSet = screenobj.getAttribute("questionset")
			}
		}else{
			tempqnum ++;
			aatq = false;
		}
	}
	return tempqnum;
}

function GetCurrentQuestionNumForDisplay(currentpos,qarray){
	var tempqnum = 0;
	var aatq = false;
	var tempctr = 0;
	var lObj = currentLessonObj.getElementsByTagName("screen");
	var temppagenumIncomp =0;
	var tempQuesSet = "";

	if (currentQuestionTypeMode == "Navigator Mode")
	{
		for(var i in qarray) {
				var screenobj = GetNode(currentLessonObj, "screen", i);
				if(lObj[Number(i)].getAttribute("flag") == "AAT"){
				 tempqnum ++;
				 if(tempQuesSet != screenobj.getAttribute("questionset") || !aatq){
				 tempctr ++;
				 aatq = true;
				 tempQuesSet = screenobj.getAttribute("questionset")
				 }
				}else
	  		    aatq = false;

				if(i == currentpos) break;
			}
			return (currentpos - tempqnum + 1 + tempctr);
	}
	switch(currentQuestionType)
	{
		case "Review Selected":
			var tempPageNum = 0
			if(lObj[Number(currentpos)].getAttribute("flag") == "AAT"){
				var qsetCurrent = lObj[Number(currentpos)].getAttribute("questionset")

				for(var i=0; i<testQuestionSequence.length; i++) {
					if(lObj[Number(i)].getAttribute("flag") != "AAT"){
						tempPageNum++
					}
					else{
						if (qsetCurrent != lObj[Number(i)].getAttribute("questionset")){
							tempPageNum++
							while (lObj[Number(i)].getAttribute("questionset") == lObj[Number(i)+1].getAttribute("questionset")){
								i++
							}
						}
						else{
							tempPageNum++
							return tempPageNum;
						}
					}
				}
			}
			else{
				for(var i=0; i<testQuestionSequence.length; i++) {
					if(lObj[Number(i)].getAttribute("flag") != "AAT"){
						tempPageNum++
						if (i == currentpos) return tempPageNum
					}
					else{
						if (qsetCurrent != lObj[Number(i)].getAttribute("questionset")){
							tempPageNum++
							while (lObj[Number(i)].getAttribute("questionset") == lObj[Number(i)+1].getAttribute("questionset")){
								i++
							}
						}
					}
				}
			}
			break;
		case "Review Incomplete":
			var tempPageNum = 0
			if(lObj[Number(currentpos)].getAttribute("flag") == "AAT"){
				var qsetCurrent = lObj[Number(currentpos)].getAttribute("questionset")

				for(var i=0; i<testQuestionSequence.length; i++) {
					if(lObj[Number(i)].getAttribute("flag") != "AAT"){
						tempPageNum++
					}
					else{
						if (qsetCurrent != lObj[Number(i)].getAttribute("questionset")){
							tempPageNum++
							while (lObj[Number(i)].getAttribute("questionset") == lObj[Number(i)+1].getAttribute("questionset")){
								i++
							}
						}
						else{
							tempPageNum++
							return tempPageNum;
						}
					}
				}
			}
			else{
				for(var i=0; i<testQuestionSequence.length; i++) {
					if(lObj[Number(i)].getAttribute("flag") != "AAT"){
						tempPageNum++
						if (i == currentpos) return tempPageNum
					}
					else{
						if (qsetCurrent != lObj[Number(i)].getAttribute("questionset")){
							tempPageNum++
							while (lObj[Number(i)].getAttribute("questionset") == lObj[Number(i)+1].getAttribute("questionset")){
								i++
							}
						}
						else{
						}
					}
				}
			}
			break;
		default:
			for(var i in qarray) {
				if(lObj[Number(i)].getAttribute("flag") == "AAT"){
				 tempqnum ++;
				 if(!aatq){
					 tempctr ++;
					 aatq = true;
				 }
				 else{
					temp2currentScreenObj = GetNode(currentLessonObj, "screen", Number(i));
 					temp3currentScreenObj = GetNode(currentLessonObj, "screen", Number(i)-1);
					temp2QuesSet = temp2currentScreenObj.getAttribute("questionset")
					temp3QuesSet = temp3currentScreenObj.getAttribute("questionset")
					if (temp2QuesSet != temp3QuesSet)tempctr ++;

				 }
				}else{
		  		    aatq = false;
				}

				if(i == currentpos) break;
			}
			return (currentpos - tempqnum + 1 + tempctr);
			break;
	}
}

function GetTotalIncompleteQuestionsForDisplay(qarray){
	var tempqnum = 0;
	var aatq = false;
	var lObj = currentLessonObj.getElementsByTagName("screen");
	for(var i=0; i<qarray.length; i++) {
		if(lObj[qarray[i]].getAttribute("flag") == "AAT"){
		}else{
			tempqnum ++;
			aatq = false;
		}
	}
	return tempqnum;
}

function GetLonganswerCompletion(){
	//---modify this function to  return the actual completion ---//
	if (flagAllCompleteInLong)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

function GetLongFormQuestionTitle(){

	return GetNodeValue(currentLessonObj, "description", 0);
}

function placeredcrosshair(event){
	var x = event.clientX;
    var y = event.clientY;
	if (x-12 == redcrshr_lastpositionx && y-12 == redcrshr_lastpositiony){
		parent.contentFrame.document.getElementById("redcrosshair_icon").style.left = -100+"px";
		parent.contentFrame.document.getElementById("redcrosshair_icon").style.top = -100+"px";
		redcrshr_lastpositionx = -100
		redcrshr_lastpositiony = -100
	}
	else{
		parent.contentFrame.document.getElementById("redcrosshair_icon").style.left = x-12+"px";
		parent.contentFrame.document.getElementById("redcrosshair_icon").style.top = y-12+"px";
		redcrshr_lastpositionx = x-12
		redcrshr_lastpositiony = y-12
	}
}

//Vaidation for FIB
function blockNonNumbers(obj, e, allowDecimal, allowNegative)
{
	if(!answerParameters.ignoreNonAlphaNumeric)return true
    var key;
    var isCtrl = false;
    var keychar;
    var reg;
	//resolve issue number B-5
   if(!isIE) {
		if(window.event) {
			key = e.keyCode;
			isCtrl = window.event.ctrlKey
		}
		else if(e.which) {
			key = e.which;
			isCtrl = e.ctrlKey;
		}

	}else {

	key = (window.event) ? e.which : e.keyCode;
	 isCtrl = e.ctrlKey;
	}

	if(!isIE) {

	if (isNaN(key)) return true;

	}

	keychar = String.fromCharCode(key);

	// check for backspace or delete, or if Ctrl was pressed
    if (key == 8 || isCtrl || key==13)
    {
        return true;
    }

    reg = /\d/;
    var isFirstN = allowNegative ? keychar == '-' && obj.value.indexOf('-') == -1 : false;
    var isFirstD = allowDecimal ? keychar == '.' && obj.value.indexOf('.') == -1 : false;
    var isFirstC = allowDecimal ? keychar == ',' && obj.value.indexOf(',') == -1 : false;


	if(keychar != '-' && keychar != '.' && keychar != ',') {

	if(!reg.test(keychar)) {
		Invalid_Char_open();
		return false;
	}

	}
    return isFirstN || isFirstD || isFirstC || reg.test(keychar);
}
function blockInvalid(obj)
{
	if(!answerParameters.ignoreNonAlphaNumeric)return true
    var temp=obj.value;
    if(temp=="-")
    {
        temp="";
    }

    if (temp.indexOf(".")==temp.length-1 && temp.indexOf(".")!=-1)
    {
        temp=temp+"00";
    }
    if (temp.indexOf(".")==0)
    {
        temp="0"+temp;
    }
    if (temp.indexOf(".")==1 && temp.indexOf("-")==0)
    {
        temp=temp.replace("-","-0") ;
    }
    if (temp.indexOf(",")==temp.length-1 && temp.indexOf(",")!=-1)
    {
        //temp=temp+"00";
    }
    if (temp.indexOf(",")==0)
    {
        temp="0"+temp;
    }
    if (temp.indexOf(",")==1 && temp.indexOf("-")==0)
    {
        temp=temp.replace("-","-0") ;
    }
    temp=temp.replace(",","") ;
    obj.value=temp;
}
function extractNumber(obj, decimalPlaces, allowNegative)
{
	if(!answerParameters.ignoreNonAlphaNumeric)return true
    var temp = obj.value;

    // avoid changing things if already formatted correctly
    var reg0Str = '[0-9]*';
    if (decimalPlaces > 0) {
		reg0Str += '\[\.]?[0-9]{0,' + decimalPlaces + '}';
    } else if (decimalPlaces < 0) {
		reg0Str += '\[\.]?[0-9]*';
    }
    reg0Str = allowNegative ? '^-?' + reg0Str : '^' + reg0Str;
    reg0Str = reg0Str + '$';
    var reg0 = new RegExp(reg0Str);
    if (reg0.test(temp)) return true;

    // first replace all non numbers
    var reg1Str = '[^0-9' + (decimalPlaces != 0 ? '.' : '') + (decimalPlaces != 0 ? ',' : '') + (allowNegative ? '-' : '') + ']';
    var reg1 = new RegExp(reg1Str, 'g');
    temp = temp.replace(reg1, '');

    if (allowNegative) {
        // replace extra negative
        var hasNegative = temp.length > 0 && temp.charAt(0) == '-';
        var reg2 = /-/g;
        temp = temp.replace(reg2, '');
        if (hasNegative) temp = '-' + temp;
    }

    if (decimalPlaces != 0) {
		var reg3 = /[\.]/g;
        var reg3Array = reg3.exec(temp);
        if (reg3Array != null) {
            // keep only first occurrence of .
            //  and the number of places specified by decimalPlaces or the entire string if decimalPlaces < 0
            var reg3Right = temp.substring(reg3Array.index + reg3Array[0].length);
            reg3Right = reg3Right.replace(reg3, '');
            reg3Right = decimalPlaces > 0 ? reg3Right.substring(0, decimalPlaces) : reg3Right;
            temp = temp.substring(0,reg3Array.index) + '.' + reg3Right;
        }
    }
	temp=temp.replace(",","") ;

    obj.value = temp;
}
function isAATQFlagged(id){
	var tempQuesSet = "";
	var tempscreenobj = GetNode(currentLessonObj, "screen", id);


	if(tempscreenobj.getAttribute("questionset")){
		tempQuesSet = tempscreenobj.getAttribute("questionset")

		for(var i=id;i<testQuestionSequence.length;i++) {
			var screenobj = GetNode(currentLessonObj, "screen", i);

			if(screenobj.getAttribute("flag") == "AAT"){
				if(tempQuesSet == screenobj.getAttribute("questionset")){
					 tempQuesSet = screenobj.getAttribute("questionset");
				}
				else{
					id=i-1;
					break;
				}
			}else{
				id=i-1;
				break;
			}
		}

	}

	if(questionStatus[id][1]==1){
		return true;
	}
	else{
		return false;
	}
}

function cleanHTML(htm){
	if(!htm)return "";
	htm = htm.replace(/[\u0027\u2018\u2019\u201A\u201B\u2032\u2035]/g, "'" );
  htm = htm.replace(/[\u0022\u201C\u201D\u201E\u201F\u2033\u2036]/g,'"');
	htm = htm.replace(/[\u2013\u2014]/g,'-');
	htm = htm.replace(/[\u2026]/g,'...');
	htm = htm.replace(/[\u00A0\u205F\u2060]/g,' ');
	//htm = htm.replace(/&nbsp;+/g,' ');
	//htm = htm.replace(/\"/g,"'");
	//htm = htm.replace(/ +/g,' ');
	//htm = htm.replace(/><\//g,'>  </');
	htm = htm.replace(/[\u000A\u0009]/g,'');
	htm = htm.replace(/[“”]/g,'"');
	htm = htm.replace(/[‘’]/g,"'");
	htm = htm.replace(/[’]/g,"'");
	htm = htm.replace(/[“]/g,'"');
	htm = htm.replace(/[”]/g,'"');
	htm = htm.replace(/&prime;/g,"'");
	htm = htm.replace(/&rsquo;/g,"'");
	htm = htm.replace(/&lsquo;/g,"'");
	htm = htm.replace(/&apos;/g,"'");
	htm = htm.replace(/&rdquo;/g,'"');
	htm = htm.replace(/&ldquo;/g,'"');
	htm = htm.replace(/&mdash;/g,"-");
	htm = htm.replace(/&ndash;/g,"-");
	htm = htm.replace(/&hellip;/g,"...");
	htm = htm.replace(/&sbquo;/g,"'");
	htm = htm.replace(/&rsquor;/g,"'");
	htm = htm.replace(/&lsquor;/g,"'");
	htm = htm.replace(/&bdquo;/g,'"');
	htm = htm.replace(/&rdquor;/g,'"');
	htm = htm.replace(/&ldquor;/g,'"');
	return htm;
}
function TrimOptionHTML(htm){
	if(!htm)return "";
	//htm = htm.replace(/[\u000A\u0009\u000D]/g,' ');
	htm = htm.replace(/\s\s+/g, ' '); //trim spaces, tabs, newlines
	htm = htm.replace(/<\/para>/g,'<\p>');
	htm = htm.replace(/<para>/g,'<p>');
	//htm = htm.trim();
	return htm;
}
function AddTableHeaderRow(qelement){
	var cols = 0;
	var row, cell;
	telements = qelement.getElementsByTagName('table');
	for(var i=0;i<telements.length;i++){
		if(telements[i].getElementsByTagName('col')){
			cols = telements[i].getElementsByTagName('col').length;
			row = telements[i].insertRow(0);
			for(var j=0;j<cols;j++){
				cell = row.insertCell(j);
				cell.innerHTML = '<td>Header' + (j+1) + '</td>';
			}
		}
		telements[i].setAttribute("style","font-family:arial;font-size:10pt;margin:0px;padding:0px;line-height:16px")
	}
	return qelement.innerHTML;
}
function GeneratePDF(htm, filename){
	var doc = new jsPDF('P','mm','a4');
	doc.fromHTML(htm, 15, 15, {'width': 170},'',{'top':15, 'bottom': 15});
	doc.save(filename+'.pdf');
}

function DownloadResponse(snum, add){
	var filename = 'Response_'+SCOID+'_Q_'+(snum+1);
		if(add) AddToResponses();
	var scrt = allresponsehtml[snum].type;
	if(scrt=="SPREADSHEET"){
		//PDF output of simple html table
		var tblhtm = GetHTMFromSheet();
		var div = document.createElement('div');
		document.body.appendChild(div);
		div.style.visibility = "hidden";
		div.innerHTML = tblhtm;

		var doc = new jsPDF();
    var elem = div.getElementsByTagName("table")[0];
    var res = doc.autoTableHtmlToJson(elem);
    doc.autoTable(res.columns, res.data, {startY: 15, theme: 'plain'});
		doc.save(filename+'.pdf');
		div.parentNode.removeChild(div);
	}
	if(scrt=="ESSAY"){
		var htm = allresponsehtml[snum].htm;
		GeneratePDF(htm, filename);
	}
}
function AddToResponses(){
	//if(selectedOptionID == "" || selectedOptionID == null) return;
	var htm = '';//'<style>.default{background-color:#FFFFFF} table.cellborderon{border-collapse:collapse; border:1px solid rgb(200,200,200)} .cellborderon td, .cellborderon th{border-right:1px solid rgb(200,200,200); border-bottom:1px solid rgb(200,200,200)} td,th{font-family:Arial; font-size:10pt; font-style:normal; height:19px; line-height:15px; padding:2px} body,p,li,div{font-family:Arial; font-size:10pt} .italic{font-style:italic} .bold{font-style:bold} .underline{font-style:underline}</style>';
	htm += '<p><b>Question '+(currentScreenNum+1)+':</b></p>\r';
	//htm += '<p>'+parent.contentFrame.document.getElementById('questionsetstimulus').innerHTML;+'</p>\r';
	htm += cleanHTML(AddTableHeaderRow(parent.contentFrame.document.getElementById('qstem')));

	allresponsehtml[currentScreenNum] = new Object();
	allresponsehtml[currentScreenNum].type = answerTypeCD;
	allresponsehtml[currentScreenNum].qstem = htm;
	allresponsehtml[currentScreenNum].screen = currentScreenNum;
	allresponsehtml[currentScreenNum].unit = currentUnit;
	allresponsehtml[currentScreenNum].lesson = currentLesson;

	var raw = "";
	var studentanswer = "";
	var answerobjects = null;
	switch(answerTypeCD){
 		case "SPREADSHEET":
			raw = GetHTMFromSheet();
			htm = '<p></p><p><b>Your answer:</b></p>\r';
			break;
		case "ESSAY":
			htm = '<p></p><p><b>Your answer:</b></p>\r';
			htm += parent.contentFrame.CKEDITOR.instances.EssayAnswer.getData();
			break;
		case "MC_LID":
			answerobjects = parent.contentFrame.document.getElementsByTagName("div");
			htm = '<ul>\r';
			for(var i=0;i<answerobjects.length;i++){
				if(answerobjects[i].id.indexOf("_answertext") != -1){
					htm += "<li>"+answerobjects[i].innerHTML+"</li>\r"
					if(answerobjects[i].id.substr(0,answerobjects[i].id.indexOf("_answertext")) == selectedOptionID){
						studentanswer = "<p><b>Your answer:</b></p><p>"+answerobjects[i].innerHTML+"</p>\r"
					}
				}
			}
			htm += "</ul>\r";
			htm += studentanswer;
			break;
		case "MULTIPLE_CHOICE_MULTIPLE_ANSWER":
			answerobjects = parent.contentFrame.document.getElementsByTagName("div");
			studentanswer = "<p><b>Your answer:</b></p><p>\r"
			htm = '<ul>\r';
			for(var i=0;i<answerobjects.length;i++){
				if(answerobjects[i].id.indexOf("_answertext") != -1){
					htm += "<li>"+answerobjects[i].innerHTML+"</li>\r"

					if(parent.contentFrame.document.getElementById("check_"+answerobjects[i].id.substr(0,answerobjects[i].id.indexOf("_answertext"))).checked){
						studentanswer += "<li>"+answerobjects[i].innerHTML+"</li>\r"
					}
				}
			}
			htm += "</ul>\r";
			htm += "<ul>"+studentanswer+"</ul>\r";
			break;
		case "MATCHING":
			answerobjects = parent.contentFrame.document.getElementsByTagName("select");
			htm = "<p><b>Your answer:</b></p><p><ul>\r";
			for(var i=0;i<answerobjects.length;i++)
			{
				htm += "<li>"+answerobjects[i].options[answerobjects[i].selectedIndex].text+"</li>\r";
			}
			htm += "</ul>\r";
			break;
		case "FILLIN_SINGLE_ANSWER":
			htm = '<p></p><p><b>Your answer:</b></p>\r';
			htm += '<p>'+parent.contentFrame.document.getElementById('answer').value+'</p>\r';
			break;
		default:
			htm = '<p></p><p><b>Your answer:</b></p>\r';
			htm += '<p>'+selectedOptionID+'</p>\r';
			break;
	}

	allresponsehtml[currentScreenNum].response = cleanHTML(htm);
	allresponsehtml[currentScreenNum].raw = raw;
	allresponsehtml[currentScreenNum].id = '<p align="right">'+parent.contentFrame.document.getElementById('vendorsid').innerHTML+'</p>\r';
}
var doc;
var currentResponse = -1;
function DownloadAllResponses(){
	var filename = 'Response_'+SCOID+'_All_Responses';
	//.contentFrame.document.getElementById('downloadAllResponses').value = "Processing...";
	//parent.contentFrame.document.getElementById('downloadAllResponses').disabled = true;
	doc = new jsPDF('p','pt','a4');
	doc.setFont("times");
	doc.setFontType("normal");
	//doc.setFontSize(10);
	doc.setFillColor(255);
	var pos = {'x':45,'y':15};

	PDFPrintNextQuestion(pos);

	//parent.contentFrame.document.getElementById("downloadAllResponses").value = "Download Responses";
	//parent.contentFrame.document.getElementById('downloadAllResponses').disabled = false;
}
function PDFPrintNextQuestion(pos){
	currentResponse++;
	if(currentResponse<allresponsehtml.length){
		if(!allresponsehtml[currentResponse].type){
			for(currentResponse++;currentResponse<allresponsehtml.length;currentResponse++){
				if(allresponsehtml[currentResponse].type){
					break;
				}
			}
		}
		if(currentResponse>0){
			doc.addPage();
			pos.y = 15;
		}
		console.log("Printing next question: "+currentResponse);
		PDFPrintQStem(pos);
	}else{
		PDFPrintSummary(pos);
	}
}
function PDFPrintQStem(pos){
	pos = doc.fromHTML(allresponsehtml[currentResponse].qstem, pos.x, pos.y, {'width': 500,'elementHandlers': {'printHeaders':false}},PDFPrintResponse,{'top': 15, 'bottom': 15});
}
function PDFPrintResponse(pos){
	pos = doc.fromHTML(allresponsehtml[currentResponse].response, pos.x, pos.y, {'width': 500,'elementHandlers': {'printHeaders':false}},PDFPrintStatus,{'top': 15, 'bottom': 15});
}
function PDFPrintStatus(pos){
	var learnerResponse;
	var htm = "";
	var div, elem, res;
	switch(allresponsehtml[currentResponse].type){
		case "SPREADSHEET":
			if(allresponsehtml[currentResponse].raw){
				//doc.addPage();
				console.log("Printing spreadsheet response ");
				div = document.createElement('div');
				document.body.appendChild(div);
				div.style.visibility = "hidden";

				div.innerHTML = allresponsehtml[currentResponse].raw;
				elem = div.getElementsByTagName("table")[0];
				res = doc.autoTableHtmlToJson(elem);
				doc.autoTable(res.columns, res.data,{
					startY: pos.y+10,
					tableLineColor: 200,
					tableLineWidth: 0.1,
					styles: {
							font: 'arial',
							lineColor: 200,
							lineWidth: 0.1,
							fontSize: 10,
							textColor: 80
					},
					headerStyles: {
							fillColor: 255,
							fontSize: 10,
							fontStyle: 'normal'
					},
					bodyStyles: {
							fillColor: 255,
							textColor: 80
					},
					alternateRowStyles: {
							fillColor: 255
					},
				});
				div.parentNode.removeChild(div);
				pos.y = doc.autoTable.previous.finalY;
			}
			PDFPrintId(pos);
			break;
		case "ESSAY": PDFPrintId(pos); break;
		case "MC_LID":
		case "MULTIPLE_CHOICE_MULTIPLE_ANSWER":
		case "MATCHING":
		case "FILLIN_SINGLE_ANSWER":
		default:
			learnerResponse = learnerData.GetResponse(allresponsehtml[currentResponse].screen,allresponsehtml[currentResponse].unit,allresponsehtml[currentResponse].lesson);
			if(eval(learnerResponse[2])){
				htm = "<p><b>Status</b>:<br/>Correct</p>";
			}else{
				htm = "<p><b>Status</b>:<br/>Incorrect</p>";
			}
			pos = doc.fromHTML(htm, pos.x, pos.y, {'width': 500,'elementHandlers': {'printHeaders':false}},PDFPrintId,{'top': 15, 'bottom': 15});
	}
}
function PDFPrintId(pos){
	pos = doc.fromHTML(allresponsehtml[currentResponse].id, pos.x, pos.y, {'width': 500,'elementHandlers': {'printHeaders':false}},PDFPrintNextQuestion,{'top': 15, 'bottom': 15});
}
function PDFPrintSummary(pos){
	doc.addPage();
	pos.y = 15;
	pos = doc.fromHTML('<p>A summary of your performance appears below.</p>', pos.x, pos.y, {'width': 500,'elementHandlers': {'printHeaders':false}},function(param){console.log("--finishing pdf--")},{'top': 15, 'bottom': 15});
	pos.y += doc.internal.getFontSize();
	var div, elem, res;
	div = document.createElement('div');
	document.body.appendChild(div);
	div.innerHTML = pdfsummaryhtm;
	elem = div.getElementsByTagName("table")[0];
	res = doc.autoTableHtmlToJson(elem);
	doc.autoTable(res.columns, res.data,{
		startY: pos.y,
		showHeader: 'firstPage',
		tableLineColor: 200,
		tableLineWidth: 0.1,
		styles: {
				font: 'arial',
				lineColor: 200,
				lineWidth: 0.1,
				fontSize: 10,
				textColor: 80
		},
		headerStyles: {
				fillColor: 255,
				fontSize: 10,
				fontStyle: 'bold'
		},
		bodyStyles: {
				fillColor: 255,
				textColor: 80
		},
		alternateRowStyles: {
				fillColor: 255
		},
	});
	div.parentNode.removeChild(div);
	console.log("Opening PDF");
	var pdfData = base64ToUint8Array(btoa(doc.output()));
	try{
		gWinResponses.ShowResponses(pdfData);
	}catch(e){
		console.error("couldn't call ShowResponses")
	}
	console.log("PDF opened");
	currentResponse = -1;
}
function base64ToUint8Array(base64) {
  var raw = atob(base64);
  var uint8Array = new Uint8Array(raw.length);
  for (var i = 0; i < raw.length; i++) {
    uint8Array[i] = raw.charCodeAt(i);
  }
  return uint8Array;
}
function DownloadAnswers(){
	return window.location.href = "../content/Answers.pdf";
}
function GetHTMFromObject(htmObj, rowcount, colcount){
	var h = '';
	h += '<table id="spreadtable" style="display: none;">\r';
	var cval = "";
	var slicedrow = [];
	for(var r=0;r<rowcount;r++){
		h+= '<tr>\r';
		slicedrow = htmObj[r].slice(0,colcount);
		h+='<td>' + slicedrow.join('</td><td>') + '</td>\r';
		h+= '</tr>\r';
	}
	h+= '</table>\r';

	return h;
}
function GetHTMFromSheet(){
	var h = new Array();
	var rowcount = spread.getSheet(0).getRowCount();
	var colcount = spread.getSheet(0).getColumnCount();
	var sheet = spread.getSheet(0);
	var lastDataCol = 0;
	var lastDataRow	= 0;
	var cval = "";
	for(var r=0;r<rowcount;r++){
		h[r]=new Array();
		for(var c=0;c<colcount;c++){
			cval = GetCellValue(sheet, r,c).toString();
			if(cval != null && cval != "") {
				if(c > lastDataCol){
					lastDataCol = c;
				}
				lastDataRow = r;
			}
			h[r][c] = cval;
		}
	}
	var tablehtm = GetHTMFromObject(h, (lastDataRow+1), (lastDataCol+1));
	return tablehtm;
}
function GetCellValue(sheet,r,c){
	if(sheet.getValue(r,c) == null||sheet.getValue(r,c) == undefined){
		return '';
	}else{
		if(sheet.hasFormula(r,c)){
			return "="+sheet.getFormula(r,c); //sheet.getValue(r,c) + " \r" + sheet.getValue(r,c) + ' {' + sheet.getFormula(r,c) + '}';
		}else{
			return sheet.getValue(r,c);
		}
	}
}
function GetCSV(){
	var h = '';
	var rowcount = spread.getSheet(0).getRowCount();
	var colcount = spread.getSheet(0).getColumnCount();
	var sheet = spread.getSheet(0);
	for(var r=0;r<rowcount;r++){
		for(var c=0;c<colcount;c++){
			if(c==0){
				h+='"' + GetCellValue(sheet, r,c) + '"';
			}else{
				h+=',"' + GetCellValue(sheet, r,c) + '"';
			}
		}
		h+= '\r';
	}
	return h;
}
function GetSectionCDownloads(){
	var htm = "";
	for(var i=0;i<allresponsehtml.length;i++){
		if(allresponsehtml[i].type == "SPREADSHEET"){
			htm += '<input type="button" value="Download Question '+(i+1)+' Response" onclick="parent.codeFrame.DownloadResponse('+i+', false, this.id)" /> &nbsp;';
		}
		if(allresponsehtml[i].type == "ESSAY"){
			htm += '<input type="button" value="Download Question '+(i+1)+' Response" onclick="parent.codeFrame.DownloadResponse('+i+', false, this.id)" /> &nbsp;';
		}
	}
	return htm;
}
function GetSectionABCount(){
	var screenst = currentLessonObj.getElementsByTagName("screen");
	var sectionpos = 0;
	for(var i=0;i<screenst.length;i++){
		if(screenst[i].getAttribute('sectionname')) sectionpos = i;
	}
	return sectionpos;
}
function GetSectionCCount(){
	var screenst = currentLessonObj.getElementsByTagName("screen");
	var sectionpos = 0;
	for(var i=0;i<screenst.length;i++){
		if(screenst[i].getAttribute('sectionname')) sectionpos = i;
	}
	return (screenst.length - sectionpos);
}
var activeColumn = 0, activeRow = 0;
var selectedSymbol = "$";
var selectedSymbolID = "s0";
var totalSymbols = 25;
function OpenSymbol(){
	parent.contentFrame.document.getElementById("symbolmenu").style.display = "block";
}
function CloseSymbol(){
	parent.contentFrame.document.getElementById("symbolmenu").style.display = "none";
}
function InsertSymbol(){
	switch(answerTypeCD){
		case "SPREADSHEET":
		if(spread.getSheet(0)){
			var sheet = spread.getSheet(0);
			activeColumn = sheet.getActiveColumnIndex();
			activeRow = sheet.getActiveRowIndex();
			var currentValue = sheet.getValue(activeRow,activeColumn);
			if(!currentValue) currentValue = "";
			sheet.setValue(activeRow,activeColumn,currentValue+selectedSymbol);

		/*	var a = selectedSymbol;
			try {
					//GcSpread.Sheets.FocusHelper.setActiveElement(this.sheet);
					var b = sheet.getCell(activeRow, activeColumn);
					var c = (null !== b.formula()) ? ("=" + b.formula()) : ((null === b.value()) ? "" : b.value() + "");
					var d = (void 0 === fbx.caret()) ? 0 : fbx.caret();
					var	e = (sheet.isEditing()) ? (c.substring(0, d) + a + c.substring(d)) : a;
					/*sheet.doCommand(new parent.contentFrame.GC.Spread.Sheets.UndoRedo.CellEditUndoAction(sheet, {
							row: activeRow,
							col: activeColumn,
							newValue: e,
							autoFormat: !0
					}));
					fbx.text(e);
					fbx.caret(d + 1)*/
					/*b.text(e);
			} catch (f) {}
			*/
		}
		break;
		case "ESSAY":
			parent.contentFrame.CKEDITOR.instances.EssayAnswer.insertText(selectedSymbol);
		break;
	}
}
function SelectSymbol(el){
	selectedSymbol = el.innerHTML;
	selectedSymbolID = el.parentNode.getAttribute("id");
	el.parentNode.className = "key highlight"
	var sdiv;
	for(var i=0;i<totalSymbols;i++){
		sdiv = parent.contentFrame.document.getElementById("s"+i);
		if(sdiv.getAttribute("id") != selectedSymbolID){
			sdiv.className = "key";
		}
	}
}

// Initialise
objAICC.Initialize();
