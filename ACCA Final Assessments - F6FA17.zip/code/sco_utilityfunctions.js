var strMode;
var AICC_Url = AICC_Cmd = AICC_Ver = AICC_Sid = AICC_Data = AICC_LesDT = AICC_CorVE = AICC_CorEV = AICC_CorST = AICC_LauDT = courseID = courseBID = debugLogTxt = "";
var flgStatus, timer, temp, debugLogWin, LaunchMode, debugWin, debugmode;
var tmpCtr = 0;
var AICC_ErrArr = new Array();
var AICC_CorDTArr = new Array();
var tempArr = new Array();
var initFlag = false;
var timeoutid1 = null;
var timeoutid2 = null;
var exitCalled = false;
/////////Check weather API exists or not/////////

// returns the CMI API SCORM 1.2 object (may be null if not found)
function findAPI1(win){
   while ((win.API == null) && (win.parent != null) && (win.parent != win))  {
      win = win.parent;
      var numOfFrames = win.frames.length;
      var counter     = 0;
      while(counter < numOfFrames){
		try{
			if(win.frames[counter].API){
				return win.frames[counter].API;
			}
		}catch(err){
			console.log("Error: "+err)
		}
      	counter++;
      }      
   }  
   return win.API;
}

// returns the CMI API SCORM 2004 object (may be null if not found)
function findAPI2(win){
   while ((win.API_1484_11 == null) && (win.parent != null) && (win.parent != win))  {
      win = win.parent;
      var numOfFrames = win.frames.length;
      var counter     = 0;
      while(counter < numOfFrames){
      	try{
			if(win.frames[counter].API_1484_11){
      		return win.frames[counter].API_1484_11;
			}
		}catch(err){
			console.log("Error: "+err)
		}
      	counter++;
      }      
   }  
   return win.API_1484_11;
}
function getAPI(which){
	if(which == 2){
		var theAPI = findAPI2(window);
	}else{
		var theAPI = findAPI1(window);	
	}
	if ((theAPI == null) && (window.opener != null) && (typeof(window.opener) != "undefined"))
	{
		if(which == 2){
			theAPI = findAPI2(window.opener);
		}else{
			theAPI = findAPI1(window.opener);
		}
	}
	return theAPI;
}
/////////////////////////////////////////////////

/////////Convert plain/text to javaScript string/////////
function replace(str, original, replacement) {
	var result;
	result = "";
	while(str.indexOf(original) != -1) {
		if (str.indexOf(original) > 0)
			result = result + str.substring(0, str.indexOf(original)) + replacement;
		else
			result = result + replacement;
	str = str.substring(str.indexOf(original) + original.length, str.length);
	}
	return result + str;
}

function parseDT(param) {
	var strParse = param;
	strParse = replace(strParse, "\\", "\\\\");
	//strParse = replace(strParse, "\r", "\^");
	strParse = replace(strParse, "\r", "");
	strParse = replace(strParse, '"', ' \\ "');
	strParse = replace(strParse, "'", "\\'");
	strParse = replace(strParse, "\t", "");
	strParse = replace(strParse, "<", " \\<");
	strParse = replace(strParse, ">", " \\>");
	strParse = replace(strParse, "^^", "\^");
	while(strParse.indexOf("\n") != -1)
		strParse = strParse.substring(0, strParse.indexOf("\n")) + "\^" + strParse.substring(strParse.indexOf("\n") + 1, strParse.length);
	return strParse;
}
/////////////////////////////////////////////////////////


// Handle all the the FSCommand messages in a Flash movie
function HACP_Comm_DoFSCommand(command, args) {
	var HACP_CommObj = InternetExplorer ? HACP_Comm : document.HACP_Comm;
	if (command == "send-data" && AICC_Cmd == "GetParam") {
		alert("raw: " + args);
		populateAICC_arr(parseDT(args));
		if(!initFlag){
			StartLoading();
			initFlag = true;
		}
		//alert(AICC_Cmd + ":" + command + "\rError: " + AICC_ErrArr + "\r return data:\r" + unescape(args));
	}
	else if (command == "initialize") {
		callLMS();		
	}
}

//IE 5+, NN7 version 16-9-05
var aiccreq = null;
function callLMS(){
	//alert("in callLMS");
	sendstring = "session_id="+AICC_Sid+"&command="+AICC_Cmd+"&version="+AICC_Ver+"&aicc_data="
	if(AICC_Cmd == "PutParam"){
		sendstring = sendstring+AICC_Data;
	}
    if (window.XMLHttpRequest) {
		appendLog("Browser is non-IE");
        aiccreq = new XMLHttpRequest();
        aiccreq.onreadystatechange = CheckForData;
        aiccreq.open("POST", AICC_Url, true);
        aiccreq.send(sendstring);
    // branch for IE/Windows ActiveX version
    } else if (window.ActiveXObject) {
		appendLog("Browser is IE");
        //isIE = true;
        aiccreq = new ActiveXObject("Microsoft.XMLHTTP");
        if (aiccreq) {
            aiccreq.onreadystatechange = CheckForData;
            aiccreq.open("POST", AICC_Url, true);
            aiccreq.send(sendstring);
        }
    }
}
function CheckForData(){
	//alert("in check for data, readystate: " + aiccreq.readyState);
	appendLog("Ready State: ");
	if (aiccreq.readyState == 4) {
        if (aiccreq.status == 200) {
            appendLog("aicc response received");
			var data = aiccreq.responseText;
			//alert("data: " + data);
			if(AICC_Cmd == "ExitAU"){
				appendLog("Calling Exit");
				CallExit();
			}else if(AICC_Cmd == "GetParam"){
				appendLog("data found, populate array");
				populateAICC_arr(parseDT(data));
			}
         } else {
		 	appendLog("There was a problem retrieving the AICC data:\n" +
                aiccreq.statusText);
            alert("There was a problem retrieving the AICC data:\n" +
                aiccreq.statusText);
         }
    }
}

function CallExit(){
	flgStatus = false;
	flgStatus = callLMS();
	appendLog("Exitting");
	if(debugmode == "true"){
		wrtToDebugWin();
		debugWin.top.opener = top;
		wrtToDebugLogWin();
		debugLogWin.top.opener = top;
	}
	top.window.opener = top;
	if(exitCalled){
		timeoutid2 = setTimeout("top.window.close();",500);
	}else{
		var cdt1 = new Date();
		var cdt2 = new Date();
		do{
			cdt2 = new Date();
		}while(cdt2-cdt1<2000);
	}
}

function GetAiccData(){
	var fromApplet = AICC_comm.CallFunction("GetParam","nothing");
	var afterParse = parseDT(fromApplet);
	alert(fromApplet + ":" + afterParse);
	populateAICC_arr(afterParse);
}
//////////////////////////////////////////////////////////

//////////////// AICC Data management ////////////////
function populateAICC_arr (AICC_Data){
	appendLog("Populating Data: "+AICC_Data);
	//AICC_Data = AICC_Data.toLowerCase()+"^[end_of_data]";
	AICC_Data = AICC_Data+"^[end_of_data]";
	appendLog("AICC_Data: " + AICC_Data);
	if(strMode != "STA"){
		temp = AICC_Data.substr(0,AICC_Data.indexOf("aicc_data=")-1);
		tempArr = temp.split("^");
		appendLog("temp: " + temp);
		for(i=0;i<tempArr.length;i++){
			if (tempArr[i].substr(0,tempArr[i].indexOf('=')) != ""){
				AICC_ErrArr[i] = new ArrayObjs();
				AICC_ErrArr[i].name = trimTxt(tempArr[i].substr(0,tempArr[i].indexOf('=')));
				AICC_ErrArr[i].value = trimTxt(tempArr[i].substr(tempArr[i].indexOf('=')+1,tempArr[i].length));
			}
		}
	}
	temp = AICC_Data.substr(AICC_Data.indexOf("[core]")+7,AICC_Data.length);
	temp = temp.substr(0,temp.indexOf("["));
	tempArr = temp.split("^");
	appendLog("CORE: " + temp);
	for(i=0;i<tempArr.length;i++){
		if (tempArr[i].substr(0,tempArr[i].indexOf('=')-1) != "" && trimTxt(tempArr[i]) != ""){
			AICC_CorDTArr[tmpCtr] = new ArrayObjs();
			AICC_CorDTArr[tmpCtr].name = trimTxt(tempArr[i].substr(0,tempArr[i].indexOf('=')));
			AICC_CorDTArr[tmpCtr].value = trimTxt(tempArr[i].substr(tempArr[i].indexOf('=')+1,tempArr[i].length));
			if(AICC_CorDTArr[tmpCtr].name=="lesson_location"||AICC_CorDTArr[tmpCtr].name=="lesson_status"||AICC_CorDTArr[tmpCtr].name=="score"||AICC_CorDTArr[tmpCtr].name=="time")AICC_CorDTArr[tmpCtr].stFlg = "set";
			if(AICC_CorDTArr[tmpCtr].name=="lesson_status" && AICC_CorDTArr[tmpCtr].value.charAt(0)=="n"){
				tmpCtr++;
				AICC_CorDTArr[tmpCtr] = new ArrayObjs();
				AICC_CorDTArr[tmpCtr].name = "entry";
				AICC_CorDTArr[tmpCtr].value = "ab-initio";
			}else if(AICC_CorDTArr[tmpCtr].name=="lesson_status" && AICC_CorDTArr[tmpCtr].value.indexOf(",")!=-1){
				if(AICC_CorDTArr[tmpCtr].value.split(",")[1].charAt(0)=="a"){
					tmpCtr++;
					AICC_CorDTArr[tmpCtr] = new ArrayObjs();
					AICC_CorDTArr[tmpCtr].name = "entry";
					AICC_CorDTArr[tmpCtr].value = "ab-initio";
				}
			}
			tmpCtr++;
		}
	}
	tmpCtr = 0;
	temp="";
	if (AICC_Data.indexOf("[core_lesson]") != -1){
		temp = AICC_Data.substr(AICC_Data.indexOf("[core_lesson]")+14,AICC_Data.length); 
		temp = replace(temp.substr(0,temp.indexOf("[")),"^","");
		AICC_LesDT = trimTxt(temp);
	}
	temp="";
	if (AICC_Data.indexOf("[core_vendor]") != -1){
		temp = AICC_Data.substr(AICC_Data.indexOf("[core_vendor]")+13,AICC_Data.length); 
		temp = replace(temp.substr(0,temp.indexOf("[")),"^","");
		AICC_CorVE = trimTxt(temp);
	}
	AICC_Data="";
	StartLoading();
}

function populateAICC_Data(){
	AICC_Data="";
	//AICC_Data=unescape("\r\n\r\n[core]\r\n\r\n");
	AICC_Data=unescape("[core]");
	for(i=0;i<AICC_CorDTArr.length;i++){
		if(AICC_CorDTArr[i].stFlg == "set") AICC_Data = AICC_Data+"\n"+AICC_CorDTArr[i].name +"="+ AICC_CorDTArr[i].value+"\r";
	}
	//AICC_Data = AICC_Data+"\n [core_lesson] \n"+AICC_LesDT+"\n [core_vendor] \n"+AICC_CorVE+"\n";
	AICC_Data = AICC_Data+"\n[core_lesson]\n"+AICC_LesDT+"\n[core_vendor]\n"+AICC_CorVE+"\n";
	//AICC_Data = AICC_Data.toUpperCase();
	//AICC_Data =escape(AICC_Data);
	return true;
}
function ArrayObjs(){
this.name = "";
this.value = "";
this.stFlg = "";
}
function getDataFrmArray(arrNm, element){
	for(i=0;i<arrNm.length;i++){
		if(arrNm[i].name == element){return arrNm[i].value;}
	}
	return "";
}
function setDataToArray(arrNm, element, data){
	for(i=0;i<arrNm.length;i++){
		if(arrNm[i].name == element){arrNm[i].value = data;arrNm[i].stFlg = "set";return;}
	}
	arrNm.push(new ArrayObjs());
	arrNm[arrNm.length-1].name = element;
	arrNm[arrNm.length-1].value = data;
	arrNm[arrNm.length-1].stFlg = "set";
	if(debugmode == "true"){
		wrtToDebugWin();
		wrtToDebugLogWin();
	}
}
//////////////////////////////////////////////////////

////////////Communication via Cookie (STA_Comm)////////////
function createCookie(param){
	appendLog("Creating Cookie");
	var the_date = new Date("December 31, 2023");
	var the_cookie_date = the_date.toGMTString();
	var course = param;
	appendLog("Writing to Cookie: "+escape(AICC_Data));
	document.cookie = course + "=" + escape(AICC_Data) + ";expires=" + the_cookie_date;
	return true;
}

function CallCookie(param){
	appendLog("Calling CallCookie("+param+")");
	if (document.cookie == '') {
		var initdata = "^^[core]^^^lesson_status=na^lesson_location=^time=0000:00:00^ [core_lesson] ^^ [core_vendor] ^^";
		populateAICC_arr(initdata);
		return false;
	}else{
		var firstChar, lastChar;
		var theBigCookie = document.cookie;
		firstChar = theBigCookie.indexOf(param);
		if(firstChar != -1)  {
			firstChar += param.length + 1;
			lastChar = theBigCookie.indexOf(';', firstChar);
			if(lastChar == -1) lastChar = theBigCookie.length;
			populateAICC_arr(parseDT(unescape(theBigCookie.substring(firstChar, lastChar))));
			return true;
		}else{
			return false;
		}
	}
}
////////////////////////////////////////////////
function trimTxt (str){
	while(str.charAt(0)==' ' || str.charAt(str.length-1)==' '){
		if (str.charAt(0)==' ') str=str.substring(1,str.length);
		else str=str.substring(0,str.length-1);
	}
	return str;
}
////////////Debug functions////////////
function showDebugWin(){
	debugWin = null;
	debugWin = window.open ('blank.htm','','scrollbars=yes,resizable=yes,height=400,width=400');
}

function showDebugLogWin(){
	debugLogWin = null;
	debugLogWin = window.open ('blank.htm','','scrollbars=yes,resizable=yes,height=400,width=400');
}

function wrtToDebugWin(){
	if(debugWin == null || debugWin == "" || debugWin.closed) {
		showDebugWin();
		setTimeout("wrtToDebugWin()",1000);
		debugWin.focus();
	}else{
		var debugTxt = "";
		debugTxt = debugTxt+"<table width='95%' border='1' cellpadding='2' cellspacing='0' bordercolor='#663333' style='font-family:Arial;font-size:10pt'><tr><td>Communication mode:</td><td>"+strMode+"</td></tr>";
		if(strMode == "HACP"){
			debugTxt = debugTxt+"<tr><td>AICC url:</td><td>"+AICC_Url+"</td></tr>";
			debugTxt = debugTxt+"<tr><td>AICC session id:</td><td>"+AICC_Sid+"</td></tr>";
			debugTxt = debugTxt+"<tr><td>AICC version:</td><td>"+AICC_Ver+"</td></tr>";
			debugTxt = debugTxt+"<tr><td>AICC command:</td><td>"+AICC_Cmd+"</td></tr>";
		}
		debugTxt = debugTxt+"<tr><td>Course id:</td><td>"+courseID+"</td></tr>";
		debugTxt = debugTxt+"<tr><td>Course build id:</td><td>"+courseBID+"</td></tr>";
		for(i=0;i<AICC_ErrArr.length;i++){
			debugTxt = debugTxt + "<tr><td width='40%'>" + AICC_ErrArr[i].name +"</td><td width='60%'>";
			if(AICC_ErrArr[i].value == ""){debugTxt = debugTxt + "&nbsp;</td></tr>";} 
			else{debugTxt = debugTxt + AICC_ErrArr[i].value +"</td></tr>";} 
		}
		for(i=0;i<AICC_CorDTArr.length;i++){
			debugTxt = debugTxt + "<tr><td width='40%'>" + AICC_CorDTArr[i].name +"</td><td width='60%'>";
			if(AICC_CorDTArr[i].value == "") {debugTxt = debugTxt + "&nbsp;</td></tr>";} 
			else{debugTxt = debugTxt + AICC_CorDTArr[i].value +"</td></tr>";}  
		}
		if(AICC_LesDT == "") debugTxt = debugTxt+"<tr><td>Lesson data:</td><td>&nbsp;</td></tr>"; 
		else debugTxt = debugTxt+"<tr><td>Lesson data:</td><td>"+AICC_LesDT+"</td></tr>";
		if(AICC_CorVE == "") debugTxt = debugTxt+"<tr><td>Launch parameters:</td><td>&nbsp;</td></tr>";
		else debugTxt = debugTxt+"<tr><td>Launch parameters:</td><td>"+AICC_CorVE+"</td></tr>";
		debugTxt = debugTxt + "<tr><td colspan='2'><b><a href='javascript:top.opener.wrtToDebugWin()' style='text-decoration:none; color:black'>Refresh</a> | <a href='javascript:top.opener.wrtToDebugLogWin()' style='text-decoration:none; color:black'>Show/Refresh Log</a></b></td></tr></table>";
		debugWin.document.body.innerHTML = debugTxt;
	}
}

function appendLog(param){
	debugLogTxt = debugLogTxt+param+"<br>";
}

function wrtToDebugLogWin(){
	if(debugLogWin == null || debugLogWin == "" || debugLogWin.closed){
		showDebugLogWin();
		setTimeout("wrtToDebugLogWin()",1000);
		debugLogWin.focus();
	}else{
		debugLogWin.document.body.innerHTML = "<p style='font-family:Arial;font-size:10pt'><b>Log:</b></P><table width='95%' border='1' cellpadding='2' cellspacing='0' bordercolor='#663333' style='font-family:Arial;font-size:10pt'><tr><td>"+debugLogTxt+"</td></tr></table>";
	}
}
///////////////////////////////////////